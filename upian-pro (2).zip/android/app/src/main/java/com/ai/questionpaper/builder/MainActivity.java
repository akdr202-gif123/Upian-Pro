package com.ai.questionpaper.builder;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
