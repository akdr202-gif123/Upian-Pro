var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_url = require("url");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_meta = {};
import_dotenv.default.config();
var __filename = (0, import_url.fileURLToPath)(import_meta.url);
var __dirname = import_path.default.dirname(__filename);
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json({ limit: "10mb" }));
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", service: "Upian Pro API" });
  });
  app.post("/api/generate-paper", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY environment variable is missing on the server."
        });
      }
      const {
        board,
        classLevel,
        medium,
        subject,
        chapters,
        difficulty,
        totalMarks,
        questionDistribution,
        customInstructions,
        examTitle,
        timeAllowedMinutes,
        includeAnswerKey
      } = req.body;
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build"
          }
        }
      });
      const prompt = `
You are an expert exam question paper author and curriculum designer for Indian and Global Education Boards (CBSE, ICSE, State Boards).
Generate a complete, highly professional, accurate, and syllabus-compliant question paper according to the following specifications:

SPECIFICATIONS:
- Board: ${board || "CBSE"}
- Class/Grade: ${classLevel || "10"}
- Medium of Instruction: ${medium || "English"}
- Subject: ${subject || "Science"}
- Chapters/Topics Covered: ${Array.isArray(chapters) && chapters.length > 0 ? chapters.join(", ") : "All core chapters"}
- Difficulty Level: ${difficulty || "Medium"}
- Total Marks: ${totalMarks || 80}
- Examination Title: ${examTitle || "Annual Examination 2026-27"}
- Time Allowed: ${timeAllowedMinutes || 180} minutes
- Include Answer Key: ${includeAnswerKey ? "Yes" : "No"}

QUESTION DISTRIBUTION DESIRED:
- 1 Mark Questions (MCQ / Very Short): ${questionDistribution?.mcq1m || 10}
- 2 Marks Questions (Short Answer Type I): ${questionDistribution?.short2m || 5}
- 3 Marks Questions (Short Answer Type II): ${questionDistribution?.short3m || 4}
- 4 Marks Questions (Case Study / Passage / Assertion-Reason): ${questionDistribution?.case4m || 2}
- 5 Marks Questions (Long Answer / Conceptual / Numerical): ${questionDistribution?.long5m || 2}
${customInstructions ? `- Custom Teacher Notes: ${customInstructions}` : ""}

GENERAL INSTRUCTIONS FOR THE PAPER:
1. Provide standard General Instructions block (1. All questions are compulsory, 2. The paper is divided into sections, etc.).
2. Categorize the paper into logical sections:
   - Section A: 1-mark Objective / MCQs
   - Section B: 2-marks Short Answer Type I
   - Section C: 3-marks Short Answer Type II
   - Section D: 4-marks Case Study / Source Based Questions
   - Section E: 5-marks Long Answer Questions
3. Ensure every question has clear wording, correct options for MCQs (A, B, C, D), and appropriate mark allocation.
4. Provide a detailed Answer Key with step-by-step solutions and marking scheme for EVERY question.
`;
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          systemInstruction: "You generate exam paper JSON adhering strictly to the requested schema. Output must be valid JSON.",
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.OBJECT,
            properties: {
              title: { type: import_genai.Type.STRING },
              board: { type: import_genai.Type.STRING },
              classLevel: { type: import_genai.Type.STRING },
              subject: { type: import_genai.Type.STRING },
              medium: { type: import_genai.Type.STRING },
              timeAllowedMinutes: { type: import_genai.Type.NUMBER },
              totalMarks: { type: import_genai.Type.NUMBER },
              generalInstructions: {
                type: import_genai.Type.ARRAY,
                items: { type: import_genai.Type.STRING }
              },
              sections: {
                type: import_genai.Type.ARRAY,
                items: {
                  type: import_genai.Type.OBJECT,
                  properties: {
                    id: { type: import_genai.Type.STRING },
                    title: { type: import_genai.Type.STRING },
                    description: { type: import_genai.Type.STRING },
                    questions: {
                      type: import_genai.Type.ARRAY,
                      items: {
                        type: import_genai.Type.OBJECT,
                        properties: {
                          id: { type: import_genai.Type.STRING },
                          text: { type: import_genai.Type.STRING },
                          type: { type: import_genai.Type.STRING, description: "mcq, short, long, case_study" },
                          marks: { type: import_genai.Type.NUMBER },
                          options: {
                            type: import_genai.Type.ARRAY,
                            items: { type: import_genai.Type.STRING }
                          },
                          answer: { type: import_genai.Type.STRING },
                          explanation: { type: import_genai.Type.STRING },
                          chapter: { type: import_genai.Type.STRING },
                          diagramNote: { type: import_genai.Type.STRING }
                        },
                        required: ["id", "text", "marks", "answer"]
                      }
                    }
                  },
                  required: ["id", "title", "questions"]
                }
              }
            },
            required: ["title", "board", "classLevel", "subject", "totalMarks", "sections"]
          }
        }
      });
      const responseText = response.text || "{}";
      const paperData = JSON.parse(responseText);
      return res.json({
        success: true,
        paper: paperData
      });
    } catch (error) {
      console.error("Error generating paper with Gemini:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to generate question paper."
      });
    }
  });
  app.post("/api/suggest-questions", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      const {
        board = "CBSE",
        classLevel = "10",
        subject = "Science",
        chapter = "General",
        difficulty = "Medium",
        count = 40
      } = req.body;
      if (!apiKey) {
        return res.status(500).json({
          error: "GEMINI_API_KEY environment variable is missing on the server."
        });
      }
      const ai = new import_genai.GoogleGenAI({
        apiKey,
        httpOptions: { headers: { "User-Agent": "aistudio-build" } }
      });
      const prompt = `
Generate exactly ${count} high-quality, distinct exam questions for:
- Board: ${board}
- Class: ${classLevel}
- Subject: ${subject}
- Chapter/Topic: ${chapter}
- Difficulty: ${difficulty}

Include a healthy balance of:
1. 1-mark MCQs (with 4 choices A, B, C, D)
2. 2-marks Short Answer questions
3. 3-marks Conceptual questions
4. 4-marks Case study / Numerical questions
5. 5-marks Long Answer questions

Provide a complete model solution/answer for each question.
Return JSON as an array of questions under a "questions" key.
`;
      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are an exam author. Output valid JSON array of questions.",
          responseMimeType: "application/json",
          responseSchema: {
            type: import_genai.Type.OBJECT,
            properties: {
              questions: {
                type: import_genai.Type.ARRAY,
                items: {
                  type: import_genai.Type.OBJECT,
                  properties: {
                    id: { type: import_genai.Type.STRING },
                    text: { type: import_genai.Type.STRING },
                    type: { type: import_genai.Type.STRING, description: "mcq, short, long, case_study" },
                    marks: { type: import_genai.Type.NUMBER },
                    options: {
                      type: import_genai.Type.ARRAY,
                      items: { type: import_genai.Type.STRING }
                    },
                    answer: { type: import_genai.Type.STRING },
                    explanation: { type: import_genai.Type.STRING },
                    difficulty: { type: import_genai.Type.STRING },
                    chapter: { type: import_genai.Type.STRING }
                  },
                  required: ["id", "text", "marks", "answer"]
                }
              }
            },
            required: ["questions"]
          }
        }
      });
      const responseText = response.text || "{}";
      const data = JSON.parse(responseText);
      return res.json({
        success: true,
        questions: data.questions || []
      });
    } catch (error) {
      console.error("Error generating suggested questions:", error);
      return res.status(500).json({
        success: false,
        error: error.message || "Failed to generate suggested questions."
      });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Upian Pro] Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
//# sourceMappingURL=server.cjs.map
