import { NotificationItem, PaymentTransaction, QuestionPaper, SchoolBranding, UserProfile } from '../types';
import { INITIAL_BRANDING, INITIAL_NOTIFICATIONS, INITIAL_SAVED_PAPERS, INITIAL_USER } from '../data/mockData';

const USER_KEY = 'upian_pro_user';
const BRANDING_KEY = 'upian_pro_branding';
const PAPERS_KEY = 'upian_pro_papers';
const NOTIFICATIONS_KEY = 'upian_pro_notifications';
const TRANSACTIONS_KEY = 'upian_pro_transactions';
const AUTH_TOKEN_KEY = 'upian_pro_auth_token';

export const safeSavePapers = (papers: QuestionPaper[]): QuestionPaper[] => {
  let currentList = [...papers];
  while (currentList.length > 0) {
    try {
      localStorage.setItem(PAPERS_KEY, JSON.stringify(currentList));
      return currentList;
    } catch (e) {
      console.warn(`[storageService] Quota exceeded saving ${currentList.length} papers. Trimming oldest paper...`);
      if (currentList.length === 1) {
        // If even 1 paper exceeds quota, trim heavy explanation texts if necessary
        const single = currentList[0];
        const trimmedSingle = {
          ...single,
          sections: single.sections?.map(sec => ({
            ...sec,
            questions: sec.questions?.map(q => ({
              ...q,
              explanation: (q.explanation && q.explanation.length > 250) ? q.explanation.slice(0, 250) + '...' : q.explanation
            }))
          }))
        };
        try {
          localStorage.setItem(PAPERS_KEY, JSON.stringify([trimmedSingle]));
          return [trimmedSingle];
        } catch (innerErr) {
          console.error('[storageService] Failed to save paper even after trimming:', innerErr);
          return currentList;
        }
      }
      // Drop the oldest paper (last in array)
      currentList.pop();
    }
  }
  return papers;
};

export const getStoredUser = (): UserProfile => {
  const saved = localStorage.getItem(USER_KEY);
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      return {
        ...INITIAL_USER,
        ...parsed,
        credits: parsed.credits !== undefined ? parsed.credits : INITIAL_USER.credits,
        plan: parsed.plan || INITIAL_USER.plan,
        isUnlimited: parsed.isUnlimited !== undefined ? parsed.isUnlimited : INITIAL_USER.isUnlimited,
        papersGeneratedCount: parsed.papersGeneratedCount !== undefined ? parsed.papersGeneratedCount : INITIAL_USER.papersGeneratedCount
      };
    } catch (e) {
      console.error('Failed to parse user profile:', e);
    }
  }
  return INITIAL_USER;
};

export const saveStoredUser = (user: UserProfile) => {
  try {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  } catch (e) {
    console.warn('Failed to save user profile:', e);
  }
};

export const getStoredNotifications = (): NotificationItem[] => {
  const saved = localStorage.getItem(NOTIFICATIONS_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse notifications:', e);
    }
  }
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(INITIAL_NOTIFICATIONS));
  } catch (e) {
    console.warn('Quota exceeded setting initial notifications:', e);
  }
  return INITIAL_NOTIFICATIONS;
};

export const saveStoredNotifications = (notifications: NotificationItem[]) => {
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
  } catch (e) {
    console.warn('Failed to save notifications:', e);
  }
};

export const addStoredNotification = (notif: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>): NotificationItem[] => {
  const existing = getStoredNotifications();
  const newItem: NotificationItem = {
    ...notif,
    id: 'notif_' + Date.now(),
    timestamp: 'Just now',
    read: false
  };
  const updated = [newItem, ...existing];
  saveStoredNotifications(updated);
  return updated;
};

export const markNotificationAsRead = (id: string): NotificationItem[] => {
  const existing = getStoredNotifications();
  const updated = existing.map(n => n.id === id ? { ...n, read: true } : n);
  saveStoredNotifications(updated);
  return updated;
};

export const markAllNotificationsAsRead = (): NotificationItem[] => {
  const existing = getStoredNotifications();
  const updated = existing.map(n => ({ ...n, read: true }));
  saveStoredNotifications(updated);
  return updated;
};

export const getStoredBranding = (): SchoolBranding => {
  const saved = localStorage.getItem(BRANDING_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse branding:', e);
    }
  }
  return INITIAL_BRANDING;
};

export const saveStoredBranding = (branding: SchoolBranding) => {
  try {
    localStorage.setItem(BRANDING_KEY, JSON.stringify(branding));
  } catch (e) {
    console.warn('Failed to save branding:', e);
  }
};

export const getStoredPapers = (): QuestionPaper[] => {
  const saved = localStorage.getItem(PAPERS_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse saved papers:', e);
    }
  }
  // Initialize default mock papers
  try {
    localStorage.setItem(PAPERS_KEY, JSON.stringify(INITIAL_SAVED_PAPERS));
  } catch (e) {
    console.warn('Quota exceeded setting initial papers:', e);
  }
  return INITIAL_SAVED_PAPERS;
};

export const savePaper = (paper: QuestionPaper): QuestionPaper[] => {
  const existing = getStoredPapers();
  const index = existing.findIndex(p => p.id === paper.id);
  let updated: QuestionPaper[];
  if (index >= 0) {
    updated = [...existing];
    updated[index] = paper;
  } else {
    updated = [paper, ...existing];
  }
  return safeSavePapers(updated);
};

export const deletePaper = (id: string): QuestionPaper[] => {
  const existing = getStoredPapers();
  const updated = existing.filter(p => p.id !== id);
  return safeSavePapers(updated);
};

export const duplicatePaper = (id: string): QuestionPaper[] => {
  const existing = getStoredPapers();
  const target = existing.find(p => p.id === id);
  if (!target) return existing;

  const copy: QuestionPaper = {
    ...target,
    id: 'pap_' + Date.now(),
    title: `${target.title} (Copy)`,
    createdAt: new Date().toISOString(),
    status: 'draft'
  };

  const updated = [copy, ...existing];
  return safeSavePapers(updated);
};

export const isAuthenticated = (): boolean => {
  return localStorage.getItem(AUTH_TOKEN_KEY) === 'true';
};

export const setAuthSession = (authenticated: boolean) => {
  try {
    if (authenticated) {
      localStorage.setItem(AUTH_TOKEN_KEY, 'true');
    } else {
      localStorage.removeItem(AUTH_TOKEN_KEY);
    }
  } catch (e) {
    console.warn('Failed to set auth session:', e);
  }
};

const INITIAL_TRANSACTIONS: PaymentTransaction[] = [
  {
    id: 'txn_init_01',
    transactionId: 'TXN_9832104820',
    planName: 'Starter',
    amount: 99,
    credits: 30,
    paymentMethod: 'UPI (GPay)',
    status: 'Success',
    paymentDate: new Date(Date.now() - 15 * 86400000).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    }),
    expiryDate: new Date(Date.now() + 15 * 86400000).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric'
    })
  }
];

export const getStoredTransactions = (): PaymentTransaction[] => {
  const saved = localStorage.getItem(TRANSACTIONS_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse stored transactions:', e);
    }
  }
  try {
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(INITIAL_TRANSACTIONS));
  } catch (e) {
    console.warn('Quota exceeded setting initial transactions:', e);
  }
  return INITIAL_TRANSACTIONS;
};

export const saveStoredTransactions = (txns: PaymentTransaction[]) => {
  try {
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(txns));
  } catch (e) {
    console.warn('Failed to save transactions to localStorage:', e);
  }
};

export const addStoredTransaction = (txn: PaymentTransaction): PaymentTransaction[] => {
  const existing = getStoredTransactions();
  const updated = [txn, ...existing];
  saveStoredTransactions(updated);
  return updated;
};
