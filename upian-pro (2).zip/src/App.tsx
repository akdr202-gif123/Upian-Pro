import React, { useState, useEffect } from 'react';
import { ActiveTab, QuestionPaper, SchoolBranding, UserProfile, SubscriptionPlan, NotificationItem } from './types';
import { 
  getStoredUser, 
  saveStoredUser, 
  getStoredBranding, 
  saveStoredBranding, 
  getStoredPapers, 
  savePaper, 
  deletePaper, 
  duplicatePaper, 
  isAuthenticated, 
  setAuthSession,
  getStoredNotifications,
  addStoredNotification,
  markNotificationAsRead,
  markAllNotificationsAsRead
} from './services/storageService';
import { auth, onAuthStateChanged, db, collection, query, where, getDocs, doc, setDoc, deleteDoc } from './lib/firebase';

import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { AuthModal } from './components/AuthModal';
import { DashboardView } from './components/DashboardView';
import { AIGenerateView } from './components/AIGenerateView';
import { QuestionBankView } from './components/QuestionBankView';
import { SmartBuilderView } from './components/SmartBuilderView';
import { SavedPapersView } from './components/SavedPapersView';
import { SchoolBrandingView } from './components/SchoolBrandingView';
import { TeacherProfileView } from './components/TeacherProfileView';
import { ResourcesView } from './components/ResourcesView';
import { PremiumView } from './components/PremiumView';
import { HelpSupportView } from './components/HelpSupportView';
import { PaperPreviewModal } from './components/PaperPreviewModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [user, setUser] = useState<UserProfile>(getStoredUser());
  const [branding, setBranding] = useState<SchoolBranding>(getStoredBranding());
  const [papers, setPapers] = useState<QuestionPaper[]>(getStoredPapers());
  const [notifications, setNotifications] = useState<NotificationItem[]>(getStoredNotifications());
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(isAuthenticated());

  // Auth modal
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | 'forgot'>('login');

  // Preview paper modal
  const [activePreviewPaper, setActivePreviewPaper] = useState<QuestionPaper | null>(null);

  // Paper being edited in Smart Builder
  const [builderPaper, setBuilderPaper] = useState<QuestionPaper | null>(null);

  // Firebase Auth sync
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        setIsLoggedIn(true);
        setAuthSession(true);
        setUser((prev) => ({
          ...prev,
          fullName: fbUser.displayName || prev.fullName || 'Educator',
          email: fbUser.email || prev.email
        }));

        // Fetch user's papers from Firestore
        try {
          const q = query(collection(db, 'papers'), where('userId', '==', fbUser.uid));
          const snapshot = await getDocs(q);
          if (!snapshot.empty) {
            const fetchedPapers: QuestionPaper[] = [];
            snapshot.forEach((d) => {
              fetchedPapers.push({ id: d.id, ...d.data() } as QuestionPaper);
            });
            if (fetchedPapers.length > 0) {
              setPapers(fetchedPapers);
            }
          }
        } catch (e) {
          console.warn('Firestore papers fetch fallback to local:', e);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  const handleOpenAuth = (mode: 'login' | 'signup' | 'forgot') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleLoginSuccess = (updatedUser?: Partial<UserProfile>) => {
    if (updatedUser) {
      const merged = { ...user, ...updatedUser };
      setUser(merged);
      saveStoredUser(merged);
    }
    setIsLoggedIn(true);
    setAuthSession(true);

    const updatedNotifs = addStoredNotification({
      title: 'Welcome Back!',
      message: 'Logged in successfully. You have access to AI question generator & paper builder.',
      type: 'general'
    });
    setNotifications(updatedNotifs);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setAuthSession(false);
  };

  const handleSaveUser = (updatedUser: UserProfile) => {
    setUser(updatedUser);
    saveStoredUser(updatedUser);
    if (auth.currentUser) {
      setDoc(doc(db, 'users', auth.currentUser.uid), {
        uid: auth.currentUser.uid,
        name: updatedUser.fullName,
        email: updatedUser.email,
        schoolName: updatedUser.schoolName,
        credits: updatedUser.credits,
        isUnlimited: updatedUser.isUnlimited,
        updatedAt: new Date().toISOString()
      }, { merge: true }).catch(console.error);
    }
  };

  const handleSaveBranding = (updatedBranding: SchoolBranding) => {
    setBranding(updatedBranding);
    saveStoredBranding(updatedBranding);
  };

  const handleSavePaper = (paper: QuestionPaper) => {
    const updated = savePaper(paper);
    setPapers(updated);
    if (auth.currentUser) {
      const paperWithUser = {
        ...paper,
        userId: auth.currentUser.uid,
        updatedAt: new Date().toISOString()
      };
      setDoc(doc(db, 'papers', paper.id), paperWithUser, { merge: true }).catch(console.error);
    }
  };

  const handleDeletePaper = (id: string) => {
    const updated = deletePaper(id);
    setPapers(updated);
    if (auth.currentUser) {
      deleteDoc(doc(db, 'papers', id)).catch(console.error);
    }
  };

  const handleDuplicatePaper = (id: string) => {
    const updated = duplicatePaper(id);
    setPapers(updated);
  };

  // CREDITS & PAPER GENERATION ENFORCEMENT
  const handlePaperGenerated = (paper: QuestionPaper) => {
    if (!user.isUnlimited && user.credits <= 0) {
      alert('You have used all your credits (0 remaining). Please upgrade to a Premium Plan to generate more question papers.');
      setActiveTab('premium');
      return;
    }

    handleSavePaper(paper);
    setActivePreviewPaper(paper);

    // Deduct credit if not unlimited
    if (!user.isUnlimited) {
      const newCredits = Math.max(0, user.credits - 1);
      const newCount = user.papersGeneratedCount + 1;
      const updatedUser = {
        ...user,
        credits: newCredits,
        papersGeneratedCount: newCount
      };

      setUser(updatedUser);
      saveStoredUser(updatedUser);

      // Add Notification
      let notifType: NotificationItem['type'] = 'credit_deducted';
      let notifMsg = `Generated "${paper.title}". 1 credit deducted (${newCredits} credits remaining).`;

      if (newCredits < 5 && newCredits > 0) {
        notifType = 'credit_warning';
        notifMsg = `Low Credits Warning! Only ${newCredits} credits remaining. Upgrade plan to ensure uninterrupted access.`;
      } else if (newCredits === 0) {
        notifType = 'credit_warning';
        notifMsg = `Free Trial / Monthly Credits Exhausted (0 credits remaining). Subscribe to continue generating papers!`;
      }

      const notifs = addStoredNotification({
        title: notifType === 'credit_warning' ? 'Credit Alert' : 'Question Paper Generated',
        message: notifMsg,
        type: notifType
      });
      setNotifications(notifs);
    } else {
      const notifs = addStoredNotification({
        title: 'Question Paper Generated',
        message: `Generated "${paper.title}" under Unlimited Plan.`,
        type: 'paper_generated'
      });
      setNotifications(notifs);
    }
  };

  const handleUpgradePlan = (plan: SubscriptionPlan, newCredits: number) => {
    const isUnlimited = plan === 'Unlimited';
    const updatedUser: UserProfile = {
      ...user,
      plan,
      credits: isUnlimited ? 99999 : user.credits + newCredits,
      isUnlimited
    };

    setUser(updatedUser);
    saveStoredUser(updatedUser);

    const notifs = addStoredNotification({
      title: 'Plan Upgraded Successfully! 🎉',
      message: `You are now subscribed to the ${plan} Plan. ${isUnlimited ? 'Unlimited Paper Generation unlocked!' : `${newCredits} Credits added.`}`,
      type: 'plan_upgraded'
    });
    setNotifications(notifs);
  };

  const handleMarkAllNotificationsRead = () => {
    const updated = markAllNotificationsAsRead();
    setNotifications(updated);
  };

  const handleMarkNotificationRead = (id: string) => {
    const updated = markNotificationAsRead(id);
    setNotifications(updated);
  };

  const handleEditPaperInBuilder = (paper: QuestionPaper) => {
    setBuilderPaper(paper);
    setActiveTab('smart_builder');
  };

  return (
    <div className="min-h-screen max-w-full overflow-x-hidden bg-slate-50 text-slate-900 font-sans flex flex-col antialiased selection:bg-blue-100 selection:text-blue-900">
      
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        branding={branding}
        isLoggedIn={isLoggedIn}
        onOpenAuth={handleOpenAuth}
        onLogout={handleLogout}
        notifications={notifications}
        onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
        onMarkNotificationRead={handleMarkNotificationRead}
      />

      {/* Main Body Layout */}
      <div className="max-w-7xl mx-auto w-full flex-1 flex flex-col lg:flex-row">
        
        {/* Left Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          savedPapersCount={papers.length}
        />

        {/* Main Content View Area */}
        <main className="flex-1 p-3 sm:p-6 lg:p-8 min-w-0 pb-8">
          {activeTab === 'dashboard' && (
            <DashboardView
              user={user}
              branding={branding}
              papers={papers}
              setActiveTab={setActiveTab}
              onPreviewPaper={setActivePreviewPaper}
              onDuplicatePaper={handleDuplicatePaper}
              onDeletePaper={handleDeletePaper}
            />
          )}

          {activeTab === 'ai_generate' && (
            <AIGenerateView
              branding={branding}
              onPaperGenerated={handlePaperGenerated}
            />
          )}

          {activeTab === 'question_bank' && (
            <QuestionBankView
              branding={branding}
              onAssemblePaper={handlePaperGenerated}
            />
          )}

          {activeTab === 'smart_builder' && (
            <SmartBuilderView
              initialPaper={builderPaper}
              branding={branding}
              onSavePaper={handleSavePaper}
              onPreviewPaper={setActivePreviewPaper}
            />
          )}

          {activeTab === 'saved_papers' && (
            <SavedPapersView
              papers={papers}
              setActiveTab={setActiveTab}
              onPreviewPaper={setActivePreviewPaper}
              onEditPaper={handleEditPaperInBuilder}
              onDuplicatePaper={handleDuplicatePaper}
              onDeletePaper={handleDeletePaper}
            />
          )}

          {activeTab === 'premium' && (
            <PremiumView
              user={user}
              onUpgradePlan={handleUpgradePlan}
            />
          )}

          {activeTab === 'school_branding' && (
            <SchoolBrandingView
              branding={branding}
              onSaveBranding={handleSaveBranding}
            />
          )}

          {activeTab === 'teacher_profile' && (
            <TeacherProfileView
              user={user}
              onSaveUser={handleSaveUser}
            />
          )}

          {activeTab === 'resources' && (
            <ResourcesView />
          )}

          {activeTab === 'help_support' && (
            <HelpSupportView />
          )}
        </main>

      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        initialMode={authModalMode}
        onClose={() => setAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Paper Preview / Print Modal */}
      <PaperPreviewModal
        paper={activePreviewPaper}
        branding={branding}
        user={user}
        onClose={() => setActivePreviewPaper(null)}
        onSavePaper={handleSavePaper}
      />

    </div>
  );
}
