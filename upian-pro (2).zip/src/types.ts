export type BoardType = 
  | 'CBSE' 
  | 'ICSE' 
  | 'State Board (Maharashtra)' 
  | 'State Board (UP)' 
  | 'State Board (Delhi)' 
  | 'State Board (Karnataka)' 
  | 'State Board (Tamil Nadu)' 
  | 'Cambridge / IB';

export type ClassLevel = 
  | '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | '11' | '12'
  | 'NEET' | 'JNVST_6' | 'Pre-Primary' | 'JNVST_9' | 'CTET_2' | 'JEE_Advanced' | 'Competitive' | 'JEE_Main'
  | (string & {});

export type MediumType = 'English' | 'Hindi' | 'Hinglish' | 'Regional';

export type DifficultyLevel = 'Easy' | 'Medium' | 'Hard' | 'Balanced Mix';

export type QuestionType = 'mcq' | 'short' | 'long' | 'case_study' | 'true_false' | 'fill_blank' | 'numerical';

export interface Question {
  id: string;
  text: string;
  type: QuestionType;
  marks: number; // 1, 2, 3, 4, 5
  subject: string;
  classLevel: ClassLevel;
  chapter: string;
  board?: string;
  difficulty?: DifficultyLevel;
  options?: string[]; // For MCQs (A, B, C, D)
  answer: string;
  explanation?: string;
  diagramNote?: string;
  hasDiagram?: boolean;
  diagramUrl?: string; // High quality SVG data string, image URL, or uploaded data
  diagramCaption?: string;
  diagramWidth?: number; // Preference width in px
  answerDiagramUrl?: string; // Labelled version for answer key
  codeSnippet?: string;
  selected?: boolean;
}

export interface PaperSection {
  id: string;
  title: string; // e.g. "Section A: Multiple Choice Questions (1 Mark Each)"
  description?: string;
  questions: Question[];
}

export interface SchoolBranding {
  schoolName: string;
  tagline: string;
  address: string;
  affiliationNo: string;
  logoUrl: string;
  signatureUrl: string;
  watermarkText: string;
  watermarkOpacity: number; // 0.05 to 0.3
  headerTheme: 'classic' | 'modern' | 'minimal' | 'bordered';
  signatureTitle: string; // e.g., "Principal Signature"
}

export interface QuestionPaper {
  id: string;
  title: string;
  board: BoardType | string;
  classLevel: ClassLevel;
  subject: string;
  medium: MediumType;
  timeAllowedMinutes: number;
  totalMarks: number;
  createdMode: 'ai' | 'question_bank' | 'builder';
  createdAt: string;
  status: 'draft' | 'published';
  generalInstructions: string[];
  sections: PaperSection[];
  includeAnswerKey?: boolean;
  schoolBranding?: SchoolBranding;
}

export interface PaperGenerationConfig {
  board: BoardType;
  classLevel: ClassLevel;
  medium: MediumType;
  subject: string;
  chapters: string[];
  difficulty: DifficultyLevel;
  totalMarks: number;
  questionDistribution: {
    mcq1m: number;
    short2m: number;
    short3m: number;
    case4m: number;
    long5m: number;
  };
  customInstructions: string;
  includeAnswerKey: boolean;
  examTitle: string;
  timeAllowedMinutes: number;
}

export type SubscriptionPlan = 'Trial' | 'Starter' | 'Pro' | 'Unlimited';

export type PaymentStatus = 'Processing' | 'Success' | 'Failed' | 'Cancelled';

export interface PaymentTransaction {
  id: string;
  transactionId: string;
  planName: SubscriptionPlan;
  amount: number;
  credits: number;
  paymentMethod: string;
  status: PaymentStatus;
  paymentDate: string;
  expiryDate: string;
  failureReason?: string;
}

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  role: 'Teacher' | 'Principal' | 'Exam Controller' | 'Coaching Admin';
  schoolName: string;
  subjectExpertise: string[];
  board: BoardType;
  phone: string;
  avatarUrl: string;
  experienceYears: number;
  bio: string;
  defaultTimeAllowed: number;
  defaultWatermark: string;
  plan: SubscriptionPlan;
  credits: number; // 3 free for trial, 30 for Starter, 50 for Pro, 99999 for Unlimited
  isUnlimited: boolean;
  papersGeneratedCount: number;
}

export type NotificationType = 
  | 'success' 
  | 'warning' 
  | 'info' 
  | 'alert' 
  | 'general' 
  | 'credit_deducted' 
  | 'credit_warning' 
  | 'paper_generated' 
  | 'plan_upgraded';

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: NotificationType;
  actionTab?: ActiveTab;
}

export type ResourceCategory = 
  | 'NCERT Books' 
  | 'Previous Year Papers' 
  | 'Short Notes' 
  | 'Handwritten Notes' 
  | 'Sample Papers' 
  | 'Worksheets';

export interface ResourceMaterial {
  id: string;
  title: string;
  category: ResourceCategory;
  board: string;
  classLevel: ClassLevel;
  subject: string;
  chapter?: string;
  downloads: number;
  fileSize: string;
  dateAdded: string;
  description: string;
  pdfUrl?: string;
}

export type ActiveTab = 
  | 'dashboard' 
  | 'ai_generate' 
  | 'question_bank' 
  | 'smart_builder' 
  | 'saved_papers' 
  | 'school_branding' 
  | 'resources' 
  | 'premium'
  | 'teacher_profile' 
  | 'help_support';
