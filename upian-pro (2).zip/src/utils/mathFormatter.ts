export function cleanLatexToUnicode(text: string): string {
  if (!text || typeof text !== "string") return text;

  let s = text;

  // 0. Remove raw LaTeX math delimiters ($...$, $$...$$, \(...\), \[...\])
  s = s.replace(/\$\$([\s\S]*?)\$\$/g, "$1")
       .replace(/\$([^$]+)\$/g, "$1")
       .replace(/\\\[([\s\S]*?)\\\]/g, "$1")
       .replace(/\\\(([\s\S]*?)\\\)/g, "$1");

  // 1. Remove LaTeX text formatting commands
  s = s.replace(/\\(text|mathrm|mathbf|mathit|mathsf|cal)\{([^}]*)\}/g, "$2");

  // 2. Remove \left and \right modifiers
  s = s.replace(/\\left\s*/g, "").replace(/\\right\s*/g, "");

  // 3. Convert \frac{A}{B} fractions recursively
  let limit = 0;
  while (/\\frac\{([^{}]+)\}\{([^{}]+)\}/.test(s) && limit < 10) {
    limit++;
    s = s.replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, (_match, num, den) => {
      const n = num.trim();
      const d = den.trim();
      if (n === "1" && d === "2") return "½";
      if (n === "1" && d === "4") return "¼";
      if (n === "3" && d === "4") return "¾";
      if (n === "\\mu_0" && d === "4\\pi") return "(μ₀ / 4π)";
      if (n === "1" && d === "4\\pi\\varepsilon_0") return "(1 / 4πε₀)";
      if (n === "1" && d === "4\\pi\\epsilon_0") return "(1 / 4πε₀)";
      return `(${n} / ${d})`;
    });
  }
  s = s.replace(/\\frac\s+([a-zA-Z0-9\\]+)\s+([a-zA-Z0-9\\]+)/g, "($1 / $2)");

  // 4. Vector and unit vector transformations
  const vectorChars: Record<string, string> = {
    'B': '𝐁', 'E': '𝐄', 'F': '𝐅', 'v': '𝐯', 'p': '𝐩', 'r': '𝐫', 'l': '𝐥',
    'A': '𝐀', 'J': '𝐉', 'D': '𝐃', 'a': '𝐚', 'k': '𝐤', 'M': '𝐌', 'P': '𝐏'
  };

  s = s.replace(/\\vec\{([a-zA-Z])\}/g, (_m, char) => vectorChars[char] || `${char}⃗`);
  s = s.replace(/\\vec\s+([a-zA-Z])/g, (_m, char) => vectorChars[char] || `${char}⃗`);

  // Unit vectors: \hat{r} -> r̂, \hat{i} -> î, \hat{j} -> ĵ, \hat{k} -> k̂, \hat{n} -> n̂
  s = s.replace(/\\hat\{([a-zA-Z])\}/g, "$1̂");
  s = s.replace(/\\hat\s+([a-zA-Z])/g, "$1̂");

  // Specific length/field element combinations
  s = s.replace(/\bd\\vec\{l\}\b|\bd\\vec\s+l\b/g, "d𝐥");
  s = s.replace(/\bd\\vec\{B\}\b|\bd\\vec\s+B\b/g, "d𝐁");
  s = s.replace(/\bd\\vec\{E\}\b|\bd\\vec\s+E\b/g, "d𝐄");

  // 5. Greek symbols & Constants
  s = s.replace(/\\mu_0|\\mu_\{0\}|\\mu0/g, "μ₀");
  s = s.replace(/\\mu/g, "μ");
  s = s.replace(/\\pi/g, "π");
  s = s.replace(/\\epsilon_0|\\varepsilon_0|\\epsilon_\{0\}|\\varepsilon_\{0\}/g, "ε₀");
  s = s.replace(/\\epsilon|\\varepsilon/g, "ε");
  s = s.replace(/\\theta/g, "θ");
  s = s.replace(/\\lambda/g, "λ");
  s = s.replace(/\\alpha/g, "α");
  s = s.replace(/\\beta/g, "β");
  s = s.replace(/\\gamma/g, "γ");
  s = s.replace(/\\delta/g, "δ");
  s = s.replace(/\\Delta/g, "Δ");
  s = s.replace(/\\sigma/g, "σ");
  s = s.replace(/\\Sigma/g, "Σ");
  s = s.replace(/\\omega/g, "ω");
  s = s.replace(/\\Omega/g, "Ω");
  s = s.replace(/\\phi|\\varphi/g, "ϕ");
  s = s.replace(/\\Phi/g, "Φ");
  s = s.replace(/\\psi/g, "ψ");
  s = s.replace(/\\Psi/g, "Ψ");
  s = s.replace(/\\rho/g, "ρ");
  s = s.replace(/\\tau/g, "τ");
  s = s.replace(/\\chi/g, "χ");
  s = s.replace(/\\nu_0|\\nu_\{0\}/g, "ν₀");
  s = s.replace(/\\nu/g, "ν");

  // 6. Operators & Mathematical Relations
  s = s.replace(/\\times/g, "×");
  s = s.replace(/\\cdot/g, "·");
  s = s.replace(/\\pm/g, "±");
  s = s.replace(/\\mp/g, "∓");
  s = s.replace(/\\le|\\leq/g, "≤");
  s = s.replace(/\\ge|\\geq/g, "≥");
  s = s.replace(/\\neq/g, "≠");
  s = s.replace(/\\approx/g, "≈");
  s = s.replace(/\\infty/g, "∞");
  s = s.replace(/\\propto/g, "∝");
  s = s.replace(/\\degree|\^\\circ|\^\{\\circ\}/g, "°");
  s = s.replace(/\\sqrt\{([^}]*)\}/g, "√($1)");

  // 7. Superscripts and Subscripts
  s = s.replace(/\^\{?-1\}?/g, "⁻¹");
  s = s.replace(/\^\{?-2\}?/g, "⁻²");
  s = s.replace(/\^\{?-3\}?/g, "⁻³");
  s = s.replace(/\^\{?0\}?/g, "⁰");
  s = s.replace(/\^\{?1\}?/g, "¹");
  s = s.replace(/\^\{?2\}?/g, "²");
  s = s.replace(/\^\{?3\}?/g, "³");
  s = s.replace(/\^\{?4\}?/g, "⁴");
  s = s.replace(/\^\{?5\}?/g, "⁵");
  s = s.replace(/\^\{?6\}?/g, "⁶");
  s = s.replace(/\^\{?7\}?/g, "⁷");
  s = s.replace(/\^\{?8\}?/g, "⁸");
  s = s.replace(/\^\{?9\}?/g, "⁹");

  s = s.replace(/_\{?0\}?/g, "₀");
  s = s.replace(/_\{?1\}?/g, "₁");
  s = s.replace(/_\{?2\}?/g, "₂");
  s = s.replace(/_\{?3\}?/g, "₃");
  s = s.replace(/_\{?4\}?/g, "₄");
  s = s.replace(/_\{?5\}?/g, "₅");
  s = s.replace(/_\{?6\}?/g, "₆");
  s = s.replace(/_\{?7\}?/g, "₇");
  s = s.replace(/_\{?8\}?/g, "₈");
  s = s.replace(/_\{?9\}?/g, "₉");
  s = s.replace(/_\{?a\}?/g, "ₐ");
  s = s.replace(/_\{?e\}?/g, "ₑ");
  s = s.replace(/_\{?m\}?/g, "ₘ");
  s = s.replace(/_\{?n\}?/g, "ₙ");
  s = s.replace(/_\{?p\}?/g, "ₚ");
  s = s.replace(/_\{?r\}?/g, "ᵣ");
  s = s.replace(/_\{?t\}?/g, "ₜ");
  s = s.replace(/_\{?x\}?/g, "ₓ");

  // 8. Clean remaining backslashes before words
  s = s.replace(/\\([a-zA-Z]+)/g, "$1");
  s = s.replace(/\\/g, "");

  // Normalize spacing
  s = s.replace(/[ \t]+/g, " ").trim();

  return s;
}
