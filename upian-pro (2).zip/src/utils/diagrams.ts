/**
 * High quality vector (SVG) diagram templates for education paper generation.
 * Print-ready, crisp, fully vector-scaled for web preview & PDF export.
 */

export interface DiagramTemplate {
  id: string;
  title: string;
  subject: string;
  category: string;
  svg: string; // Vector SVG markup
  answerSvg?: string; // Labelled solution SVG markup
}

export const DIAGRAM_TEMPLATES: Record<string, DiagramTemplate> = {
  // 1. MATHEMATICS: RIGHT TRIANGLE (PYTHAGORAS & TRIGONOMETRY)
  math_right_triangle: {
    id: 'math_right_triangle',
    title: 'Right-Angled Triangle (ABC)',
    subject: 'Mathematics',
    category: 'Geometry & Trigonometry',
    svg: `<svg viewBox="0 0 400 260" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#1e293b"/>
        </marker>
      </defs>
      <!-- Triangle ABC -->
      <polygon points="60,200 320,200 60,40" fill="#f1f5f9" stroke="#0f172a" stroke-width="3.5" stroke-linejoin="round"/>
      <!-- Right angle marker at B -->
      <path d="M 60,180 L 80,180 L 80,200" fill="none" stroke="#2563eb" stroke-width="2.5"/>
      <circle cx="70" cy="190" r="2.5" fill="#2563eb"/>
      
      <!-- Angle Theta at C -->
      <path d="M 280,200 A 40 40 0 0 0 295,183" fill="none" stroke="#dc2626" stroke-width="2.5"/>
      <text x="268" y="192" font-family="sans-serif" font-size="14" font-weight="bold" fill="#dc2626">θ</text>

      <!-- Labels for Vertices -->
      <text x="45" y="35" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0f172a">A</text>
      <text x="45" y="222" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0f172a">B (90°)</text>
      <text x="330" y="215" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0f172a">C</text>

      <!-- Side Labels -->
      <text x="25" y="125" font-family="sans-serif" font-size="13" font-weight="bold" fill="#2563eb">Height (h = 12 cm)</text>
      <text x="160" y="225" font-family="sans-serif" font-size="13" font-weight="bold" fill="#2563eb">Base (b = 5 cm)</text>
      <text x="195" y="110" font-family="sans-serif" font-size="13" font-weight="bold" fill="#059669" transform="rotate(-30 195,110)">Hypotenuse (AC)</text>
    </svg>`,
    answerSvg: `<svg viewBox="0 0 400 260" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <polygon points="60,200 320,200 60,40" fill="#eff6ff" stroke="#1d4ed8" stroke-width="3.5" stroke-linejoin="round"/>
      <path d="M 60,180 L 80,180 L 80,200" fill="none" stroke="#2563eb" stroke-width="2.5"/>
      <circle cx="70" cy="190" r="2.5" fill="#2563eb"/>
      <text x="45" y="35" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0f172a">A</text>
      <text x="45" y="222" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0f172a">B</text>
      <text x="330" y="215" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0f172a">C</text>
      <text x="20" y="125" font-family="sans-serif" font-size="12" font-weight="bold" fill="#1e40af">AB = 12 cm</text>
      <text x="160" y="225" font-family="sans-serif" font-size="12" font-weight="bold" fill="#1e40af">BC = 5 cm</text>
      <text x="165" y="105" font-family="sans-serif" font-size="13" font-weight="bold" fill="#dc2626">AC = √(12² + 5²) = 13 cm</text>
    </svg>`
  },

  // 2. MATHEMATICS: CIRCLE WITH TANGENTS FROM EXTERNAL POINT
  math_circle_tangents: {
    id: 'math_circle_tangents',
    title: 'Circle Tangents from External Point P',
    subject: 'Mathematics',
    category: 'Circles & Geometry',
    svg: `<svg viewBox="0 0 420 250" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Circle with Center O -->
      <circle cx="260" cy="125" r="75" fill="#f8fafc" stroke="#0f172a" stroke-width="3"/>
      <circle cx="260" cy="125" r="4" fill="#0f172a"/>
      <text x="268" y="120" font-family="sans-serif" font-size="14" font-weight="bold" fill="#0f172a">O</text>

      <!-- External Point P -->
      <circle cx="60" cy="125" r="5" fill="#dc2626"/>
      <text x="40" y="130" font-family="sans-serif" font-size="16" font-weight="bold" fill="#dc2626">P</text>

      <!-- Tangent Points A and B -->
      <!-- Tangent PA -->
      <line x1="60" y1="125" x2="220" y2="61" stroke="#2563eb" stroke-width="3"/>
      <circle cx="220" cy="61" r="4" fill="#2563eb"/>
      <text x="215" y="45" font-family="sans-serif" font-size="15" font-weight="bold" fill="#2563eb">A</text>

      <!-- Tangent PB -->
      <line x1="60" y1="125" x2="220" y2="189" stroke="#2563eb" stroke-width="3"/>
      <circle cx="220" cy="189" r="4" fill="#2563eb"/>
      <text x="215" y="210" font-family="sans-serif" font-size="15" font-weight="bold" fill="#2563eb">B</text>

      <!-- Radii OA and OB -->
      <line x1="260" y1="125" x2="220" y2="61" stroke="#64748b" stroke-width="2" stroke-dasharray="4"/>
      <line x1="260" y1="125" x2="220" y2="189" stroke="#64748b" stroke-width="2" stroke-dasharray="4"/>

      <!-- Center line PO -->
      <line x1="60" y1="125" x2="260" y2="125" stroke="#059669" stroke-width="2" stroke-dasharray="6"/>

      <!-- Right Angle symbols -->
      <path d="M 228,74 L 217,81 L 209,68" fill="none" stroke="#dc2626" stroke-width="1.8"/>
      <path d="M 228,176 L 217,169 L 209,182" fill="none" stroke="#dc2626" stroke-width="1.8"/>

      <text x="120" y="85" font-family="sans-serif" font-size="12" font-weight="bold" fill="#2563eb">PA (Tangent 1)</text>
      <text x="120" y="175" font-family="sans-serif" font-size="12" font-weight="bold" fill="#2563eb">PB (Tangent 2)</text>
      <text x="235" y="90" font-family="sans-serif" font-size="11" font-weight="bold" fill="#64748b">r</text>
    </svg>`,
    answerSvg: `<svg viewBox="0 0 420 250" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <circle cx="260" cy="125" r="75" fill="#f0fdf4" stroke="#059669" stroke-width="3"/>
      <circle cx="260" cy="125" r="4" fill="#0f172a"/>
      <line x1="60" y1="125" x2="220" y2="61" stroke="#2563eb" stroke-width="3.5"/>
      <line x1="60" y1="125" x2="220" y2="189" stroke="#2563eb" stroke-width="3.5"/>
      <line x1="260" y1="125" x2="220" y2="61" stroke="#dc2626" stroke-width="2.5"/>
      <line x1="260" y1="125" x2="220" y2="189" stroke="#dc2626" stroke-width="2.5"/>
      <line x1="60" y1="125" x2="260" y2="125" stroke="#059669" stroke-width="2" stroke-dasharray="4"/>
      <text x="40" y="130" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0f172a">P</text>
      <text x="268" y="120" font-family="sans-serif" font-size="14" font-weight="bold" fill="#0f172a">O</text>
      <text x="215" y="45" font-family="sans-serif" font-size="15" font-weight="bold" fill="#2563eb">A</text>
      <text x="215" y="210" font-family="sans-serif" font-size="15" font-weight="bold" fill="#2563eb">B</text>
      <text x="130" y="30" font-family="sans-serif" font-size="12" font-weight="bold" fill="#059669">PA = PB = 12 cm (Equal Tangents)</text>
      <text x="245" y="80" font-family="sans-serif" font-size="12" font-weight="bold" fill="#dc2626">OA ⊥ PA (90°)</text>
    </svg>`
  },

  // 3. MATHEMATICS: CYLINDER & CONE (3D GEOMETRY)
  math_3d_cylinder_cone: {
    id: 'math_3d_cylinder_cone',
    title: 'Solid Cone Surmounting Cylinder',
    subject: 'Mathematics',
    category: 'Surface Areas & Volumes',
    svg: `<svg viewBox="0 0 360 280" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Cone Top -->
      <polygon points="180,30 100,120 260,120" fill="#fef3c7" stroke="#0f172a" stroke-width="3"/>
      
      <!-- Junction Ellipse -->
      <ellipse cx="180" cy="120" rx="80" ry="20" fill="#fde68a" stroke="#0f172a" stroke-width="2.5"/>

      <!-- Cylinder Body -->
      <rect x="100" y="120" width="160" height="110" fill="#e0f2fe" stroke="#0f172a" stroke-dasharray="none" stroke-width="3"/>
      <!-- Re-draw side borders cleanly -->
      <line x1="100" y1="120" x2="100" y2="230" stroke="#0f172a" stroke-width="3"/>
      <line x1="260" y1="120" x2="260" y2="230" stroke="#0f172a" stroke-width="3"/>

      <!-- Bottom Ellipse -->
      <ellipse cx="180" cy="230" rx="80" ry="20" fill="#bae6fd" stroke="#0f172a" stroke-width="2.5"/>

      <!-- Axis and Heights -->
      <line x1="180" y1="30" x2="180" y2="230" stroke="#dc2626" stroke-width="2" stroke-dasharray="5"/>
      <line x1="180" y1="230" x2="260" y2="230" stroke="#2563eb" stroke-width="2.5"/>

      <!-- Dimensions Text -->
      <text x="210" y="248" font-family="sans-serif" font-size="13" font-weight="bold" fill="#2563eb">r = 7 cm</text>
      <text x="185" y="80" font-family="sans-serif" font-size="12" font-weight="bold" fill="#d97706">h₁ = 6 cm</text>
      <text x="185" y="180" font-family="sans-serif" font-size="12" font-weight="bold" fill="#0284c7">h₂ = 10 cm</text>
      <text x="225" y="70" font-family="sans-serif" font-size="12" font-weight="bold" fill="#0f172a">Slant l</text>
    </svg>`
  },

  // 4. SCIENCE / PHYSICS: ELECTRIC CIRCUIT DIAGRAM
  physics_electric_circuit: {
    id: 'physics_electric_circuit',
    title: 'Electric Circuit (Ohm\'s Law Setup)',
    subject: 'Physics',
    category: 'Electricity & Circuits',
    svg: `<svg viewBox="0 0 450 260" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Main Loop Line -->
      <rect x="50" y="40" width="350" height="180" fill="none" stroke="#0f172a" stroke-width="3.5" rx="10"/>

      <!-- Resistor R1 (Zigzag) -->
      <rect x="180" y="30" width="90" height="20" fill="#ffffff"/>
      <path d="M 180,40 L 190,25 L 202,55 L 214,25 L 226,55 L 238,25 L 250,55 L 260,40" fill="none" stroke="#2563eb" stroke-dasharray="none" stroke-width="3.5"/>
      <text x="200" y="18" font-family="sans-serif" font-size="14" font-weight="bold" fill="#2563eb">R = 10 Ω</text>

      <!-- Voltmeter V (Parallel to Resistor) -->
      <line x1="160" y1="40" x2="160" y2="90" stroke="#0f172a" stroke-width="2.5"/>
      <line x1="310" y1="40" x2="310" y2="90" stroke="#0f172a" stroke-width="2.5"/>
      <line x1="160" y1="90" x2="310" y2="90" stroke="#0f172a" stroke-width="2.5"/>
      <circle cx="235" cy="90" r="18" fill="#ffffff" stroke="#dc2626" stroke-width="3"/>
      <text x="229" y="96" font-family="sans-serif" font-size="16" font-weight="bold" fill="#dc2626">V</text>

      <!-- Ammeter A (In series on right wire) -->
      <circle cx="400" cy="130" r="18" fill="#ffffff" stroke="#059669" stroke-width="3"/>
      <text x="393" y="136" font-family="sans-serif" font-size="16" font-weight="bold" fill="#059669">A</text>

      <!-- Battery / Voltage Source (Bottom wire) -->
      <rect x="180" y="210" width="80" height="20" fill="#ffffff"/>
      <line x1="200" y1="205" x2="200" y2="235" stroke="#0f172a" stroke-width="4"/>
      <line x1="212" y1="212" x2="212" y2="228" stroke="#0f172a" stroke-width="2"/>
      <line x1="224" y1="205" x2="224" y2="235" stroke="#0f172a" stroke-width="4"/>
      <line x1="236" y1="212" x2="236" y2="228" stroke="#0f172a" stroke-width="2"/>
      <text x="210" y="250" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">Battery (V = 12V)</text>
      <text x="185" y="200" font-family="sans-serif" font-size="12" font-weight="bold" fill="#dc2626">+</text>
      <text x="245" y="200" font-family="sans-serif" font-size="12" font-weight="bold" fill="#2563eb">-</text>

      <!-- Plug Key / Switch (Left wire) -->
      <circle cx="50" cy="110" r="4" fill="#0f172a"/>
      <circle cx="50" cy="150" r="4" fill="#0f172a"/>
      <line x1="50" y1="110" x2="50" y2="148" stroke="#059669" stroke-width="3.5"/>
      <text x="15" y="135" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">Key (K)</text>

      <!-- Current Flow Arrows -->
      <path d="M 120 40 L 135 40" stroke="#dc2626" stroke-width="3" marker-end="url(#arrow)"/>
      <text x="110" y="28" font-family="sans-serif" font-size="12" font-weight="bold" fill="#dc2626">I (Current)</text>
    </svg>`
  },

  // 5. SCIENCE / PHYSICS: RAY DIAGRAM (CONVEX LENS)
  physics_convex_lens: {
    id: 'physics_convex_lens',
    title: 'Convex Lens Ray Diagram (Object at 2F)',
    subject: 'Physics',
    category: 'Ray Optics & Light',
    svg: `<svg viewBox="0 0 500 240" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Principal Axis -->
      <line x1="20" y1="120" x2="480" y2="120" stroke="#64748b" stroke-width="2" stroke-dasharray="6"/>
      <text x="440" y="110" font-family="sans-serif" font-size="11" fill="#64748b">Principal Axis</text>

      <!-- Lens Body -->
      <path d="M 250,20 Q 225,120 250,220 Q 275,120 250,20 Z" fill="#dbeafe" stroke="#2563eb" stroke-width="3" opacity="0.85"/>
      <line x1="250" y1="20" x2="250" y2="220" stroke="#2563eb" stroke-width="1.5" stroke-dasharray="3"/>

      <!-- Focal Points & Center -->
      <!-- Left side -->
      <circle cx="170" cy="120" r="3.5" fill="#0f172a"/>
      <text x="165" y="140" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">F₁</text>

      <circle cx="90" cy="120" r="3.5" fill="#0f172a"/>
      <text x="80" y="140" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">2F₁</text>

      <!-- Right side -->
      <circle cx="330" cy="120" r="3.5" fill="#0f172a"/>
      <text x="325" y="140" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">F₂</text>

      <circle cx="410" cy="120" r="3.5" fill="#0f172a"/>
      <text x="400" y="140" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">2F₂</text>

      <!-- Center O -->
      <text x="242" y="140" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">O</text>

      <!-- Object Arrow AB at 2F1 -->
      <line x1="90" y1="120" x2="90" y2="50" stroke="#dc2626" stroke-width="4"/>
      <polygon points="90,40 82,53 98,53" fill="#dc2626"/>
      <text x="82" y="32" font-family="sans-serif" font-size="14" font-weight="bold" fill="#dc2626">A (Object)</text>
      <text x="82" y="160" font-family="sans-serif" font-size="13" font-weight="bold" fill="#dc2626">B</text>

      <!-- Parallel Ray 1 from Object to Lens then through F2 -->
      <line x1="90" y1="50" x2="250" y2="50" stroke="#059669" stroke-width="2.5"/>
      <line x1="250" y1="50" x2="410" y2="190" stroke="#059669" stroke-width="2.5"/>

      <!-- Ray 2 through Optical Center O -->
      <line x1="90" y1="50" x2="410" y2="190" stroke="#d97706" stroke-width="2.5"/>

      <!-- Inverted Image Arrow A'B' at 2F2 -->
      <line x1="410" y1="120" x2="410" y2="190" stroke="#dc2626" stroke-width="4"/>
      <polygon points="410,200 402,187 418,187" fill="#dc2626"/>
      <text x="405" y="218" font-family="sans-serif" font-size="14" font-weight="bold" fill="#dc2626">A' (Image)</text>
      <text x="405" y="110" font-family="sans-serif" font-size="13" font-weight="bold" fill="#dc2626">B'</text>
    </svg>`
  },

  // 6. BIOLOGY: PLANT CELL DIAGRAM
  biology_plant_cell: {
    id: 'biology_plant_cell',
    title: 'Structure of a Plant Cell',
    subject: 'Biology',
    category: 'Cell Biology',
    svg: `<svg viewBox="0 0 460 280" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Rigid Outer Cell Wall -->
      <polygon points="60,20 400,20 440,240 20,240" fill="#dcfce7" stroke="#16a34a" stroke-width="6" stroke-linejoin="round"/>
      <polygon points="68,28 392,28 430,232 30,232" fill="#f0fdf4" stroke="#22c55e" stroke-width="3" stroke-linejoin="round"/>

      <!-- Large Central Vacuole -->
      <ellipse cx="230" cy="140" rx="100" ry="60" fill="#e0f2fe" stroke="#0284c7" stroke-width="2.5"/>
      <text x="180" y="145" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0369a1">Large Vacuole</text>

      <!-- Nucleus -->
      <circle cx="100" cy="90" r="35" fill="#fbcfe8" stroke="#db2777" stroke-width="3"/>
      <circle cx="100" cy="90" r="14" fill="#9d174d"/>
      <text x="70" y="140" font-family="sans-serif" font-size="12" font-weight="bold" fill="#9d174d">Nucleus</text>

      <!-- Chloroplasts -->
      <ellipse cx="330" cy="70" rx="22" ry="12" fill="#86efac" stroke="#15803d" stroke-width="2"/>
      <line x1="315" y1="70" x2="345" y2="70" stroke="#15803d" stroke-width="1.5"/>
      <text x="310" y="50" font-family="sans-serif" font-size="11" font-weight="bold" fill="#15803d">Chloroplast</text>

      <ellipse cx="360" cy="180" rx="22" ry="12" fill="#86efac" stroke="#15803d" stroke-width="2"/>

      <!-- Mitochondria -->
      <ellipse cx="120" cy="190" rx="20" ry="10" fill="#fde68a" stroke="#d97706" stroke-width="2"/>
      <path d="M 105,190 Q 120,185 135,190" fill="none" stroke="#d97706" stroke-width="1.5"/>
      <text x="80" y="215" font-family="sans-serif" font-size="11" font-weight="bold" fill="#b45309">Mitochondrion</text>

      <!-- Cell Wall Pointer -->
      <line x1="390" y1="20" x2="430" y2="10" stroke="#16a34a" stroke-width="2"/>
      <text x="350" y="12" font-family="sans-serif" font-size="12" font-weight="bold" fill="#15803d">Rigid Cell Wall</text>
    </svg>`
  },

  // 7. BIOLOGY: HUMAN HEART (4 CHAMBERS)
  biology_human_heart: {
    id: 'biology_human_heart',
    title: 'Schematic Diagram of Human Heart',
    subject: 'Biology',
    category: 'Human Physiology & Circulation',
    svg: `<svg viewBox="0 0 420 280" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Outer Heart Chamber Box Outline -->
      <rect x="70" y="30" width="280" height="210" rx="24" fill="#fff1f2" stroke="#be123c" stroke-width="4"/>

      <!-- Septum Dividing Left and Right -->
      <line x1="210" y1="30" x2="210" y2="240" stroke="#9f1239" stroke-width="8"/>

      <!-- Horizontal Partition Dividing Atria & Ventricles -->
      <line x1="70" y1="120" x2="350" y2="120" stroke="#be123c" stroke-width="4"/>

      <!-- Right Atrium (Top Left Box) -->
      <rect x="80" y="40" width="120" height="70" fill="#dbeafe" rx="10"/>
      <text x="95" y="75" font-family="sans-serif" font-size="14" font-weight="bold" fill="#1e40af">Right Atrium</text>
      <text x="100" y="95" font-family="sans-serif" font-size="11" fill="#3b82f6">(Deoxygenated)</text>

      <!-- Left Atrium (Top Right Box) -->
      <rect x="220" y="40" width="120" height="70" fill="#ffe4e6" rx="10"/>
      <text x="240" y="75" font-family="sans-serif" font-size="14" font-weight="bold" fill="#9f1239">Left Atrium</text>
      <text x="245" y="95" font-family="sans-serif" font-size="11" fill="#e11d48">(Oxygenated)</text>

      <!-- Right Ventricle (Bottom Left Box) -->
      <rect x="80" y="135" width="120" height="95" fill="#bfdbfe" rx="10"/>
      <text x="90" y="180" font-family="sans-serif" font-size="14" font-weight="bold" fill="#1e3a8a">Right Ventricle</text>

      <!-- Left Ventricle (Bottom Right Box - Thicker Wall) -->
      <rect x="220" y="135" width="120" height="95" fill="#fecdd3" rx="10"/>
      <text x="235" y="180" font-family="sans-serif" font-size="14" font-weight="bold" fill="#881337">Left Ventricle</text>
      <text x="235" y="200" font-family="sans-serif" font-size="10" font-weight="bold" fill="#be123c">(Thick Muscular Wall)</text>

      <!-- Arrows showing blood flow -->
      <path d="M 140,110 L 140,130" stroke="#2563eb" stroke-width="3" marker-end="url(#arrow)"/>
      <path d="M 280,110 L 280,130" stroke="#dc2626" stroke-width="3" marker-end="url(#arrow)"/>

      <text x="120" y="260" font-family="sans-serif" font-size="12" font-weight="bold" fill="#0f172a">Interventricular Septum</text>
    </svg>`
  },

  // 8. GEOGRAPHY: MAP CONTOUR / TOPOGRAPHIC ELEVATION
  geography_contour_map: {
    id: 'geography_contour_map',
    title: 'Topographic Contour Lines & River Basin',
    subject: 'Geography',
    category: 'Map Reading & Topography',
    svg: `<svg viewBox="0 0 420 250" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Outer Map Grid Frame -->
      <rect x="20" y="20" width="380" height="210" fill="#fcfcfc" stroke="#0f172a" stroke-width="3"/>

      <!-- Contour Line 100m -->
      <ellipse cx="200" cy="125" rx="160" ry="85" fill="none" stroke="#b45309" stroke-width="2"/>
      <text x="330" y="130" font-family="sans-serif" font-size="10" font-weight="bold" fill="#b45309">100m</text>

      <!-- Contour Line 200m -->
      <ellipse cx="190" cy="120" rx="120" ry="60" fill="none" stroke="#b45309" stroke-width="2"/>
      <text x="280" y="125" font-family="sans-serif" font-size="10" font-weight="bold" fill="#b45309">200m</text>

      <!-- Contour Line 300m -->
      <ellipse cx="180" cy="115" rx="80" ry="40" fill="none" stroke="#b45309" stroke-width="2.5"/>
      <text x="230" y="120" font-family="sans-serif" font-size="10" font-weight="bold" fill="#b45309">300m</text>

      <!-- Peak 450m Δ -->
      <polygon points="170,105 163,115 177,115" fill="#dc2626"/>
      <text x="182" y="112" font-family="sans-serif" font-size="12" font-weight="bold" fill="#dc2626">Peak (450m)</text>

      <!-- River Path crossing contours -->
      <path d="M 50,30 Q 110,80 150,140 T 260,220" fill="none" stroke="#0284c7" stroke-width="3.5"/>
      <text x="60" y="45" font-family="sans-serif" font-size="12" font-weight="bold" fill="#0284c7">River Indus Branch</text>

      <!-- Scale bar -->
      <rect x="280" y="195" width="100" height="8" fill="#0f172a"/>
      <rect x="330" y="195" width="50" height="8" fill="#ffffff" stroke="#0f172a"/>
      <text x="280" y="190" font-family="sans-serif" font-size="10" font-weight="bold" fill="#0f172a">0</text>
      <text x="325" y="190" font-family="sans-serif" font-size="10" font-weight="bold" fill="#0f172a">5 km</text>
      <text x="370" y="190" font-family="sans-serif" font-size="10" font-weight="bold" fill="#0f172a">10 km</text>
    </svg>`
  },

  // 9. ECONOMICS: DEMAND & SUPPLY GRAPH
  economics_demand_supply: {
    id: 'economics_demand_supply',
    title: 'Market Demand & Supply Equilibrium Graph',
    subject: 'Economics',
    category: 'Microeconomics',
    svg: `<svg viewBox="0 0 420 260" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- Axes -->
      <line x1="60" y1="20" x2="60" y2="210" stroke="#0f172a" stroke-width="3"/>
      <line x1="60" y1="210" x2="390" y2="210" stroke="#0f172a" stroke-width="3"/>

      <text x="15" y="115" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a" transform="rotate(-90 20,115)">Price (P)</text>
      <text x="190" y="245" font-family="sans-serif" font-size="13" font-weight="bold" fill="#0f172a">Quantity (Q)</text>

      <!-- Demand Curve D (Downward sloping) -->
      <line x1="80" y1="40" x2="360" y2="190" stroke="#dc2626" stroke-width="3.5"/>
      <text x="368" y="195" font-family="sans-serif" font-size="14" font-weight="bold" fill="#dc2626">D</text>

      <!-- Supply Curve S (Upward sloping) -->
      <line x1="80" y1="190" x2="360" y2="40" stroke="#2563eb" stroke-width="3.5"/>
      <text x="368" y="45" font-family="sans-serif" font-size="14" font-weight="bold" fill="#2563eb">S</text>

      <!-- Equilibrium Point E (Intersection) -->
      <circle cx="220" cy="115" r="6" fill="#059669"/>
      <text x="230" y="110" font-family="sans-serif" font-size="15" font-weight="bold" fill="#059669">E (Equilibrium)</text>

      <!-- Dotted lines to axes -->
      <line x1="220" y1="115" x2="60" y2="115" stroke="#64748b" stroke-dasharray="4" stroke-width="2"/>
      <line x1="220" y1="115" x2="220" y2="210" stroke="#64748b" stroke-dasharray="4" stroke-width="2"/>

      <text x="30" y="120" font-family="sans-serif" font-size="12" font-weight="bold" fill="#059669">P*</text>
      <text x="212" y="230" font-family="sans-serif" font-size="12" font-weight="bold" fill="#059669">Q*</text>
    </svg>`
  },

  // 10. COMPUTER SCIENCE: FLOWCHART
  cs_flowchart: {
    id: 'cs_flowchart',
    title: 'Flowchart: Check Even or Odd Number',
    subject: 'Computer Science',
    category: 'Algorithms & Logic',
    svg: `<svg viewBox="0 0 380 300" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="background:#ffffff;">
      <!-- START Oval -->
      <rect x="130" y="15" width="120" height="36" rx="18" fill="#dbeafe" stroke="#1d4ed8" stroke-width="3"/>
      <text x="170" y="38" font-family="sans-serif" font-size="13" font-weight="bold" fill="#1e40af">START</text>

      <!-- Arrow 1 -->
      <line x1="190" y1="51" x2="190" y2="75" stroke="#0f172a" stroke-width="2.5" marker-end="url(#arrow)"/>

      <!-- Input N (Parallelogram) -->
      <polygon points="120,75 270,75 250,110 100,110" fill="#fef3c7" stroke="#d97706" stroke-width="3"/>
      <text x="135" y="98" font-family="sans-serif" font-size="12" font-weight="bold" fill="#b45309">Input Number N</text>

      <!-- Arrow 2 -->
      <line x1="185" y1="110" x2="185" y2="135" stroke="#0f172a" stroke-width="2.5"/>

      <!-- Decision Diamond: N % 2 == 0 -->
      <polygon points="185,135 270,170 185,205 100,170" fill="#fce7f3" stroke="#be185d" stroke-width="3"/>
      <text x="140" y="174" font-family="sans-serif" font-size="11" font-weight="bold" fill="#9d174d">Is N % 2 == 0?</text>

      <!-- Output Even (Right) -->
      <line x1="270" y1="170" x2="310" y2="170" stroke="#059669" stroke-width="2.5"/>
      <text x="275" y="162" font-family="sans-serif" font-size="10" font-weight="bold" fill="#059669">Yes</text>
      <polygon points="300,195 375,195 365,225 290,225" fill="#d1fae5" stroke="#059669" stroke-width="2"/>
      <text x="302" y="213" font-family="sans-serif" font-size="10" font-weight="bold" fill="#047857">Print "EVEN"</text>

      <!-- Output Odd (Down) -->
      <line x1="185" y1="205" x2="185" y2="230" stroke="#dc2626" stroke-width="2.5"/>
      <text x="192" y="220" font-family="sans-serif" font-size="10" font-weight="bold" fill="#dc2626">No</text>
      <polygon points="120,230 250,230 235,260 105,260" fill="#fee2e2" stroke="#dc2626" stroke-width="2"/>
      <text x="132" y="248" font-family="sans-serif" font-size="10" font-weight="bold" fill="#b91c1c">Print "ODD"</text>

      <!-- END Oval -->
      <rect x="210" y="270" width="100" height="28" rx="14" fill="#e2e8f0" stroke="#475569" stroke-width="2"/>
      <text x="245" y="288" font-family="sans-serif" font-size="12" font-weight="bold" fill="#334155">END</text>
    </svg>`
  }
};

/**
 * Get vector diagram for subject/chapter or default fallback
 */
export const getDiagramForTopic = (subject: string, chapter: string): DiagramTemplate | null => {
  const subLower = subject.toLowerCase();
  const chapLower = chapter.toLowerCase();

  if (subLower.includes('math')) {
    if (chapLower.includes('trig') || chapLower.includes('triangle') || chapLower.includes('height')) {
      return DIAGRAM_TEMPLATES.math_right_triangle;
    }
    if (chapLower.includes('circle') || chapLower.includes('tangent')) {
      return DIAGRAM_TEMPLATES.math_circle_tangents;
    }
    if (chapLower.includes('surface') || chapLower.includes('volume') || chapLower.includes('cylinder') || chapLower.includes('cone')) {
      return DIAGRAM_TEMPLATES.math_3d_cylinder_cone;
    }
    return DIAGRAM_TEMPLATES.math_right_triangle;
  }

  if (subLower.includes('physic') || subLower.includes('science')) {
    if (chapLower.includes('electric') || chapLower.includes('current') || chapLower.includes('circuit')) {
      return DIAGRAM_TEMPLATES.physics_electric_circuit;
    }
    if (chapLower.includes('optics') || chapLower.includes('light') || chapLower.includes('lens') || chapLower.includes('mirror')) {
      return DIAGRAM_TEMPLATES.physics_convex_lens;
    }
  }

  if (subLower.includes('biolog') || subLower.includes('life')) {
    if (chapLower.includes('heart') || chapLower.includes('circulation') || chapLower.includes('blood')) {
      return DIAGRAM_TEMPLATES.biology_human_heart;
    }
    return DIAGRAM_TEMPLATES.biology_plant_cell;
  }

  if (subLower.includes('geograph') || subLower.includes('social')) {
    return DIAGRAM_TEMPLATES.geography_contour_map;
  }

  if (subLower.includes('economic')) {
    return DIAGRAM_TEMPLATES.economics_demand_supply;
  }

  if (subLower.includes('computer') || subLower.includes('code') || subLower.includes('python')) {
    return DIAGRAM_TEMPLATES.cs_flowchart;
  }

  return null;
};
