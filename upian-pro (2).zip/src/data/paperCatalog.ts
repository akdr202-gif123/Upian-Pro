export interface PaperCategory {
  id: string;
  name: string;
  badge?: string;
  type: 'school' | 'competitive' | 'entrance' | 'preprimary';
  generationRules: string;
  subjects: string[];
}

export const PAPER_CATEGORIES: PaperCategory[] = [
  {
    id: '1',
    name: 'Class 1',
    type: 'school',
    generationRules: 'Follow NCERT curriculum and CBSE/ICSE primary pattern.',
    subjects: ['English', 'Mathematics', 'EVS', 'Drawing', 'Reasoning']
  },
  {
    id: '2',
    name: 'Class 2',
    type: 'school',
    generationRules: 'Follow NCERT curriculum and CBSE/ICSE primary pattern.',
    subjects: ['English', 'Mathematics', 'Science', 'EVS', 'Drawing']
  },
  {
    id: '3',
    name: 'Class 3',
    type: 'school',
    generationRules: 'Follow NCERT curriculum and CBSE/ICSE elementary pattern.',
    subjects: ['English', 'Mathematics', 'EVS', 'General Knowledge', 'Drawing']
  },
  {
    id: '4',
    name: 'Class 4',
    type: 'school',
    generationRules: 'Follow NCERT curriculum and latest syllabus updates.',
    subjects: ['English', 'Mathematics', 'EVS', 'Science', 'Social Studies']
  },
  {
    id: '5',
    name: 'Class 5',
    type: 'school',
    generationRules: 'Follow NCERT curriculum and latest syllabus updates.',
    subjects: ['English', 'Mathematics', 'EVS', 'Science', 'Social Studies', 'Hindi']
  },
  {
    id: '6',
    name: 'Class 6',
    type: 'school',
    generationRules: 'Follow NCERT curriculum with CBSE and ICSE board standards.',
    subjects: ['English', 'Mathematics', 'Science', 'Social Science', 'Hindi', 'Sanskrit', 'Computer']
  },
  {
    id: '7',
    name: 'Class 7',
    type: 'school',
    generationRules: 'Follow latest NCERT curriculum and competency-based questions.',
    subjects: ['English', 'Mathematics', 'Science', 'Social Science', 'Hindi', 'Sanskrit', 'Computer']
  },
  {
    id: '8',
    name: 'Class 8',
    type: 'school',
    generationRules: 'Follow latest NCERT curriculum and competency-based questions.',
    subjects: ['English', 'Mathematics', 'Science', 'Social Science', 'Hindi', 'Sanskrit', 'Computer']
  },
  {
    id: '9',
    name: 'Class 9',
    type: 'school',
    generationRules: 'Follow latest NCERT curriculum, CBSE question paper pattern and ICSE style.',
    subjects: ['Mathematics', 'Science', 'Social Studies', 'English', 'Hindi', 'Computer Science', 'Information Technology']
  },
  {
    id: '10',
    name: 'Class 10',
    type: 'school',
    badge: 'Board Class',
    generationRules: 'Follow latest NCERT curriculum, official CBSE board pattern, competency-based case studies and assertion-reasoning questions.',
    subjects: ['Mathematics', 'Science', 'Social Studies', 'English', 'Hindi', 'Information Technology', 'Computer Applications']
  },
  {
    id: '11',
    name: 'Class 11',
    type: 'school',
    generationRules: 'Follow latest NCERT curriculum, CBSE senior secondary pattern.',
    subjects: ['Physics', 'Chemistry', 'Mathematics', 'Biology', 'English', 'Accountancy', 'Business Studies', 'Economics', 'Computer Science', 'Physical Education']
  },
  {
    id: '12',
    name: 'Class 12',
    type: 'school',
    badge: 'Board Class',
    generationRules: 'Follow latest NCERT curriculum, official CBSE board exam pattern with high-order thinking competency questions.',
    subjects: ['Physics', 'Chemistry', 'Mathematics', 'Biology', 'English', 'Accountancy', 'Business Studies', 'Economics', 'Computer Science', 'Physical Education']
  },
  {
    id: 'JEE_Main',
    name: 'JEE Main',
    type: 'entrance',
    badge: 'NTA JEE',
    generationRules: '75 Questions total (Physics: 25, Chemistry: 25, Math: 25) | 300 Marks | 180 Mins | Each subject has Sec A (20 MCQs, 4 marks each) & Sec B (5 Qs, 4 marks each).',
    subjects: ['All Subjects (PCM)', 'Physics', 'Chemistry', 'Mathematics']
  },
  {
    id: 'JEE_Advanced',
    name: 'JEE Advanced',
    type: 'entrance',
    badge: 'IIT JEE',
    generationRules: 'Paper 1 (51 Qs, 180 Marks, 180 Mins: 21 MCQs only; per subject Sec A 4x3m, Sec B 3x4m, Sec C 6x4m, Sec D 4x3m) | Paper 2 (54 Qs, 180 Marks, 180 Mins: 36 MCQs only with paragraph based; per subject Sec A 6x3m, Sec B 3x4m, Sec C 3x4m, Sec D 6x3m).',
    subjects: ['Paper 1 (PCM - 51 Qs)', 'Paper 2 (PCM - 54 Qs)', 'Physics', 'Chemistry', 'Mathematics']
  },
  {
    id: 'NEET_UG',
    name: 'NEET UG',
    type: 'entrance',
    badge: 'Medical',
    generationRules: '180 Questions total (Biology: 90 Qs [Botany 45 + Zoology 45], Physics: 45 Qs, Chemistry: 45 Qs) | 720 Marks | 180 Mins | All MCQs (4 marks each).',
    subjects: ['All Subjects (PCB)', 'Biology (Botany & Zoology)', 'Botany', 'Zoology', 'Physics', 'Chemistry']
  },
  {
    id: 'CUET_UG',
    name: 'CUET UG',
    type: 'entrance',
    badge: 'NTA CUET',
    generationRules: 'Subject-wise Paper | 50 Questions (All MCQs, 5 marks each) | 250 Marks | 60 Mins.',
    subjects: ['English', 'General Test', 'Physics', 'Chemistry', 'Mathematics', 'Botany', 'Zoology', 'Accountancy', 'Business Studies', 'Economics']
  },
  {
    id: 'NDA_NA',
    name: 'NDA & NA',
    type: 'entrance',
    badge: 'UPSC NDA',
    generationRules: 'Paper 1: Mathematics (120 Qs, 300 Marks, 150 Mins) | Paper 2: General Ability Test GAT (150 Qs, 600 Marks, 150 Mins).',
    subjects: ['Paper 1: Mathematics (120 Qs)', 'Paper 2: General Ability Test GAT (150 Qs)', 'Physics', 'Chemistry', 'English', 'General Science', 'History & Geography']
  }
];

export function getCategoryById(id: string): PaperCategory | undefined {
  return PAPER_CATEGORIES.find((cat) => cat.id === id || cat.name === id);
}

export function getSubjectsForCategory(categoryIdOrName: string): string[] {
  const cat = getCategoryById(categoryIdOrName);
  if (cat && cat.subjects.length > 0) {
    return cat.subjects;
  }
  // Default fallback subjects
  return ['Mathematics', 'Science', 'English', 'Social Science', 'Hindi'];
}
