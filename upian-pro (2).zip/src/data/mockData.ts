import { NotificationItem, Question, QuestionPaper, ResourceMaterial, SchoolBranding, UserProfile } from '../types';
import { DIAGRAM_TEMPLATES } from '../utils/diagrams';

export const INITIAL_USER: UserProfile = {
  id: 'usr_101',
  fullName: 'Dr. Rajesh Sharma',
  email: 'rajesh.sharma@dpsvk.edu.in',
  role: 'Teacher',
  schoolName: 'Delhi Public School, Vasant Kunj',
  subjectExpertise: ['Physics', 'Mathematics', 'General Science'],
  board: 'CBSE',
  phone: '+91 98765 43210',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
  experienceYears: 14,
  bio: 'Senior Physics PGT & Academic Exam Controller with 14+ years of CBSE evaluation experience.',
  defaultTimeAllowed: 180,
  defaultWatermark: 'DPS VASANT KUNJ - CONFIDENTIAL',
  plan: 'Trial',
  credits: 3, // 3 free trial generations for new users
  isUnlimited: false,
  papersGeneratedCount: 0
};

export const INITIAL_BRANDING: SchoolBranding = {
  schoolName: 'DELHI PUBLIC SCHOOL, VASANT KUNJ',
  tagline: 'Service Before Self | Affiliated to CBSE New Delhi',
  address: 'Sector C, Pocket 5, Vasant Kunj, New Delhi - 110070',
  affiliationNo: 'CBSE / AFF / 2730182',
  logoUrl: 'https://images.unsplash.com/photo-1592280771190-3e2e4d571952?auto=format&fit=crop&q=80&w=200',
  signatureUrl: 'https://images.unsplash.com/photo-1600132806370-bf17e65e942f?auto=format&fit=crop&q=80&w=300',
  watermarkText: 'DPS VASANT KUNJ - EXAMINATION DEPT',
  watermarkOpacity: 0.08,
  headerTheme: 'classic',
  signatureTitle: 'Controller of Examinations'
};

export const MOCK_QUESTION_BANK: Question[] = [
  // 1 MARK QUESTIONS
  {
    id: 'qb_1m_01',
    text: 'In the electric circuit shown below, identify the device connected in parallel with resistor R:',
    type: 'mcq',
    marks: 1,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'Electricity',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['Ammeter (A)', 'Voltmeter (V)', 'Plug Key (K)', 'Galvanometer'],
    answer: 'Voltmeter (V)',
    hasDiagram: true,
    diagramUrl: DIAGRAM_TEMPLATES.physics_electric_circuit.svg,
    diagramCaption: 'Figure 1: Electric Circuit with Resistor, Voltmeter, and Ammeter',
    explanation: 'A Voltmeter is always connected in parallel across the resistor to measure potential difference.'
  },
  {
    id: 'qb_1m_02',
    text: 'In the convex lens ray diagram given below, when an object is placed at 2F₁, where is the image formed?',
    type: 'mcq',
    marks: 1,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'Ray Optics',
    board: 'CBSE',
    difficulty: 'Medium',
    options: ['At F₂', 'At 2F₂', 'Between F₂ and 2F₂', 'At Infinity'],
    answer: 'At 2F₂',
    hasDiagram: true,
    diagramUrl: DIAGRAM_TEMPLATES.physics_convex_lens.svg,
    diagramCaption: 'Figure 2: Ray Diagram for Convex Lens with Object at 2F₁',
    explanation: 'When an object is placed at 2F₁, a real, inverted, same-sized image is formed at 2F₂.'
  },
  {
    id: 'qb_1m_03',
    text: 'The balanced chemical equation for reaction between Sodium and Water is:',
    type: 'mcq',
    marks: 1,
    subject: 'Chemistry',
    classLevel: '10',
    chapter: 'Chemical Reactions and Equations',
    board: 'CBSE',
    difficulty: 'Easy',
    options: [
      'Na + H2O → NaOH + H2',
      '2Na + 2H2O → 2NaOH + H2',
      '2Na + H2O → Na2O + H2',
      'Na + 2H2O → NaOH2 + H'
    ],
    answer: '2Na + 2H2O → 2NaOH + H2',
    explanation: '2 moles of Sodium react with 2 moles of Water to yield 2 moles of Sodium Hydroxide and 1 mole of Hydrogen gas.'
  },
  {
    id: 'qb_1m_04',
    text: 'If matrix A is of order 2x3 and matrix B is of order 3x4, what is the order of matrix AB?',
    type: 'mcq',
    marks: 1,
    subject: 'Mathematics',
    classLevel: '12',
    chapter: 'Matrices & Determinants',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['2x4', '3x3', '4x2', 'Not defined'],
    answer: '2x4',
    explanation: 'Product AB of (m x n) and (n x p) matrix results in a matrix of order (m x p) = 2x4.'
  },
  {
    id: 'qb_1m_05',
    text: 'Study the plant cell diagram below and identify the organelle labelled as the large central storage reservoir:',
    type: 'mcq',
    marks: 1,
    subject: 'Biology',
    classLevel: '9',
    chapter: 'The Fundamental Unit of Life',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['Nucleus', 'Large Vacuole', 'Chloroplast', 'Mitochondria'],
    answer: 'Large Vacuole',
    hasDiagram: true,
    diagramUrl: DIAGRAM_TEMPLATES.biology_plant_cell.svg,
    diagramCaption: 'Figure 3: Plant Cell Diagram showing organelle structures',
    explanation: 'The large central vacuole occupies 50-90% of plant cell volume, providing turgidity.'
  },
  {
    id: 'qb_1m_07_diag',
    text: 'In the right-angled triangle ABC shown below, if base BC = 5 cm and height AB = 12 cm, calculate the length of hypotenuse AC:',
    type: 'mcq',
    marks: 1,
    subject: 'Mathematics',
    classLevel: '10',
    chapter: 'Introduction to Trigonometry',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['10 cm', '13 cm', '15 cm', '17 cm'],
    answer: '13 cm',
    hasDiagram: true,
    diagramUrl: DIAGRAM_TEMPLATES.math_right_triangle.svg,
    diagramCaption: 'Figure 4: Right Triangle ABC with Base 5 cm and Height 12 cm',
    explanation: 'By Pythagoras Theorem: AC = √(AB² + BC²) = √(12² + 5²) = √(144 + 25) = √169 = 13 cm.'
  },
  {
    id: 'qb_1m_06',
    text: 'Assertion (A): Blue light scatters more than red light in Earth’s atmosphere.\nReason (R): Rayleigh scattering intensity is inversely proportional to the fourth power of wavelength.',
    type: 'mcq',
    marks: 1,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'The Human Eye and the Colorful World',
    board: 'CBSE',
    difficulty: 'Hard',
    options: [
      'Both A and R are true, and R is the correct explanation of A.',
      'Both A and R are true, but R is NOT the correct explanation of A.',
      'A is true, but R is false.',
      'A is false, but R is true.'
    ],
    answer: 'Both A and R are true, and R is the correct explanation of A.',
    explanation: 'S ∝ 1/λ⁴. Since blue has a shorter wavelength than red, it scatters substantially more.'
  },

  // 2 MARKS QUESTIONS
  {
    id: 'qb_2m_01',
    text: 'Define Ohm’s Law. Write its mathematical formula and state one limitation.',
    type: 'short',
    marks: 2,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'Electricity',
    board: 'CBSE',
    difficulty: 'Easy',
    answer: 'Ohm’s Law states that electric current flowing through a conductor is directly proportional to potential difference across its ends, provided temperature remains constant. V = IR.\nLimitation: It does not hold for non-ohmic devices like semiconductors and diodes.',
    explanation: '1 mark for statement and formula, 1 mark for limitation.'
  },
  {
    id: 'qb_2m_02',
    text: 'Why does acidic solution conduct electricity whereas distilled water does not?',
    type: 'short',
    marks: 2,
    subject: 'Chemistry',
    classLevel: '10',
    chapter: 'Acids, Bases and Salts',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: 'Acidic solutions dissociate in water to produce free H+ (H3O+) ions which carry electric charge. Distilled water is pure and contains no free ions to conduct electricity.',
    explanation: 'Key points: Presence of H+ ions in acid vs absence of free ions in distilled water.'
  },
  {
    id: 'qb_2m_03',
    text: 'Find the derivative of f(x) = sin(x²) with respect to x using chain rule.',
    type: 'short',
    marks: 2,
    subject: 'Mathematics',
    classLevel: '12',
    chapter: 'Continuity & Differentiability',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: 'd/dx [sin(x²)] = cos(x²) · d/dx(x²) = 2x · cos(x²).',
    explanation: 'Apply derivative of outer function multiplied by derivative of inner function x².'
  },

  // 3 MARKS QUESTIONS
  {
    id: 'qb_3m_01',
    text: 'An object 5 cm in length is placed 25 cm away from a converging lens of focal length 10 cm. Find the position, size, and nature of the image formed.',
    type: 'short',
    marks: 3,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'Light - Reflection and Refraction',
    board: 'CBSE',
    difficulty: 'Hard',
    answer: 'Given u = -25 cm, f = +10 cm, h1 = 5 cm.\nLens formula: 1/f = 1/v - 1/u ⇒ 1/10 = 1/v + 1/25 ⇒ 1/v = 1/10 - 1/25 = 3/50 ⇒ v = 16.67 cm.\nMagnification m = v/u = 16.67 / (-25) = -0.667.\nImage height h2 = m × h1 = -3.33 cm.\nNature: Real, inverted, and diminished image formed 16.67 cm behind the lens.',
    explanation: '1 mark for formula substitution, 1 mark for v calculation, 1 mark for nature and size.'
  },
  {
    id: 'qb_3m_02',
    text: 'Differentiate between Aerobic and Anaerobic respiration on the basis of: (a) Oxygen requirement, (b) End products formed, and (c) Energy released in ATP.',
    type: 'short',
    marks: 3,
    subject: 'Biology',
    classLevel: '10',
    chapter: 'Life Processes',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: '(a) Aerobic requires O2; Anaerobic occurs in absence of O2.\n(b) Aerobic yields CO2 + H2O; Anaerobic yields Lactic acid or Ethanol + CO2.\n(c) Aerobic yields 38 ATP; Anaerobic yields only 2 ATP per glucose molecule.',
    explanation: '1 mark for each comparative distinction.'
  },

  // 4 MARKS QUESTIONS (CASE STUDY)
  {
    id: 'qb_4m_01',
    text: 'CASE STUDY: A convex spherical lens is used in optical magnifying glasses, camera viewfinders, and human eye corrections.\n(i) State Rayleigh’s condition for image sharpness.\n(ii) A person cannot see distant objects beyond 1.2 m clearly. Name the defect of vision and specify the lens required for correction.',
    type: 'case_study',
    marks: 4,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'The Human Eye and the Colorful World',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: '(i) Rayleigh condition states that two point sources are just resolved when maximum of one diffraction pattern coincides with first minimum of other.\n(ii) The defect is Myopia (Nearsightedness). It is corrected using a Concave lens of focal length f = -1.2 m (Power P = -0.83 D).',
    explanation: '2 marks for theoretical optics, 2 marks for vision defect calculations.'
  },

  // 5 MARKS QUESTIONS
  {
    id: 'qb_5m_01',
    text: 'State Ampere’s Circuital Law. Derive an expression for the magnetic field along the axis of a long current-carrying solenoid inside it.',
    type: 'long',
    marks: 5,
    subject: 'Physics',
    classLevel: '12',
    chapter: 'Moving Charges and Magnetism',
    board: 'CBSE',
    difficulty: 'Hard',
    answer: 'Statement: The line integral of magnetic field B around any closed loop is equal to μ₀ times total net current enclosed.\nDerivation: Consider rectangular Amperian loop abcd inside solenoid...\nB = μ₀ n I, where n is number of turns per unit length.',
    explanation: '1.5 marks for statement & loop diagram, 3.5 marks for complete step-by-step integral derivation.'
  },

  // ADDITIONAL PREBUILT BANK QUESTIONS
  {
    id: 'qb_1m_07',
    text: 'What is the speed of light in vacuum?',
    type: 'mcq',
    marks: 1,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'Light - Reflection and Refraction',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['3 × 10⁸ m/s', '3 × 10⁶ m/s', '3 × 10¹⁰ m/s', '3 × 10⁵ m/s'],
    answer: '3 × 10⁸ m/s',
    explanation: 'Standard speed of electromagnetic waves in vacuum.'
  },
  {
    id: 'qb_1m_08',
    text: 'The functional unit of kidney is called:',
    type: 'mcq',
    marks: 1,
    subject: 'Biology',
    classLevel: '10',
    chapter: 'Life Processes',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['Neuron', 'Nephron', 'Alveoli', 'Glomerulus'],
    answer: 'Nephron',
    explanation: 'Nephrons filter blood and produce urine in human kidneys.'
  },
  {
    id: 'qb_1m_09',
    text: 'Which gas is evolved when zinc reacts with dilute sulphuric acid?',
    type: 'mcq',
    marks: 1,
    subject: 'Chemistry',
    classLevel: '10',
    chapter: 'Chemical Reactions and Equations',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['Oxygen', 'Hydrogen', 'Carbon dioxide', 'Nitrogen'],
    answer: 'Hydrogen',
    explanation: 'Zn + H2SO4 → ZnSO4 + H2↑. Hydrogen gas burns with a pop sound.'
  },
  {
    id: 'qb_1m_10',
    text: 'Evaluate: lim(x→0) [sin(x) / x]',
    type: 'mcq',
    marks: 1,
    subject: 'Mathematics',
    classLevel: '12',
    chapter: 'Limits & Continuity',
    board: 'CBSE',
    difficulty: 'Easy',
    options: ['0', '1', 'Infinity', 'Undefined'],
    answer: '1',
    explanation: 'Standard trigonometric limit formula.'
  },
  {
    id: 'qb_2m_04',
    text: 'State two differences between a real image and a virtual image.',
    type: 'short',
    marks: 2,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'Light - Reflection and Refraction',
    board: 'CBSE',
    difficulty: 'Easy',
    answer: '1. Real images are formed by actual intersection of rays and can be taken on screen. 2. Virtual images are formed when rays appear to diverge and cannot be taken on screen.',
    explanation: '1 mark per distinct point.'
  },
  {
    id: 'qb_2m_05',
    text: 'What is double circulation in human beings? Why is it necessary?',
    type: 'short',
    marks: 2,
    subject: 'Biology',
    classLevel: '10',
    chapter: 'Life Processes',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: 'Double circulation means blood flows through the heart twice during one complete cycle (Pulmonary + Systemic). It prevents mixing of oxygenated and deoxygenated blood, ensuring efficient oxygen delivery.',
    explanation: '1 mark for definition, 1 mark for biological importance.'
  },
  {
    id: 'qb_3m_03',
    text: 'Explain the principle, construction, and working of an AC Generator with a neat labeled diagram.',
    type: 'short',
    marks: 3,
    subject: 'Physics',
    classLevel: '12',
    chapter: 'Electromagnetic Induction',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: 'Principle: Electromagnetic Induction (Faraday’s Law).\nWorking: Rectangular coil rotated in magnetic field cuts lines of force, inducing alternating EMF.\nDiagram: Armature, magnetic poles, slip rings, carbon brushes.',
    explanation: '1 mark diagram, 1 mark principle, 1 mark working steps.'
  },
  {
    id: 'qb_4m_02',
    text: 'CASE STUDY: Electric power distribution in households uses parallel connection instead of series connection.\n(i) Why are domestic circuits connected in parallel?\n(ii) An electric iron of resistance 20 Ω takes a current of 5 A. Calculate the heat developed in 30 seconds.',
    type: 'case_study',
    marks: 4,
    subject: 'Physics',
    classLevel: '10',
    chapter: 'Electricity',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: '(i) Parallel connection ensures independent operation and same voltage (220V) across all appliances.\n(ii) Heat H = I² R t = (5)² × 20 × 30 = 25 × 600 = 15,000 Joules (15 kJ).',
    explanation: '2 marks for conceptual explanation, 2 marks for numerical calculation.'
  },
  {
    id: 'qb_5m_02',
    text: '(a) Explain the mechanism of photosynthesis with balanced chemical equation.\n(b) Describe an experiment to demonstrate that chlorophyll is essential for photosynthesis.',
    type: 'long',
    marks: 5,
    subject: 'Biology',
    classLevel: '10',
    chapter: 'Life Processes',
    board: 'CBSE',
    difficulty: 'Medium',
    answer: '(a) 6CO2 + 12H2O --(Sunlight/Chlorophyll)--> C6H12O6 + 6O2 + 6H2O. Steps: Light absorption, water splitting, CO2 reduction.\n(b) Variegated leaf experiment (Croton/Coleus): De-starch plant, expose to sunlight, test for starch with Iodine. Only green parts turn blue-black.',
    explanation: '2 marks equation & steps, 3 marks detailed experimental procedure.'
  }
];

export const INITIAL_SAVED_PAPERS: QuestionPaper[] = [
  {
    id: 'pap_101',
    title: 'Class 10 Science Mid-Term Examination 2026-27',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Science',
    medium: 'English',
    timeAllowedMinutes: 180,
    totalMarks: 80,
    createdMode: 'ai',
    createdAt: '2026-07-20T10:30:00.000Z',
    status: 'published',
    generalInstructions: [
      'This question paper consists of 39 questions in 5 sections.',
      'All questions are compulsory. Internal choice is provided in selected questions.',
      'Section A consists of 16 Objective type questions carrying 1 mark each.',
      'Section B consists of 6 Short Answer type I questions carrying 2 marks each.',
      'Section C consists of 7 Short Answer type II questions carrying 3 marks each.',
      'Section D consists of 3 Case-Based questions carrying 4 marks each.',
      'Section E consists of 3 Long Answer questions carrying 5 marks each.'
    ],
    sections: [
      {
        id: 'sec_a',
        title: 'SECTION A - Objective & Multiple Choice Questions (1 Mark Each)',
        questions: [MOCK_QUESTION_BANK[0], MOCK_QUESTION_BANK[1], MOCK_QUESTION_BANK[3]]
      },
      {
        id: 'sec_b',
        title: 'SECTION B - Short Answer Type I Questions (2 Marks Each)',
        questions: [MOCK_QUESTION_BANK[6], MOCK_QUESTION_BANK[7]]
      },
      {
        id: 'sec_c',
        title: 'SECTION C - Short Answer Type II Questions (3 Marks Each)',
        questions: [MOCK_QUESTION_BANK[9], MOCK_QUESTION_BANK[10]]
      },
      {
        id: 'sec_d',
        title: 'SECTION D - Case-Study & Source Based Questions (4 Marks Each)',
        questions: [MOCK_QUESTION_BANK[11]]
      },
      {
        id: 'sec_e',
        title: 'SECTION E - Long Answer Questions (5 Marks Each)',
        questions: [MOCK_QUESTION_BANK[12]]
      }
    ],
    includeAnswerKey: true,
    schoolBranding: INITIAL_BRANDING
  },
  {
    id: 'pap_102',
    title: 'Class 12 Physics Unit Test - Electromagnetism',
    board: 'CBSE',
    classLevel: '12',
    subject: 'Physics',
    medium: 'English',
    timeAllowedMinutes: 90,
    totalMarks: 40,
    createdMode: 'builder',
    createdAt: '2026-07-22T14:15:00.000Z',
    status: 'draft',
    generalInstructions: [
      'Attempt all questions carefully.',
      'Calculators are not permitted. Log tables may be provided if required.'
    ],
    sections: [
      {
        id: 'sec_a',
        title: 'SECTION A - MCQs',
        questions: [MOCK_QUESTION_BANK[1]]
      },
      {
        id: 'sec_b',
        title: 'SECTION B - Long Derivations',
        questions: [MOCK_QUESTION_BANK[12]]
      }
    ],
    includeAnswerKey: true,
    schoolBranding: INITIAL_BRANDING
  }
];

export const MOCK_RESOURCES: ResourceMaterial[] = [
  // 1. NCERT Books
  {
    id: 'res_ncert_10_sci',
    title: 'NCERT Textbook Class 10 Science (Complete Book - All Chapters)',
    category: 'NCERT Books',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Science',
    downloads: 5820,
    fileSize: '14.2 MB',
    dateAdded: 'July 2026',
    description: 'Official NCERT Class 10 Science textbook covering Chemical Reactions, Electricity, Life Processes, and Light.'
  },
  {
    id: 'res_ncert_12_phy',
    title: 'NCERT Physics Class 12 (Part 1 & Part 2 Textbooks)',
    category: 'NCERT Books',
    board: 'CBSE',
    classLevel: '12',
    subject: 'Physics',
    downloads: 4120,
    fileSize: '18.5 MB',
    dateAdded: 'June 2026',
    description: 'Complete NCERT Physics textbook for Class 12 with solved examples and chapter exercise solutions.'
  },
  {
    id: 'res_ncert_10_math',
    title: 'NCERT Mathematics Class 10 Textbook & Exemplar Problems',
    category: 'NCERT Books',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Mathematics',
    downloads: 6390,
    fileSize: '12.8 MB',
    dateAdded: 'July 2026',
    description: 'Official NCERT Maths book with step-by-step theorem proofs and exemplar problem sets.'
  },

  // 2. Previous Year Papers (PYQs)
  {
    id: 'res_pyq_10_sci',
    title: 'CBSE Class 10 Science Last 10 Years Solved Board Papers (2015-2025)',
    category: 'Previous Year Papers',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Science',
    downloads: 8940,
    fileSize: '8.4 MB',
    dateAdded: 'July 2026',
    description: 'Topic-wise sorted Previous Year Questions with official CBSE marking scheme answers.'
  },
  {
    id: 'res_pyq_12_mat',
    title: 'Class 12 Mathematics 5-Year Solved Board Question Papers (Delhi & All India)',
    category: 'Previous Year Papers',
    board: 'CBSE',
    classLevel: '12',
    subject: 'Mathematics',
    downloads: 5120,
    fileSize: '6.2 MB',
    dateAdded: 'June 2026',
    description: 'Includes Calculus, Vectors, Matrices, and Linear Programming solved board question papers.'
  },

  // 3. Chapter-wise Short Notes
  {
    id: 'res_notes_10_elec',
    title: 'Class 10 Physics Chapter Notes: Electricity & Magnetic Effects (Formula Sheet)',
    category: 'Short Notes',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Physics',
    chapter: 'Electricity',
    downloads: 7210,
    fileSize: '2.1 MB',
    dateAdded: 'July 2026',
    description: 'Ultra-quick revision notes with circuit diagrams, Ohm’s law formulas, and numerical shortcuts.'
  },
  {
    id: 'res_notes_10_chem',
    title: 'Class 10 Chemistry Quick Revision Notes: Carbon & Its Compounds',
    category: 'Short Notes',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Chemistry',
    chapter: 'Carbon and its Compounds',
    downloads: 4890,
    fileSize: '1.9 MB',
    dateAdded: 'July 2026',
    description: 'Covers IUPAC nomenclature, homologous series, and key chemical reaction mechanisms.'
  },

  // 4. Toppers' Handwritten Notes
  {
    id: 'res_topper_12_phy',
    title: 'CBSE Class 12 Physics Topper (99/100) Handwritten Revision Notebook',
    category: 'Handwritten Notes',
    board: 'CBSE',
    classLevel: '12',
    subject: 'Physics',
    downloads: 9840,
    fileSize: '24.0 MB',
    dateAdded: 'June 2026',
    description: 'Scanned high-resolution handwritten notes with ray optics diagrams and derivation tricks.'
  },
  {
    id: 'res_topper_10_bio',
    title: 'Class 10 Biology Topper Diagram Handbook & Answer Presentation Tips',
    category: 'Handwritten Notes',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Biology',
    downloads: 6730,
    fileSize: '11.5 MB',
    dateAdded: 'July 2026',
    description: 'Clean labeled diagrams for Nephron, Heart, Reflex Arc, and Plant Transport.'
  },

  // 5. Sample Papers
  {
    id: 'res_sample_10_cbse',
    title: 'Official CBSE Class 10 Science & Maths Model Sample Papers 2026-27',
    category: 'Sample Papers',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Science',
    downloads: 11200,
    fileSize: '3.5 MB',
    dateAdded: 'July 2026',
    description: 'CBSE official blueprint compliant sample papers with detailed solutions and section breakdown.'
  },
  {
    id: 'res_sample_12_chem',
    title: 'Class 12 Chemistry Full Syllabus Pre-Board Practice Sample Paper',
    category: 'Sample Papers',
    board: 'CBSE',
    classLevel: '12',
    subject: 'Chemistry',
    downloads: 3890,
    fileSize: '2.8 MB',
    dateAdded: 'June 2026',
    description: '70-mark theory paper formatted according to latest 2026 CBSE curriculum.'
  },

  // 6. Practice Worksheets
  {
    id: 'res_ws_10_math',
    title: 'Class 10 Quadratic Equations & Arithmetic Progressions Practice Worksheet',
    category: 'Worksheets',
    board: 'CBSE',
    classLevel: '10',
    subject: 'Mathematics',
    downloads: 4320,
    fileSize: '1.4 MB',
    dateAdded: 'July 2026',
    description: '50 differentiated practice problems ranging from basic concept checks to HOTS questions.'
  },
  {
    id: 'res_ws_9_sci',
    title: 'Class 9 Science Chapter-wise Practice Worksheets with Answer Key',
    category: 'Worksheets',
    board: 'CBSE',
    classLevel: '9',
    subject: 'Science',
    downloads: 2980,
    fileSize: '2.2 MB',
    dateAdded: 'July 2026',
    description: 'Classroom print-ready worksheets with space for student answers and teacher markings.'
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_1',
    title: 'Welcome to Upian Pro!',
    message: 'Your account comes with 3 FREE question paper generations. All AI & Question Bank features unlocked.',
    timestamp: 'Just now',
    read: false,
    type: 'info'
  },
  {
    id: 'notif_2',
    title: 'New Study Materials Added',
    message: 'Class 10 Science NCERT Books, PYQs (2015-2025), and Toppers Notes added to Free Resources.',
    timestamp: '2 hours ago',
    read: false,
    type: 'success',
    actionTab: 'resources'
  },
  {
    id: 'notif_3',
    title: 'Gemini 3.6 AI Engine Active',
    message: 'Enjoy instantaneous board-compliant question generation with step-by-step answer key.',
    timestamp: '1 day ago',
    read: true,
    type: 'info'
  }
];

export const MOCK_FAQS = [
  {
    q: 'How does AI Question Generation work in Upian Pro?',
    a: 'Upian Pro uses Google Gemini AI customized for education boards (CBSE, ICSE, State Boards). It takes your selected Board, Subject, Class, Chapters, and Question distribution to generate fresh, curriculum-compliant questions with complete marking schemes.'
  },
  {
    q: 'Can I add my school logo and principal signature to generated PDFs?',
    a: 'Yes! Go to the "School Branding" section from the sidebar. You can upload your official logo, signature, set custom watermark text, and select header styling. All exported PDFs will automatically include these.'
  },
  {
    q: 'Is it possible to reorder or edit questions before downloading?',
    a: 'Absolutely. You can open any paper in the "Smart Paper Builder" to drag and drop questions, edit question text, adjust marks, add custom questions, and preview auto-numbering live.'
  },
  {
    q: 'How do I print or save papers as PDF?',
    a: 'Inside the Paper Preview or Builder, click the "Export PDF / Print" button. You can choose to print the Question Paper only, or include the step-by-step Answer Key and Marking Scheme.'
  }
];
