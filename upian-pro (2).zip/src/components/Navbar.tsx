import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Sparkles, 
  Building2, 
  User, 
  LogOut, 
  Bell, 
  ChevronDown, 
  Search, 
  CheckCircle2, 
  GraduationCap,
  Gem,
  AlertTriangle,
  Crown,
  Menu,
  X,
  LayoutDashboard,
  Database,
  Layers,
  FolderCheck,
  BookOpen,
  HelpCircle
} from 'lucide-react';
import { ActiveTab, UserProfile, SchoolBranding, NotificationItem } from '../types';
import { NotificationCenter } from './NotificationCenter';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  user: UserProfile;
  branding: SchoolBranding;
  isLoggedIn: boolean;
  onOpenAuth: (mode: 'login' | 'signup' | 'forgot') => void;
  onLogout: () => void;
  notifications: NotificationItem[];
  onMarkAllNotificationsRead: () => void;
  onMarkNotificationRead: (id: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  user,
  branding,
  isLoggedIn,
  onOpenAuth,
  onLogout,
  notifications,
  onMarkAllNotificationsRead,
  onMarkNotificationRead
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showCreateDropdown, setShowCreateDropdown] = useState(false);
  const [showMobileDrawer, setShowMobileDrawer] = useState(false);

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;
  const isLowCredits = !user.isUnlimited && user.credits < 5 && user.credits > 0;
  const isZeroCredits = !user.isUnlimited && user.credits === 0;

  const isModeSelected = activeTab === 'ai_generate' || activeTab === 'smart_builder' || activeTab === 'question_bank';

  const mobileNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'teacher_profile', label: 'Teacher Profile', icon: User },
    { id: 'saved_papers', label: 'Saved Papers', icon: FolderCheck },
    { id: 'premium', label: 'Subscription', icon: Crown, badge: 'Pro ₹99', badgeColor: 'bg-amber-100 text-amber-800 font-bold' },
    { id: 'school_branding', label: 'School Branding', icon: Building2 },
    { id: 'resources', label: 'Resources Library', icon: BookOpen, badge: 'NCERT', badgeColor: 'bg-amber-100 text-amber-800' },
    { id: 'help_support', label: 'Help & Support', icon: HelpCircle }
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-3">
        
        {/* Left: Hamburger Menu (Top Left) & Brand Identity */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* TOP LEFT Hamburger Menu Icon (☰) */}
          <button
            onClick={() => setShowMobileDrawer(true)}
            className="lg:hidden p-2 text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors flex items-center justify-center border border-slate-200 shrink-0"
            title="Open Navigation Menu"
            aria-label="Open Navigation Menu"
          >
            <Menu className="w-5 h-5 text-slate-800" />
          </button>

          <button 
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 sm:gap-3 group focus:outline-none"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-200 text-white transition-transform group-hover:scale-105 shrink-0">
              <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="text-left min-w-0">
              <div className="flex items-center">
                <span className="text-lg sm:text-2xl font-bold tracking-tight text-slate-900 whitespace-nowrap">
                  Upian <span className="text-blue-600 font-extrabold">Pro</span>
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-500 hidden sm:block">
                Question Paper Engine for Educators
              </p>
            </div>
          </button>

          {/* Active School Badge */}
          <div className="hidden xl:flex items-center gap-2 ml-4 pl-4 border-l border-slate-200 text-xs text-slate-600">
            <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="font-medium truncate max-w-[200px]" title={branding.schoolName}>
              {branding.schoolName || 'School Branding Unset'}
            </span>
          </div>
        </div>

        {/* Center/Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* CREDITS & PLAN STATUS BAR */}
          <div className="flex items-center gap-2">
            {isZeroCredits ? (
              <button
                onClick={() => setActiveTab('premium')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-extrabold bg-gradient-to-r from-amber-500 to-rose-500 text-white rounded-xl shadow-md shadow-rose-500/20 hover:opacity-95 transition-all animate-pulse"
              >
                <span>💎 0 Credits — Upgrade</span>
              </button>
            ) : (
              <button
                onClick={() => setActiveTab('premium')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all border ${
                  user.isUnlimited
                    ? 'bg-purple-50 text-purple-900 border-purple-200 hover:bg-purple-100'
                    : isLowCredits
                    ? 'bg-amber-50 text-amber-900 border-amber-300 hover:bg-amber-100'
                    : 'bg-blue-50 text-blue-900 border-blue-200 hover:bg-blue-100'
                }`}
                title="Click to view subscription plans & top-up credits"
              >
                <span className="font-extrabold text-xs tracking-tight">
                  {user.isUnlimited ? '💎 Unlimited' : `💎 ${user.credits}`}
                </span>

                {isLowCredits && (
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-200 text-amber-900 text-[10px] font-extrabold ml-1">
                    <AlertTriangle className="w-3 h-3 text-amber-800 shrink-0" /> Low
                  </span>
                )}
              </button>
            )}
          </div>

          {/* Quick Create Dropdown - Hidden on Mobile (< sm) and when a paper creation mode is active */}
          {!isModeSelected && (
            <div className="relative hidden sm:block">
              <button
                onClick={() => setShowCreateDropdown(!showCreateDropdown)}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-md shadow-blue-100 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Create Paper</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-80" />
              </button>

              {showCreateDropdown && (
                <div 
                  className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                  onClick={() => setShowCreateDropdown(false)}
                >
                  <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                    Creation Modes
                  </div>
                  <button
                    onClick={() => setActiveTab('ai_generate')}
                    className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5"
                  >
                    <Sparkles className="w-4 h-4 text-blue-600" />
                    <div>
                      <div className="font-semibold">AI Generate Paper</div>
                      <div className="text-[10px] text-slate-500">Auto syllabus & chapter paper</div>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('question_bank')}
                    className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5"
                  >
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <div>
                      <div className="font-semibold">Question Bank</div>
                      <div className="text-[10px] text-slate-500">Browse by 1 to 5 marks</div>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('smart_builder')}
                    className="w-full text-left px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5"
                  >
                    <Plus className="w-4 h-4 text-indigo-600" />
                    <div>
                      <div className="font-semibold">Smart Paper Builder</div>
                      <div className="text-[10px] text-slate-500">Drag, drop & live preview</div>
                    </div>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Notification Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors relative"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 rounded-full bg-blue-600 ring-2 ring-white" />
              )}
            </button>

            <NotificationCenter
              isOpen={showNotifications}
              onClose={() => setShowNotifications(false)}
              notifications={notifications}
              onMarkAllAsRead={onMarkAllNotificationsRead}
              onMarkAsRead={onMarkNotificationRead}
            />
          </div>

          {/* Auth / Profile Area */}
          {isLoggedIn ? (
            <div className="relative hidden md:block">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-2 p-1 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <img
                  src={user.avatarUrl}
                  alt={user.fullName}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-blue-100"
                />
                <div className="text-left">
                  <div className="text-xs font-semibold text-slate-800 leading-none">{user.fullName}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{user.role}</div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {showProfileMenu && (
                <div 
                  className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50"
                  onClick={() => setShowProfileMenu(false)}
                >
                  <div className="px-3.5 py-2 border-b border-slate-100">
                    <p className="text-xs font-bold text-slate-900">{user.fullName}</p>
                    <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                    <div className="mt-1 flex items-center justify-between text-[10px]">
                      <span className="text-slate-500">Plan:</span>
                      <span className="font-extrabold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">{user.plan}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveTab('premium')}
                    className="w-full text-left px-3.5 py-2 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 flex items-center gap-2"
                  >
                    <Crown className="w-4 h-4 text-amber-600" />
                    Subscription Plans
                  </button>

                  <button
                    onClick={() => setActiveTab('teacher_profile')}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <User className="w-4 h-4 text-slate-500" />
                    Teacher Profile
                  </button>

                  <button
                    onClick={() => setActiveTab('school_branding')}
                    className="w-full text-left px-3.5 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <Building2 className="w-4 h-4 text-slate-500" />
                    School Branding
                  </button>

                  <div className="border-t border-slate-100 my-1"></div>

                  <button
                    onClick={onLogout}
                    className="w-full text-left px-3.5 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 font-medium"
                  >
                    <LogOut className="w-4 h-4" />
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-2">
              <button
                onClick={() => onOpenAuth('login')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-blue-700 transition-colors"
              >
                Sign In
              </button>
              <button
                onClick={() => onOpenAuth('signup')}
                className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors shadow-xs"
              >
                Sign Up Free
              </button>
            </div>
          )}

        </div>

      </div>

      {/* Mobile Navigation Side Drawer */}
      {showMobileDrawer && (
        <div className="fixed inset-0 z-50 flex justify-start lg:hidden">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in"
            onClick={() => setShowMobileDrawer(false)}
          />

          {/* Side Drawer Panel */}
          <div className="relative w-80 max-w-[85vw] bg-white h-full shadow-2xl flex flex-col z-10 animate-in slide-in-from-left duration-200">
            
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-3">
                {isLoggedIn ? (
                  <>
                    <img
                      src={user.avatarUrl}
                      alt={user.fullName}
                      className="w-9 h-9 rounded-full object-cover ring-2 ring-blue-400"
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white leading-tight truncate">{user.fullName}</div>
                      <div className="text-[10px] text-slate-300 truncate">{user.email}</div>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-6 h-6 text-blue-400" />
                    <span className="font-bold text-sm">Upian Pro</span>
                  </div>
                )}
              </div>
              <button
                onClick={() => setShowMobileDrawer(false)}
                className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Drawer Items - Vertically Scrollable */}
            <div className="flex-1 overflow-y-auto p-4 space-y-1">
              <div className="px-2 pb-2 text-[10px] font-bold tracking-wider uppercase text-slate-400">
                Navigation Menu
              </div>

              {mobileNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id as ActiveTab);
                      setShowMobileDrawer(false);
                    }}
                    className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-blue-50 text-blue-700 font-bold shadow-xs'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-600' : 'text-slate-500'}`} />
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Drawer Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 space-y-2">
              {isLoggedIn ? (
                <>
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
                    <span>Active Plan:</span>
                    <span className="font-bold text-blue-700 bg-blue-100 px-2.5 py-0.5 rounded-full text-[10px]">{user.plan}</span>
                  </div>
                  <button
                    onClick={() => {
                      onLogout();
                      setShowMobileDrawer(false);
                    }}
                    className="w-full py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      onOpenAuth('login');
                      setShowMobileDrawer(false);
                    }}
                    className="py-2 text-xs font-bold text-slate-700 bg-slate-200 hover:bg-slate-300 rounded-xl text-center"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => {
                      onOpenAuth('signup');
                      setShowMobileDrawer(false);
                    }}
                    className="py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl text-center shadow-xs"
                  >
                    Sign Up Free
                  </button>
                </div>
              )}
            </div>

          </div>
        </div>
      )}
    </header>
  );
};
