import React, { useState } from 'react';
import { 
  Database, 
  Search, 
  Filter, 
  CheckSquare, 
  Square, 
  Check, 
  Plus, 
  FileText, 
  Sparkles, 
  BookOpen, 
  Eye, 
  ChevronDown,
  Layers,
  Image as ImageIcon
} from 'lucide-react';
import { Question, QuestionPaper, SchoolBranding } from '../types';
import { MOCK_QUESTION_BANK } from '../data/mockData';
import { PAPER_CATEGORIES, getSubjectsForCategory } from '../data/paperCatalog';

interface QuestionBankViewProps {
  branding: SchoolBranding;
  onAssemblePaper: (paper: QuestionPaper) => void;
}

export const QuestionBankView: React.FC<QuestionBankViewProps> = ({
  branding,
  onAssemblePaper
}) => {
  const [selectedMarkTab, setSelectedMarkTab] = useState<number | 'all'>('all');
  const [onlyDiagrams, setOnlyDiagrams] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');

  // Selected question IDs map
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<Record<string, boolean>>({});
  const [showAnswerForId, setShowAnswerForId] = useState<Record<string, boolean>>({});

  // Get available subjects for selected class or all
  const availableSubjects = React.useMemo(() => {
    if (selectedClass !== 'all') {
      const subs = getSubjectsForCategory(selectedClass);
      if (subs && subs.length > 0) return subs;
    }
    // Default fallback list of all unique subjects
    const set = new Set<string>();
    PAPER_CATEGORIES.forEach(c => c.subjects.forEach(s => {
      if (s !== 'All Subjects') set.add(s);
    }));
    MOCK_QUESTION_BANK.forEach(q => {
      if (q.subject) set.add(q.subject);
    });
    return Array.from(set).sort();
  }, [selectedClass]);

  // Filter questions
  const filteredQuestions = MOCK_QUESTION_BANK.filter((q) => {
    if (onlyDiagrams && !q.hasDiagram && !q.diagramUrl) return false;
    if (selectedMarkTab !== 'all' && q.marks !== selectedMarkTab) return false;
    
    // Class / Category filtering
    if (selectedClass !== 'all') {
      const targetCat = PAPER_CATEGORIES.find(c => c.id === selectedClass || c.name === selectedClass);
      const isClassMatch = 
        q.classLevel === selectedClass ||
        q.classLevel === targetCat?.id ||
        (targetCat && (q.classLevel as string) === targetCat.name) ||
        (targetCat && q.classLevel && targetCat.name.includes(q.classLevel as string));
      if (!isClassMatch) return false;
    }

    // Subject filtering
    if (selectedSubject !== 'all') {
      const isSubMatch = q.subject && q.subject.toLowerCase() === selectedSubject.toLowerCase();
      if (!isSubMatch) return false;
    }

    if (selectedDifficulty !== 'all' && q.difficulty !== selectedDifficulty) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const matchText = q.text.toLowerCase();
      const matchChapter = q.chapter.toLowerCase();
      const matchAnswer = q.answer.toLowerCase();
      return matchText.includes(query) || matchChapter.includes(query) || matchAnswer.includes(query);
    }
    return true;
  });

  const toggleSelectQuestion = (id: string) => {
    setSelectedQuestionIds(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const toggleShowAnswer = (id: string) => {
    setShowAnswerForId(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Selected questions count & total marks
  const selectedList = MOCK_QUESTION_BANK.filter(q => selectedQuestionIds[q.id]);
  const selectedCount = selectedList.length;
  const totalSelectedMarks = selectedList.reduce((sum, q) => sum + q.marks, 0);

  const handleAssemblePaper = () => {
    if (selectedCount === 0) return;

    // Group selected questions by marks into sections
    const sec1m = selectedList.filter(q => q.marks === 1);
    const sec2m = selectedList.filter(q => q.marks === 2);
    const sec3m = selectedList.filter(q => q.marks === 3);
    const sec4m = selectedList.filter(q => q.marks === 4);
    const sec5m = selectedList.filter(q => q.marks === 5);

    const sections = [];
    if (sec1m.length) {
      sections.push({
        id: 'sec_1m',
        title: 'SECTION A - Objective & MCQs (1 Mark Each)',
        questions: sec1m
      });
    }
    if (sec2m.length) {
      sections.push({
        id: 'sec_2m',
        title: 'SECTION B - Short Answer Type I (2 Marks Each)',
        questions: sec2m
      });
    }
    if (sec3m.length) {
      sections.push({
        id: 'sec_3m',
        title: 'SECTION C - Short Answer Type II (3 Marks Each)',
        questions: sec3m
      });
    }
    if (sec4m.length) {
      sections.push({
        id: 'sec_4m',
        title: 'SECTION D - Case Study Questions (4 Marks Each)',
        questions: sec4m
      });
    }
    if (sec5m.length) {
      sections.push({
        id: 'sec_5m',
        title: 'SECTION E - Long Answer Questions (5 Marks Each)',
        questions: sec5m
      });
    }

    const assembledPaper: QuestionPaper = {
      id: 'pap_' + Date.now(),
      title: `Curated Examination Paper (${selectedList[0]?.subject || 'General'} - Class ${selectedList[0]?.classLevel || '10'})`,
      board: selectedList[0]?.board || 'CBSE',
      classLevel: selectedList[0]?.classLevel || '10',
      subject: selectedList[0]?.subject || 'Science',
      medium: 'English',
      timeAllowedMinutes: Math.max(60, Math.round(totalSelectedMarks * 2.2)),
      totalMarks: totalSelectedMarks,
      createdMode: 'question_bank',
      createdAt: new Date().toISOString(),
      status: 'published',
      generalInstructions: [
        'All questions are compulsory.',
        'Section division is based on question mark weightage.',
        'Write answers neatly in the designated answer sheet.'
      ],
      sections,
      includeAnswerKey: true,
      schoolBranding: branding
    };

    onAssemblePaper(assembledPaper);
  };

  return (
    <div className="space-y-6 pb-20">
      
      {/* Title Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold mb-2">
            <Database className="w-3.5 h-3.5" />
            Mode B: Question Bank Repository
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
            Browse & Select Questions by Marks
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Pick vetted 1, 2, 3, 4, 5 mark questions with complete solutions & instant paper assembly.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              const allIds: Record<string, boolean> = {};
              filteredQuestions.forEach(q => { allIds[q.id] = true; });
              setSelectedQuestionIds(allIds);
            }}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors"
          >
            Select Filtered ({filteredQuestions.length})
          </button>
          
          <button
            onClick={() => setSelectedQuestionIds({})}
            className="px-3 py-1.5 text-slate-500 hover:text-slate-800 text-xs font-semibold"
          >
            Clear Selection
          </button>
        </div>
      </div>

      {/* Mark Category Tabs (1 Mark, 2 Marks, 3 Marks, 4 Marks, 5 Marks) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setSelectedMarkTab('all')}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap ${
            selectedMarkTab === 'all'
              ? 'bg-slate-900 text-white shadow-md'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          All Questions ({MOCK_QUESTION_BANK.length})
        </button>

        {[1, 2, 3, 4, 5].map((mark) => {
          const count = MOCK_QUESTION_BANK.filter(q => q.marks === mark).length;
          const isSelected = selectedMarkTab === mark;

          return (
            <button
              key={mark}
              onClick={() => setSelectedMarkTab(mark)}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap flex items-center gap-2 ${
                isSelected
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <span>{mark} {mark === 1 ? 'Mark' : 'Marks'}</span>
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
              }`}>
                {count}
              </span>
            </button>
          );
        })}

        {/* Diagram Questions Filter Tab */}
        <button
          onClick={() => setOnlyDiagrams(!onlyDiagrams)}
          className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all whitespace-nowrap flex items-center gap-2 ${
            onlyDiagrams
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20'
              : 'bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>Diagram Questions</span>
          <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
            onlyDiagrams ? 'bg-white/20 text-white' : 'bg-indigo-200 text-indigo-900'
          }`}>
            {MOCK_QUESTION_BANK.filter(q => q.hasDiagram || q.diagramUrl).length}
          </span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-4 gap-3">
        
        {/* Search Input */}
        <div className="relative col-span-1 sm:col-span-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search question text or chapter..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 outline-none"
          />
        </div>

        {/* Subject Filter */}
        <div>
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-medium text-slate-700 outline-none"
          >
            <option value="all">All Subjects</option>
            <option value="Physics">Physics</option>
            <option value="Chemistry">Chemistry</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Biology">Biology</option>
          </select>
        </div>

        {/* Class Filter */}
        <div>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-medium text-slate-700 outline-none"
          >
            <option value="all">All Classes</option>
            <option value="9">Class 9</option>
            <option value="10">Class 10</option>
            <option value="12">Class 12</option>
          </select>
        </div>

        {/* Difficulty Filter */}
        <div>
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-medium text-slate-700 outline-none"
          >
            <option value="all">All Difficulties</option>
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>
        </div>

      </div>

      {/* Question Cards List */}
      <div className="space-y-3">
        {filteredQuestions.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500">
            <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-slate-800">No questions found matching filters</p>
            <p className="text-xs text-slate-500 mt-1">Try clearing your search query or selecting 'All' marks.</p>
          </div>
        ) : (
          filteredQuestions.map((q, index) => {
            const isSelected = !!selectedQuestionIds[q.id];
            const showAnswer = !!showAnswerForId[q.id];

            return (
              <div
                key={q.id}
                className={`bg-white rounded-2xl p-5 border transition-all ${
                  isSelected 
                    ? 'border-emerald-500 ring-2 ring-emerald-500/10 shadow-sm' 
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  
                  {/* Select Checkbox */}
                  <button
                    onClick={() => toggleSelectQuestion(q.id)}
                    className="mt-0.5 text-slate-400 hover:text-emerald-600 transition-colors shrink-0"
                  >
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                    ) : (
                      <Square className="w-5 h-5" />
                    )}
                  </button>

                  <div className="flex-1 space-y-2">
                    
                    {/* Tags Bar */}
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-emerald-100 text-emerald-800">
                          {q.marks} {q.marks === 1 ? 'Mark' : 'Marks'}
                        </span>
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-700">
                          {q.subject} • Class {q.classLevel}
                        </span>
                        <span className="text-[11px] font-medium text-slate-500">
                          Ch: {q.chapter}
                        </span>
                      </div>

                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        q.difficulty === 'Easy' 
                          ? 'bg-blue-50 text-blue-700' 
                          : q.difficulty === 'Medium' 
                            ? 'bg-amber-50 text-amber-700' 
                            : 'bg-rose-50 text-rose-700'
                      }`}>
                        {q.difficulty}
                      </span>
                    </div>

                    {/* Question Text */}
                    <p className="text-sm font-semibold text-slate-900 whitespace-pre-line leading-relaxed">
                      Q{index + 1}. {q.text}
                    </p>

                    {/* Diagram Preview */}
                    {(q.diagramUrl || q.hasDiagram) && (
                      <div className="my-3 p-3 bg-slate-50 border border-slate-200 rounded-xl max-w-md">
                        {q.diagramUrl?.startsWith('<svg') ? (
                          <div className="w-full max-h-48 flex justify-center" dangerouslySetInnerHTML={{ __html: q.diagramUrl }} />
                        ) : (
                          <img src={q.diagramUrl} alt="Question Diagram" className="max-h-48 max-w-full object-contain mx-auto rounded-lg" />
                        )}
                        {q.diagramCaption && (
                          <p className="text-[11px] text-slate-500 font-medium text-center mt-1.5 italic">
                            {q.diagramCaption}
                          </p>
                        )}
                      </div>
                    )}

                    {/* MCQ Options */}
                    {q.options && q.options.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 pl-2">
                        {q.options.map((opt, optIdx) => (
                          <div key={optIdx} className="text-xs text-slate-700 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200/60">
                            <span className="font-bold text-slate-900">{String.fromCharCode(65 + optIdx)})</span> {opt}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Show Answer Toggle */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <button
                        onClick={() => toggleShowAnswer(q.id)}
                        className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>{showAnswer ? 'Hide Solution' : 'Show Solution & Marking Scheme'}</span>
                      </button>

                      <button
                        onClick={() => toggleSelectQuestion(q.id)}
                        className={`text-xs font-semibold px-3 py-1 rounded-lg transition-colors ${
                          isSelected 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        {isSelected ? '✓ Added to Paper' : '+ Add Question'}
                      </button>
                    </div>

                    {/* Answer & Explanation Box */}
                    {showAnswer && (
                      <div className="mt-2 p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs space-y-1 animate-in fade-in duration-150">
                        <div className="font-bold text-emerald-950">Solution / Model Answer:</div>
                        <p className="text-emerald-900 whitespace-pre-line font-medium">{q.answer}</p>
                        {q.explanation && (
                          <p className="text-emerald-700 text-[11px] italic mt-1">
                            Note: {q.explanation}
                          </p>
                        )}
                      </div>
                    )}

                  </div>

                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Floating Selection Bar */}
      {selectedCount > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-900 text-white px-6 py-3.5 rounded-2xl shadow-2xl border border-slate-800 flex items-center justify-between gap-6 w-[90%] max-w-xl animate-in slide-in-from-bottom-5 duration-200">
          <div>
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-sm">{selectedCount} Questions Selected</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Total Weightage: <span className="font-bold text-emerald-400">{totalSelectedMarks} Marks</span>
            </p>
          </div>

          <button
            onClick={handleAssemblePaper}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-transform hover:scale-105 flex items-center gap-2 shrink-0"
          >
            <Layers className="w-4 h-4" />
            <span>Assemble & Export PDF</span>
          </button>
        </div>
      )}

    </div>
  );
};
