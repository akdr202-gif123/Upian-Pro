import React from 'react';
import { 
  LayoutDashboard, 
  Sparkles, 
  Database, 
  Layers, 
  FolderCheck, 
  Building2, 
  BookOpen, 
  User, 
  HelpCircle,
  Crown
} from 'lucide-react';
import { ActiveTab } from '../types';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  savedPapersCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  savedPapersCount
}) => {
  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'saved_papers',
      label: 'Saved Papers',
      icon: FolderCheck,
      badge: savedPapersCount > 0 ? `${savedPapersCount}` : null,
      badgeColor: 'bg-slate-200 text-slate-800'
    },
    {
      id: 'premium',
      label: 'Subscription Plans',
      icon: Crown,
      badge: 'Pro ₹99',
      badgeColor: 'bg-amber-100 text-amber-800 font-bold'
    },
    {
      id: 'school_branding',
      label: 'School Branding',
      icon: Building2,
      badge: null
    },
    {
      id: 'resources',
      label: 'Resources Library',
      icon: BookOpen,
      badge: 'Free NCERT',
      badgeColor: 'bg-amber-100 text-amber-800'
    },
    {
      id: 'teacher_profile',
      label: 'Teacher Profile',
      icon: User,
      badge: null
    },
    {
      id: 'help_support',
      label: 'Help & Support',
      icon: HelpCircle,
      badge: null
    }
  ];

  return (
    <aside className="hidden lg:flex lg:w-64 bg-white border-r border-slate-200 shrink-0 p-4 lg:min-h-[calc(100vh-5rem)] flex-col">
      <div className="flex flex-col gap-1 overflow-x-visible pb-0 flex-1">
        
        <div className="px-3 py-2 text-[10px] font-bold tracking-wider uppercase text-slate-400">
          Navigation Menu
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as ActiveTab)}
              className={`flex items-center justify-between px-3.5 py-2.5 rounded-lg text-xs sm:text-sm transition-colors whitespace-nowrap lg:whitespace-normal group ${
                isActive
                  ? 'bg-blue-50 text-blue-700 font-semibold'
                  : 'text-slate-600 hover:bg-slate-50 font-medium'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-blue-600' : 'text-slate-500 group-hover:text-blue-600'
                  }`}
                />
                <span>{item.label}</span>
              </div>

              {item.badge && (
                <span
                  className={`hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ml-2 ${
                    isActive ? 'bg-blue-100 text-blue-800' : item.badgeColor
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Sidebar Info Card */}
        <div className="hidden lg:block mt-6 p-4 rounded-xl bg-slate-900 text-white text-xs shadow-md">
          <div className="flex items-center gap-1.5 text-blue-400 font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            Upian AI Engine
          </div>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Generate 100% board-compliant question papers with answers & instant PDF export.
          </p>
        </div>

      </div>
    </aside>
  );
};
