import React, { useState } from 'react';
import { 
  FolderCheck, 
  Search, 
  FileText, 
  Eye, 
  Copy, 
  Trash2, 
  Printer, 
  Sparkles, 
  Database, 
  Layers, 
  Calendar, 
  Clock, 
  FileCheck2,
  Filter
} from 'lucide-react';
import { QuestionPaper, ActiveTab } from '../types';

interface SavedPapersViewProps {
  papers: QuestionPaper[];
  setActiveTab: (tab: ActiveTab) => void;
  onPreviewPaper: (paper: QuestionPaper) => void;
  onEditPaper: (paper: QuestionPaper) => void;
  onDuplicatePaper: (id: string) => void;
  onDeletePaper: (id: string) => void;
}

export const SavedPapersView: React.FC<SavedPapersViewProps> = ({
  papers,
  setActiveTab,
  onPreviewPaper,
  onEditPaper,
  onDuplicatePaper,
  onDeletePaper
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedMode, setSelectedMode] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');

  const filteredPapers = papers.filter((p) => {
    if (selectedMode !== 'all' && p.createdMode !== selectedMode) return false;
    if (selectedSubject !== 'all' && p.subject !== selectedSubject) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        p.title.toLowerCase().includes(q) ||
        p.subject.toLowerCase().includes(q) ||
        p.board.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Title Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-bold mb-2">
            <FolderCheck className="w-3.5 h-3.5 text-blue-600" />
            Saved Papers Repository ({papers.length})
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
            Saved & Draft Question Papers
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Access, edit, duplicate, and print all previously generated examination papers.
          </p>
        </div>

        <button
          onClick={() => setActiveTab('ai_generate')}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20 transition-all flex items-center gap-2"
        >
          <Sparkles className="w-4 h-4" />
          <span>+ Generate New Paper</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search saved papers by title, board..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
          />
        </div>

        <div>
          <select
            value={selectedMode}
            onChange={(e) => setSelectedMode(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-medium text-slate-700 outline-none"
          >
            <option value="all">All Modes (AI, Bank, Builder)</option>
            <option value="ai">AI Generated</option>
            <option value="question_bank">Question Bank</option>
            <option value="builder">Smart Builder</option>
          </select>
        </div>

        <div>
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-medium text-slate-700 outline-none"
          >
            <option value="all">All Subjects</option>
            <option value="Science">Science</option>
            <option value="Physics">Physics</option>
            <option value="Mathematics">Mathematics</option>
            <option value="Chemistry">Chemistry</option>
          </select>
        </div>
      </div>

      {/* Papers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPapers.length === 0 ? (
          <div className="col-span-full bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-500">
            <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-bold text-slate-800">No saved papers found</p>
            <p className="text-xs text-slate-500 mt-1">Try resetting search filters or generate a paper using AI.</p>
          </div>
        ) : (
          filteredPapers.map((paper) => (
            <div
              key={paper.id}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4 group"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                    paper.createdMode === 'ai'
                      ? 'bg-purple-100 text-purple-800'
                      : paper.createdMode === 'question_bank'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-indigo-100 text-indigo-800'
                  }`}>
                    {paper.createdMode === 'ai' && 'AI Mode'}
                    {paper.createdMode === 'question_bank' && 'Question Bank'}
                    {paper.createdMode === 'builder' && 'Smart Builder'}
                  </span>

                  <span className="text-[11px] font-semibold text-slate-400">
                    {new Date(paper.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-sm leading-snug group-hover:text-blue-600 transition-colors line-clamp-2">
                  {paper.title}
                </h3>

                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 pt-1">
                  <span className="font-semibold bg-slate-100 px-2 py-0.5 rounded-md text-[11px]">
                    {paper.board} • Class {paper.classLevel}
                  </span>
                  <span>•</span>
                  <span className="font-medium text-slate-800">{paper.subject}</span>
                </div>

                <div className="flex items-center gap-3 text-[11px] font-medium text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    {paper.timeAllowedMinutes} Mins
                  </span>
                  <span>•</span>
                  <span className="font-bold text-slate-800">
                    {paper.totalMarks} Marks
                  </span>
                  <span>•</span>
                  <span>{paper.sections.flatMap(s => s.questions).length} Qs</span>
                </div>
              </div>

              {/* Card Bottom Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <button
                  onClick={() => onPreviewPaper(paper)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview / Print</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onEditPaper(paper)}
                    className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                    title="Edit in Smart Builder"
                  >
                    <Layers className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onDuplicatePaper(paper.id)}
                    className="p-1.5 text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                    title="Duplicate Paper"
                  >
                    <Copy className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onDeletePaper(paper.id)}
                    className="p-1.5 text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Delete Paper"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

            </div>
          ))
        )}
      </div>

    </div>
  );
};
