import React, { useState } from 'react';
import { 
  HelpCircle, 
  ChevronDown, 
  Search, 
  Send, 
  Sparkles, 
  Mail,
  MessageCircle,
  ExternalLink
} from 'lucide-react';
import { MOCK_FAQS } from '../data/mockData';

export const HelpSupportView: React.FC = () => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // AI Assistant Chat Simulator
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'bot', text: string }>>([
    {
      sender: 'bot',
      text: 'Hello! I am Upian AI Support Assistant. How can I help you design your question paper today?'
    }
  ]);
  const [chatInput, setChatInput] = useState<string>('');

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput;
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setChatInput('');

    setTimeout(() => {
      let botReply = 'Upian Pro allows you to generate question papers via Gemini AI or assemble from our Question Bank. Go to School Branding to upload your logo and signature!';
      if (userText.toLowerCase().includes('logo') || userText.toLowerCase().includes('brand')) {
        botReply = 'You can upload your school logo, principal signature, and watermark in the "School Branding" tab on the left sidebar.';
      } else if (userText.toLowerCase().includes('cbse') || userText.toLowerCase().includes('marks')) {
        botReply = 'Upian Pro supports standard CBSE section weightages (Section A: 1m, Section B: 2m, Section C: 3m, Section D: 4m, Section E: 5m).';
      }
      setMessages(prev => [...prev, { sender: 'bot', text: botReply }]);
    }, 600);
  };

  const filteredFaqs = MOCK_FAQS.filter(f => 
    f.q.toLowerCase().includes(searchQuery.toLowerCase()) || 
    f.a.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold mb-2">
            <HelpCircle className="w-3.5 h-3.5" />
            24/7 Teacher Help & Support Hub
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
            Frequently Asked Questions & Support
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Need assistance or have custom inquiries? Reach out via Email or WhatsApp.
          </p>
        </div>
      </div>

      {/* Direct Contact Support Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Email Support Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start gap-3">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Email Support</h3>
              <p className="text-xs text-slate-500 mt-0.5">Send us your queries, feedback, or custom requests.</p>
              <p className="text-xs font-bold text-blue-700 mt-1 select-all">upianpro.info@gmail.com</p>
            </div>
          </div>
          <a
            href="mailto:upianpro.info@gmail.com"
            className="mt-4 inline-flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
          >
            <Mail className="w-4 h-4" />
            <span>Email Support</span>
          </a>
        </div>

        {/* WhatsApp Chat Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-start gap-3">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
              <MessageCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">WhatsApp Chat</h3>
              <p className="text-xs text-slate-500 mt-0.5">Get instant quick assistance on WhatsApp.</p>
              <p className="text-xs font-bold text-emerald-700 mt-1">+91 93213 82706</p>
            </div>
          </div>
          <a
            href="https://wa.me/919321382706"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp Chat</span>
            <ExternalLink className="w-3 h-3 opacity-80" />
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: FAQs */}
        <div className="lg:col-span-2 space-y-4">
          
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-7 top-6" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search help topics..."
              className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-slate-300 outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>

          <div className="space-y-3">
            {filteredFaqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div key={idx} className="bg-white rounded-2xl border border-slate-200 overflow-hidden transition-all">
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                    className="w-full p-4 text-left font-bold text-xs sm:text-sm text-slate-900 flex items-center justify-between gap-4 hover:bg-slate-50"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-3 bg-slate-50/50">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>

        {/* Right: AI Support Chat Bot */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between h-[450px]">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100 font-bold text-slate-900 text-xs">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Upian AI Guide Assistant</span>
            </div>

            <div className="mt-3 space-y-2 max-h-[300px] overflow-y-auto text-xs pr-1">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded-xl max-w-[85%] leading-relaxed ${
                    m.sender === 'bot'
                      ? 'bg-blue-50 text-blue-950 font-medium'
                      : 'bg-slate-900 text-white font-medium ml-auto text-right'
                  }`}
                >
                  {m.text}
                </div>
              ))}
            </div>
          </div>

          <form onSubmit={handleSendChat} className="pt-3 border-t border-slate-100 flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask a question..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 outline-none focus:ring-2 focus:ring-blue-500/20"
            />
            <button
              type="submit"
              className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
