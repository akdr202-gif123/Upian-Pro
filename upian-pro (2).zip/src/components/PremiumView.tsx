import React, { useState } from 'react';
import { 
  Crown, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  CreditCard, 
  QrCode, 
  X, 
  ArrowRight,
  Gem,
  AlertCircle,
  XCircle,
  Receipt,
  CheckCircle2,
  Lock,
  RefreshCw
} from 'lucide-react';
import { PaymentStatus, PaymentTransaction, SubscriptionPlan, UserProfile } from '../types';
import { addStoredTransaction } from '../services/storageService';

interface PremiumViewProps {
  user: UserProfile;
  onUpgradePlan: (plan: SubscriptionPlan, credits: number) => void;
  onNavigateToHistory?: () => void;
}

export const PremiumView: React.FC<PremiumViewProps> = ({ 
  user, 
  onUpgradePlan,
  onNavigateToHistory 
}) => {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>('Pro');
  const [showCheckoutModal, setShowCheckoutModal] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [upiId, setUpiId] = useState('teacher@okicici');
  
  // Payment Gateway Step State
  const [paymentStep, setPaymentStep] = useState<'details' | 'processing' | 'result'>('details');
  const [paymentResultStatus, setPaymentResultStatus] = useState<PaymentStatus>('Processing');
  const [currentTxn, setCurrentTxn] = useState<PaymentTransaction | null>(null);
  
  const [successNotice, setSuccessNotice] = useState('');
  const [errorNotice, setErrorNotice] = useState('');

  const plans = [
    {
      id: 'Starter' as SubscriptionPlan,
      name: 'Starter Plan',
      price: 99,
      priceFormatted: '₹99',
      billing: 'per month',
      credits: 30,
      description: 'Ideal for individual subject teachers generating monthly class tests.',
      popular: false,
      color: 'border-slate-200 hover:border-blue-400',
      badge: '30 Papers / Mo',
      features: [
        '30 Credits per month',
        '1 Credit = 1 Question Paper',
        'Gemini 3.6 AI Question Generator',
        'Standard Question Bank (Class 1-12)',
        'Watermarked PDF Export',
        'Basic Answer Keys'
      ]
    },
    {
      id: 'Pro' as SubscriptionPlan,
      name: 'Pro Plan',
      price: 999,
      priceFormatted: '₹999',
      billing: 'per year (Save 60%)',
      credits: 50,
      description: 'Best value for active teachers & exam controllers needing consistent papers.',
      popular: true,
      color: 'border-blue-500 ring-2 ring-blue-500/20 bg-gradient-to-b from-blue-50/40 to-white',
      badge: 'Best Value • 50 Papers / Mo',
      features: [
        '50 Credits per month (Resets monthly)',
        'Full AI & Board Syllabus Engine',
        'Official School Branding & Logo Header',
        'Custom Watermark Opacity & Signatures',
        'Step-by-Step Marking Schemes',
        'Priority Customer Support'
      ]
    },
    {
      id: 'Unlimited' as SubscriptionPlan,
      name: 'Unlimited Plan',
      price: 399,
      priceFormatted: '₹399',
      billing: 'per month',
      credits: 99999,
      description: 'Ultimate freedom for coaching institutes, departments & school admins.',
      popular: false,
      color: 'border-purple-300 hover:border-purple-500 bg-purple-50/20',
      badge: 'Unlimited Everything',
      features: [
        'Unlimited Question Paper Generation',
        'Unlimited AI Generator Usage',
        'Unlimited Question Bank Access',
        'Unlimited Smart Paper Builder',
        'HD Vector PDF & Word Export',
        'Dedicated Academic Consultant'
      ]
    }
  ];

  const handleOpenCheckout = (planId: SubscriptionPlan) => {
    setSelectedPlan(planId);
    setPaymentStep('details');
    setErrorNotice('');
    setShowCheckoutModal(true);
  };

  const getPlanDetails = (pName: SubscriptionPlan) => {
    return plans.find(p => p.id === pName) || plans[1];
  };

  // Payment Execution & Verification Flow
  const processPaymentFlow = (simulateOutcome: 'success' | 'failed') => {
    setPaymentStep('processing');
    setErrorNotice('');

    const targetPlan = getPlanDetails(selectedPlan);
    const generatedTxnId = 'TXN_' + Math.floor(1000000000 + Math.random() * 9000000000);
    const currentDate = new Date().toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    const expiryDateObj = new Date();
    if (selectedPlan === 'Pro') {
      expiryDateObj.setFullYear(expiryDateObj.getFullYear() + 1);
    } else {
      expiryDateObj.setMonth(expiryDateObj.getMonth() + 1);
    }
    const formattedExpiry = expiryDateObj.toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric'
    });

    const methodLabel = paymentMethod === 'upi' 
      ? `UPI (${upiId || 'GPay'})` 
      : paymentMethod === 'card' 
      ? 'Credit/Debit Card (•••• 4242)' 
      : 'Net Banking';

    // Simulate 2.5s bank verification
    setTimeout(() => {
      if (simulateOutcome === 'success') {
        const successfulTxn: PaymentTransaction = {
          id: 'txn_' + Date.now(),
          transactionId: generatedTxnId,
          planName: selectedPlan,
          amount: targetPlan.price,
          credits: targetPlan.credits,
          paymentMethod: methodLabel,
          status: 'Success',
          paymentDate: currentDate,
          expiryDate: formattedExpiry
        };

        // 1. Store transaction
        addStoredTransaction(successfulTxn);
        setCurrentTxn(successfulTxn);

        // 2. Activate Subscription
        onUpgradePlan(selectedPlan, targetPlan.credits);

        // 3. Update Result UI
        setPaymentResultStatus('Success');
        setPaymentStep('result');
        setSuccessNotice(`Payment Verified! Subscription for ${selectedPlan} Plan is now Active.`);
      } else {
        const failedTxn: PaymentTransaction = {
          id: 'txn_' + Date.now(),
          transactionId: generatedTxnId,
          planName: selectedPlan,
          amount: targetPlan.price,
          credits: targetPlan.credits,
          paymentMethod: methodLabel,
          status: 'Failed',
          paymentDate: currentDate,
          expiryDate: formattedExpiry,
          failureReason: 'Bank gateway declined transaction (Insufficient response or timed out).'
        };

        // Store failed transaction log
        addStoredTransaction(failedTxn);
        setCurrentTxn(failedTxn);

        // DO NOT activate subscription
        setPaymentResultStatus('Failed');
        setPaymentStep('result');
        setErrorNotice('Payment Failed! Subscription was not activated.');
      }
    }, 2200);
  };

  const handleCancelPayment = () => {
    const targetPlan = getPlanDetails(selectedPlan);
    const generatedTxnId = 'TXN_' + Math.floor(1000000000 + Math.random() * 9000000000);
    const currentDate = new Date().toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });

    const cancelledTxn: PaymentTransaction = {
      id: 'txn_' + Date.now(),
      transactionId: generatedTxnId,
      planName: selectedPlan,
      amount: targetPlan.price,
      credits: targetPlan.credits,
      paymentMethod: paymentMethod.toUpperCase(),
      status: 'Cancelled',
      paymentDate: currentDate,
      expiryDate: 'N/A',
      failureReason: 'Cancelled by user before completion.'
    };

    addStoredTransaction(cancelledTxn);
    setShowCheckoutModal(false);
    setErrorNotice('Payment Cancelled. No charges were made.');
    setTimeout(() => setErrorNotice(''), 4000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300 max-w-full">
      
      {/* Page Title Header */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-10 translate-x-8 -translate-y-8">
          <Crown className="w-96 h-96 text-white" />
        </div>

        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-200 border border-blue-400/30 text-xs font-bold backdrop-blur-sm">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            Upian Pro Premium Subscriptions
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold font-display tracking-tight text-white">
            Unlock Board-Quality Question Paper Generation
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Choose a flexible credit plan or unlock unlimited paper generation with automated answers, official school headers, and instant PDF downloads.
          </p>

          {/* Current Status Box */}
          <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
            <div className="inline-flex flex-wrap items-center gap-3 bg-white/10 backdrop-blur-md p-3 px-4 rounded-xl border border-white/15 text-xs">
              <span className="text-slate-300 font-medium">Your Active Plan:</span>
              <span className="font-bold px-2.5 py-0.5 rounded-md bg-amber-400 text-slate-950 text-xs">
                {user.plan || 'Trial'}
              </span>
              <span className="text-slate-400">•</span>
              <span className="text-slate-300 font-medium">Credits Left:</span>
              <span className="font-bold text-white flex items-center gap-1">
                <Gem className="w-3.5 h-3.5 text-cyan-300 fill-cyan-300/30 shrink-0" />
                <span>{user.isUnlimited ? '💎 Unlimited' : `💎 ${user.credits}`}</span>
              </span>
            </div>

            {onNavigateToHistory && (
              <button
                onClick={onNavigateToHistory}
                className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-xl text-xs font-bold transition-all backdrop-blur-sm"
              >
                <Receipt className="w-4 h-4 text-blue-300" />
                <span>Purchase History & Invoices</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {successNotice && (
        <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 text-sm font-semibold flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{successNotice}</span>
          </div>
          <button onClick={() => setSuccessNotice('')} className="text-emerald-700 hover:text-emerald-950">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorNotice && (
        <div className="p-4 bg-rose-50 rounded-2xl border border-rose-200 text-rose-900 text-sm font-semibold flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5">
            <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>{errorNotice}</span>
          </div>
          <button onClick={() => setErrorNotice('')} className="text-rose-700 hover:text-rose-950">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => {
          const isCurrent = user.plan === plan.id;

          return (
            <div
              key={plan.id}
              className={`bg-white rounded-3xl p-6 border shadow-sm flex flex-col justify-between relative transition-all hover:shadow-lg ${plan.color}`}
            >
              {plan.popular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-3.5 py-1 rounded-full text-[10px] font-extrabold tracking-wider uppercase shadow-md">
                  RECOMMENDED FOR TEACHERS
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                    {plan.badge}
                  </span>
                  {isCurrent && (
                    <span className="text-[10px] font-extrabold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                      CURRENT PLAN
                    </span>
                  )}
                </div>

                <h3 className="text-lg font-bold text-slate-900">{plan.name}</h3>
                <p className="text-xs text-slate-500 mt-1 min-h-[32px]">{plan.description}</p>

                <div className="my-5 flex items-baseline gap-1">
                  <span className="text-3xl font-black text-slate-900 tracking-tight">{plan.priceFormatted}</span>
                  <span className="text-xs font-medium text-slate-500">{plan.billing}</span>
                </div>

                <div className="space-y-2.5 pt-4 border-t border-slate-100 mb-6">
                  {plan.features.map((feat, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-slate-700">
                      <Check className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => handleOpenCheckout(plan.id)}
                disabled={isCurrent}
                className={`w-full py-3 rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 ${
                  isCurrent
                    ? 'bg-slate-100 text-slate-400 cursor-default shadow-none'
                    : plan.popular
                    ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20'
                    : 'bg-slate-900 hover:bg-slate-800 text-white'
                }`}
              >
                <span>{isCurrent ? 'Active Plan' : `Subscribe (${plan.priceFormatted})`}</span>
                {!isCurrent && <ArrowRight className="w-3.5 h-3.5" />}
              </button>

            </div>
          );
        })}
      </div>

      {/* Checkout Payment Gateway Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden relative flex flex-col">
            
            {/* Modal Top Banner */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-600 rounded-lg text-white">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">Upian Pro Payment Gateway</div>
                  <h3 className="text-sm font-bold">Subscribe to {selectedPlan} Plan</h3>
                </div>
              </div>
              <button
                onClick={handleCancelPayment}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body depending on Step */}
            <div className="p-6 space-y-4 text-xs">

              {/* STEP 1: PAYMENT DETAILS */}
              {paymentStep === 'details' && (
                <div className="space-y-4">
                  
                  {/* Order Summary */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between">
                    <div>
                      <p className="font-bold text-slate-900 text-sm">{selectedPlan} Plan</p>
                      <p className="text-[11px] text-slate-500">
                        {getPlanDetails(selectedPlan).billing}
                      </p>
                      <p className="text-[10px] text-blue-600 font-semibold mt-1 flex items-center gap-1">
                        <Gem className="w-3 h-3 text-cyan-500 fill-cyan-500/20" />
                        <span>
                          {selectedPlan === 'Unlimited' ? 'Unlimited Papers' : `+${getPlanDetails(selectedPlan).credits} Credits / Mo`}
                        </span>
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-extrabold text-blue-700">
                        {getPlanDetails(selectedPlan).priceFormatted}
                      </p>
                      <p className="text-[10px] text-slate-400">Incl. All Taxes & GST</p>
                    </div>
                  </div>

                  {/* Payment Method Selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-2">
                      Select Payment Method
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('upi')}
                        className={`py-2.5 px-2 rounded-xl border font-bold text-[11px] transition-all flex items-center justify-center gap-1.5 ${
                          paymentMethod === 'upi' ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <QrCode className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>UPI / GPay</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('card')}
                        className={`py-2.5 px-2 rounded-xl border font-bold text-[11px] transition-all flex items-center justify-center gap-1.5 ${
                          paymentMethod === 'card' ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <CreditCard className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>Card</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('netbanking')}
                        className={`py-2.5 px-2 rounded-xl border font-bold text-[11px] transition-all flex items-center justify-center gap-1.5 ${
                          paymentMethod === 'netbanking' ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-xs' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                        <span>NetBanking</span>
                      </button>
                    </div>
                  </div>

                  {/* Payment Inputs */}
                  {paymentMethod === 'upi' && (
                    <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-700">Enter UPI ID / VPA</label>
                      <input
                        type="text"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        placeholder="teacher@okicici or mobile@upi"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-blue-500/20 outline-none"
                      />
                      <p className="text-[10px] text-slate-500">
                        Supports Google Pay, PhonePe, Paytm, BHIM, and Cred UPI.
                      </p>
                    </div>
                  )}

                  {paymentMethod === 'card' && (
                    <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-700">Card Details</label>
                      <input
                        type="text"
                        placeholder="4111 2222 3333 4444"
                        className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono outline-none"
                      />
                      <div className="grid grid-cols-2 gap-2">
                        <input type="text" placeholder="MM/YY" className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs outline-none" />
                        <input type="password" maxLength={3} placeholder="CVV" className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs outline-none" />
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'netbanking' && (
                    <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-700">Select Bank</label>
                      <select className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold outline-none">
                        <option>State Bank of India (SBI)</option>
                        <option>HDFC Bank</option>
                        <option>ICICI Bank</option>
                        <option>Axis Bank</option>
                        <option>Kotak Mahindra Bank</option>
                      </select>
                    </div>
                  )}

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-[11px] leading-snug">
                    <span className="font-bold">Strict Verification Guarantee:</span> Your subscription will ONLY activate after payment verification succeeds from the bank gateway.
                  </div>

                  {/* Actions: Proceed to Pay vs Simulate Fail vs Cancel */}
                  <div className="space-y-2 pt-2">
                    <button
                      onClick={() => processPaymentFlow('success')}
                      className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Pay {getPlanDetails(selectedPlan).priceFormatted} & Verify Payment</span>
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => processPaymentFlow('failed')}
                        className="flex-1 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl font-bold text-[11px] transition-colors"
                      >
                        Simulate Payment Failure
                      </button>
                      <button
                        onClick={handleCancelPayment}
                        className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-[11px] transition-colors"
                      >
                        Cancel Payment
                      </button>
                    </div>
                  </div>

                </div>
              )}

              {/* STEP 2: PROCESSING STATE */}
              {paymentStep === 'processing' && (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 bg-blue-50 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
                  <div>
                    <h3 className="text-base font-bold text-slate-900">Verifying Payment with Bank...</h3>
                    <p className="text-xs text-slate-500 mt-1">Please do not refresh or close this window.</p>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 font-mono inline-block">
                    Status: <span className="font-bold text-blue-600">Processing Verification</span>
                  </div>
                </div>
              )}

              {/* STEP 3: RESULT STATE */}
              {paymentStep === 'result' && (
                <div className="py-4 space-y-4">
                  {paymentResultStatus === 'Success' && (
                    <div className="text-center space-y-3">
                      <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                        <CheckCircle2 className="w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900">Payment Verified & Successful!</h3>
                      <p className="text-xs text-slate-600 max-w-sm mx-auto">
                        Your transaction was verified by the payment gateway. Subscription to <strong className="text-blue-700">{selectedPlan} Plan</strong> is now active.
                      </p>

                      {currentTxn && (
                        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-left text-xs space-y-2">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Transaction ID</span>
                            <span className="font-mono font-bold text-slate-900">{currentTxn.transactionId}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Plan Name</span>
                            <span className="font-bold text-blue-700">{currentTxn.planName} Plan</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Amount Paid</span>
                            <span className="font-extrabold text-slate-900">₹{currentTxn.amount}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Credits Granted</span>
                            <span className="font-bold text-emerald-700">
                              {currentTxn.credits === 99999 ? 'Unlimited Papers' : `${currentTxn.credits} Credits`}
                            </span>
                          </div>
                        </div>
                      )}

                      <button
                        onClick={() => setShowCheckoutModal(false)}
                        className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold shadow-md transition-all"
                      >
                        Start Generating Papers
                      </button>
                    </div>
                  )}

                  {paymentResultStatus === 'Failed' && (
                    <div className="text-center space-y-3">
                      <div className="w-14 h-14 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
                        <XCircle className="w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900">Payment Failed</h3>
                      <p className="text-xs text-rose-600 font-semibold max-w-sm mx-auto">
                        Bank verification declined. Your subscription was NOT activated and no credits were added.
                      </p>

                      {currentTxn && (
                        <div className="bg-rose-50 p-4 rounded-xl border border-rose-200 text-left text-xs space-y-2 text-rose-900">
                          <div className="flex justify-between">
                            <span className="text-rose-700">Transaction ID</span>
                            <span className="font-mono font-bold">{currentTxn.transactionId}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-rose-700">Failure Reason</span>
                            <span className="font-medium text-rose-800">{currentTxn.failureReason}</span>
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2">
                        <button
                          onClick={() => setPaymentStep('details')}
                          className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-all"
                        >
                          Retry Payment
                        </button>
                        <button
                          onClick={() => setShowCheckoutModal(false)}
                          className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold transition-all"
                        >
                          Close
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
