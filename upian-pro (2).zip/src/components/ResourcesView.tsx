import React, { useState } from 'react';
import { 
  BookOpen, 
  Download, 
  Search, 
  FileText, 
  Award, 
  Sparkles, 
  CheckCircle2, 
  ExternalLink,
  Eye,
  X,
  Filter,
  GraduationCap
} from 'lucide-react';
import { MOCK_RESOURCES } from '../data/mockData';
import { ResourceCategory, ResourceMaterial } from '../types';

export const ResourcesView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activePreviewResource, setActivePreviewResource] = useState<ResourceMaterial | null>(null);

  const categories: { label: string; value: string; count: number }[] = [
    { label: 'All Resources', value: 'all', count: MOCK_RESOURCES.length },
    { label: 'NCERT Books', value: 'NCERT Books', count: MOCK_RESOURCES.filter(r => r.category === 'NCERT Books').length },
    { label: 'Previous Year Papers', value: 'Previous Year Papers', count: MOCK_RESOURCES.filter(r => r.category === 'Previous Year Papers').length },
    { label: 'Chapter Short Notes', value: 'Short Notes', count: MOCK_RESOURCES.filter(r => r.category === 'Short Notes').length },
    { label: 'Toppers Notes', value: 'Handwritten Notes', count: MOCK_RESOURCES.filter(r => r.category === 'Handwritten Notes').length },
    { label: 'Sample Papers', value: 'Sample Papers', count: MOCK_RESOURCES.filter(r => r.category === 'Sample Papers').length },
    { label: 'Worksheets', value: 'Worksheets', count: MOCK_RESOURCES.filter(r => r.category === 'Worksheets').length }
  ];

  const filtered = MOCK_RESOURCES.filter(r => {
    if (selectedCategory !== 'all' && r.category !== selectedCategory) return false;
    if (selectedClass !== 'all' && r.classLevel !== selectedClass) return false;
    if (selectedSubject !== 'all' && r.subject.toLowerCase() !== selectedSubject.toLowerCase()) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        r.title.toLowerCase().includes(q) ||
        r.subject.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleDownload = (res: ResourceMaterial) => {
    // Generate a dummy text/PDF download Blob
    const content = `%PDF-1.4\n1 0 obj\n<< /Title (${res.title}) /Author (Upian Pro) >>\nendobj\n... [Official Board Resource: ${res.title}]`;
    const blob = new Blob([content], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${res.title.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Title Header */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-orange-600 text-white rounded-3xl p-6 sm:p-8 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold mb-3 backdrop-blur-md">
            <BookOpen className="w-3.5 h-3.5 text-amber-100" />
            Free Academic Study Material Vault
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display tracking-tight text-white">
            100% Free NCERT, PYQs & Topper Notes
          </h1>
          <p className="text-xs sm:text-sm text-amber-50 mt-1">
            Access verified NCERT books, last 10 years solved board papers, chapter revision notes, sample papers, and practice worksheets.
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-3">
          <div className="bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-center text-white">
            <div className="text-2xl font-black">{MOCK_RESOURCES.length * 150}+</div>
            <div className="text-[10px] uppercase font-bold text-amber-100">Free Downloads</div>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="bg-white rounded-2xl p-2 border border-slate-200 shadow-xs flex items-center gap-1.5 overflow-x-auto scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.value}
            onClick={() => setSelectedCategory(cat.value)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center gap-2 ${
              selectedCategory === cat.value
                ? 'bg-amber-500 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <span>{cat.label}</span>
            <span
              className={`px-1.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                selectedCategory === cat.value ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
              }`}
            >
              {cat.count}
            </span>
          </button>
        ))}
      </div>

      {/* Filters & Search Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 text-slate-500 font-bold">
            <Filter className="w-3.5 h-3.5" />
            <span>Filters:</span>
          </div>

          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-700 outline-none"
          >
            <option value="all">All Classes (9 to 12)</option>
            <option value="9">Class 9</option>
            <option value="10">Class 10</option>
            <option value="11">Class 11</option>
            <option value="12">Class 12</option>
          </select>

          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-semibold text-slate-700 outline-none"
          >
            <option value="all">All Subjects</option>
            <option value="Science">Science</option>
            <option value="Physics">Physics</option>
            <option value="Chemistry">Chemistry</option>
            <option value="Biology">Biology</option>
            <option value="Mathematics">Mathematics</option>
          </select>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search NCERT, PYQs, Notes..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 outline-none focus:ring-2 focus:ring-amber-500/20"
          />
        </div>
      </div>

      {/* Resource Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((res) => (
          <div
            key={res.id}
            className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:border-amber-400 hover:shadow-md transition-all flex flex-col justify-between space-y-4 group"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[10px] font-bold">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-200/60">
                  {res.category}
                </span>
                <span className="text-slate-400 font-medium">{res.dateAdded}</span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm leading-snug group-hover:text-amber-700 transition-colors">
                {res.title}
              </h3>

              <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                {res.description}
              </p>

              <div className="text-[11px] font-semibold text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100 flex items-center justify-between">
                <span>{res.board} • Class {res.classLevel}</span>
                <span className="text-amber-700">{res.subject}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-400 text-[11px] font-medium">{res.fileSize} • {res.downloads.toLocaleString()} downloads</span>
              
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setActivePreviewResource(res)}
                  className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                  title="Preview Material"
                >
                  <Eye className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleDownload(res)}
                  className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg transition-all shadow-xs flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 bg-white rounded-3xl border border-slate-200">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          <p className="font-bold text-slate-700 text-sm">No resources match your search filters.</p>
          <p className="text-xs text-slate-400 mt-1">Try switching categories or clearing search keywords.</p>
        </div>
      )}

      {/* Resource PDF Preview Modal */}
      {activePreviewResource && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden relative flex flex-col max-h-[85vh]">
            
            <div className="bg-amber-600 p-4 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-200" />
                <div>
                  <h3 className="font-bold text-sm leading-none">{activePreviewResource.title}</h3>
                  <p className="text-[10px] text-amber-100 mt-0.5">
                    {activePreviewResource.category} • Class {activePreviewResource.classLevel} {activePreviewResource.subject}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setActivePreviewResource(null)}
                className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 flex-1">
              <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 text-amber-900 text-xs leading-relaxed">
                <p className="font-bold mb-1">Resource Information:</p>
                <p>{activePreviewResource.description}</p>
              </div>

              {/* Simulated Document Viewer Canvas */}
              <div className="border border-slate-200 rounded-2xl p-6 bg-slate-50 shadow-inner font-serif text-slate-800 space-y-4 text-xs">
                <div className="text-center border-b pb-3 border-slate-200">
                  <h2 className="font-bold text-base text-slate-900">{activePreviewResource.title}</h2>
                  <p className="text-slate-500 font-sans text-[11px] mt-1">Curriculum & Marking Matrix • Upian Pro Verified</p>
                </div>

                <div className="space-y-3 leading-relaxed font-sans text-slate-700">
                  <p className="font-bold text-slate-900">1. Chapter Key Concepts & Definitions</p>
                  <p>
                    All concepts in this document have been aligned with official CBSE / ICSE curriculum guidelines for the 2026-27 academic session. Includes solved exemplars, board marking schemes, and step-by-step formula derivations.
                  </p>

                  <p className="font-bold text-slate-900 mt-4">2. Sample Board Evaluation Weightage</p>
                  <ul className="list-disc pl-5 space-y-1 text-slate-600">
                    <li>1 Mark MCQs & Assertion Reason: 20%</li>
                    <li>2 & 3 Marks Short Answers: 40%</li>
                    <li>4 Marks Case-Study Application: 15%</li>
                    <li>5 Marks Long Analytical Questions: 25%</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
              <span className="text-xs text-slate-500 font-medium">
                {activePreviewResource.fileSize} • PDF Document
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActivePreviewResource(null)}
                  className="px-4 py-2 bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
                >
                  Close Preview
                </button>
                <button
                  onClick={() => {
                    handleDownload(activePreviewResource);
                    setActivePreviewResource(null);
                  }}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>Download PDF ({activePreviewResource.fileSize})</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
