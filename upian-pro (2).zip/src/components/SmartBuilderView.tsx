import React, { useState } from 'react';
import { 
  Layers, 
  Plus, 
  GripVertical, 
  Trash2, 
  ArrowUp, 
  ArrowDown, 
  Eye, 
  FileText, 
  Building2, 
  Printer, 
  Download, 
  Save, 
  Sparkles, 
  PlusCircle, 
  Edit3, 
  CheckCircle2,
  X,
  RefreshCw,
  Database,
  Image as ImageIcon,
  Upload,
  Sliders,
  Copy
} from 'lucide-react';
import { Question, QuestionPaper, SchoolBranding, PaperSection } from '../types';
import { MOCK_QUESTION_BANK } from '../data/mockData';
import { DIAGRAM_TEMPLATES } from '../utils/diagrams';

interface SmartBuilderViewProps {
  initialPaper?: QuestionPaper | null;
  branding: SchoolBranding;
  onSavePaper: (paper: QuestionPaper) => void;
  onPreviewPaper: (paper: QuestionPaper) => void;
}

export const SmartBuilderView: React.FC<SmartBuilderViewProps> = ({
  initialPaper,
  branding,
  onSavePaper,
  onPreviewPaper
}) => {
  // Local working paper state
  const [paperTitle, setPaperTitle] = useState<string>(
    initialPaper?.title || 'Class 10 Physics Mid-Term Examination 2026-27'
  );
  const [board, setBoard] = useState<string>(initialPaper?.board || 'CBSE');
  const [classLevel, setClassLevel] = useState<string>(initialPaper?.classLevel || '10');
  const [subject, setSubject] = useState<string>(initialPaper?.subject || 'Physics');
  const [timeAllowed, setTimeAllowed] = useState<number>(initialPaper?.timeAllowedMinutes || 180);

  // Sections list
  const [sections, setSections] = useState<PaperSection[]>(
    initialPaper?.sections || [
      {
        id: 'sec_1',
        title: 'SECTION A - Objective & Multiple Choice Questions (1 Mark Each)',
        questions: [MOCK_QUESTION_BANK[0], MOCK_QUESTION_BANK[1]]
      },
      {
        id: 'sec_2',
        title: 'SECTION B - Short Answer Type I (2 Marks Each)',
        questions: [MOCK_QUESTION_BANK[6]]
      },
      {
        id: 'sec_3',
        title: 'SECTION C - Long Answer Questions (5 Marks Each)',
        questions: [MOCK_QUESTION_BANK[12]]
      }
    ]
  );

  // Unified Modal for adding questions (Prebuilt Bank, AI Suggested 40-50, or Custom Manual)
  const [showQuestionModal, setShowQuestionModal] = useState<boolean>(false);
  const [targetSectionId, setTargetSectionId] = useState<string>('');

  // Custom question state
  const [showAddCustomModal, setShowAddCustomModal] = useState<boolean>(false);
  const [editingDiagramQId, setEditingDiagramQId] = useState<string | null>(null);
  const [customText, setCustomText] = useState<string>('');
  const [customType, setCustomType] = useState<any>('short');
  const [customMarks, setCustomMarks] = useState<number>(2);
  const [customOptions, setCustomOptions] = useState<string>('');
  const [customAnswer, setCustomAnswer] = useState<string>('');

  // Live preview toggle mode
  const [viewMode, setViewMode] = useState<'split' | 'editor' | 'preview'>('split');

  // Calculate total questions & total marks dynamically
  const allQuestions = sections.flatMap(s => s.questions);
  const totalQuestionsCount = allQuestions.length;
  const totalMarksCount = allQuestions.reduce((sum, q) => sum + q.marks, 0);

  // Reordering helpers
  const moveQuestion = (sectionIdx: number, questionIdx: number, direction: 'up' | 'down') => {
    const updatedSections = [...sections];
    const targetQuestions = [...updatedSections[sectionIdx].questions];
    
    if (direction === 'up' && questionIdx > 0) {
      const temp = targetQuestions[questionIdx];
      targetQuestions[questionIdx] = targetQuestions[questionIdx - 1];
      targetQuestions[questionIdx - 1] = temp;
    } else if (direction === 'down' && questionIdx < targetQuestions.length - 1) {
      const temp = targetQuestions[questionIdx];
      targetQuestions[questionIdx] = targetQuestions[questionIdx + 1];
      targetQuestions[questionIdx + 1] = temp;
    }

    updatedSections[sectionIdx].questions = targetQuestions;
    setSections(updatedSections);
  };

  const removeQuestion = (sectionIdx: number, questionIdx: number) => {
    const updatedSections = [...sections];
    updatedSections[sectionIdx].questions = updatedSections[sectionIdx].questions.filter((_, idx) => idx !== questionIdx);
    setSections(updatedSections);
  };

  const duplicateQuestion = (sectionIdx: number, questionIdx: number) => {
    const updatedSections = [...sections];
    const targetQ = updatedSections[sectionIdx].questions[questionIdx];
    const dupQ: Question = {
      ...targetQ,
      id: 'dup_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6)
    };
    updatedSections[sectionIdx].questions.splice(questionIdx + 1, 0, dupQ);
    setSections(updatedSections);
  };

  const handleAddSection = () => {
    const newSec: PaperSection = {
      id: 'sec_' + Date.now(),
      title: `SECTION ${String.fromCharCode(65 + sections.length)} - New Question Section`,
      questions: []
    };
    setSections([...sections, newSec]);
  };

  const handleAddCustomQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customText.trim()) return;

    const newQ: Question = {
      id: 'cust_' + Date.now(),
      text: customText,
      type: customType,
      marks: customMarks,
      subject,
      classLevel: classLevel as any,
      chapter: 'Custom Section',
      options: customType === 'mcq' ? customOptions.split(',').map(o => o.trim()).filter(Boolean) : undefined,
      answer: customAnswer || 'Answer provided by subject teacher.'
    };

    const updatedSections = sections.map(s => {
      if (s.id === targetSectionId) {
        return {
          ...s,
          questions: [...s.questions, newQ]
        };
      }
      return s;
    });

    setSections(updatedSections);
    setShowAddCustomModal(false);
    setCustomText('');
    setCustomAnswer('');
  };

  const handleAddFromBank = (question: Question) => {
    if (sections.length === 0) return;
    const target = sections[0].id;
    setSections(sections.map(s => {
      if (s.id === target) {
        return {
          ...s,
          questions: [...s.questions, question]
        };
      }
      return s;
    }));
  };

  const buildQuestionPaperObject = (): QuestionPaper => {
    return {
      id: initialPaper?.id || 'pap_' + Date.now(),
      title: paperTitle,
      board,
      classLevel: classLevel as any,
      subject,
      medium: 'English',
      timeAllowedMinutes: timeAllowed,
      totalMarks: totalMarksCount,
      createdMode: 'builder',
      createdAt: new Date().toISOString(),
      status: 'published',
      generalInstructions: [
        'All questions are compulsory.',
        'Read instructions carefully before answering.',
        'Total marks for each question are indicated against it.'
      ],
      sections,
      includeAnswerKey: true,
      schoolBranding: branding
    };
  };

  const handleSaveAndExport = () => {
    const paperObj = buildQuestionPaperObject();
    onSavePaper(paperObj);
    onPreviewPaper(paperObj);
  };

  // Helper for sequential global question numbering (Q1, Q2, Q3...)
  let globalQuestionCounter = 0;

  return (
    <div className="space-y-6">
      
      {/* Top Header & Actions */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold mb-2">
            <Layers className="w-3.5 h-3.5" />
            Mode C: Smart Drag & Drop Builder
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
            Smart Interactive Paper Builder
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Rearrange questions, edit text, auto-number sections, and preview live paper layout.
          </p>
        </div>

        {/* Action Controls & View Mode Toggles */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* View Toggles */}
          <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1 text-xs font-semibold">
            <button
              onClick={() => setViewMode('split')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                viewMode === 'split' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Split View
            </button>
            <button
              onClick={() => setViewMode('editor')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                viewMode === 'editor' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Editor Only
            </button>
            <button
              onClick={() => setViewMode('preview')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                viewMode === 'preview' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Live Preview
            </button>
          </div>

          <button
            onClick={() => {
              if (sections.length > 0) setTargetSectionId(sections[0].id);
              setShowQuestionModal(true);
            }}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4 text-emerald-600" />
            <span>Add From Question Bank / AI</span>
          </button>

          <button
            onClick={handleSaveAndExport}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-500/20 transition-all flex items-center gap-2"
          >
            <Printer className="w-4 h-4" />
            <span>Export & Print PDF ({totalMarksCount} Marks)</span>
          </button>

        </div>
      </div>

      {/* Paper Config Meta Settings Bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">Paper Title</label>
          <input
            type="text"
            value={paperTitle}
            onChange={(e) => setPaperTitle(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-800 outline-none"
          />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">Board & Class</label>
          <div className="grid grid-cols-2 gap-1.5">
            <input
              type="text"
              value={board}
              onChange={(e) => setBoard(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-800 outline-none"
            />
            <input
              type="text"
              value={classLevel}
              onChange={(e) => setClassLevel(e.target.value)}
              className="w-full px-2 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-800 outline-none"
            />
          </div>
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">Subject</label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-semibold text-slate-800 outline-none"
          />
        </div>
        <div>
          <label className="block text-[11px] font-semibold text-slate-500 mb-1">Time & Total Marks</label>
          <div className="flex items-center gap-2 font-bold text-slate-900 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <span>{timeAllowed} Mins</span>
            <span>•</span>
            <span className="text-indigo-600">{totalQuestionsCount} Qs</span>
            <span>•</span>
            <span className="text-emerald-600">{totalMarksCount} Marks</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Editor vs Live Preview */}
      <div className={`grid gap-6 ${viewMode === 'split' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
        
        {/* LEFT COLUMN: INTERACTIVE EDITOR */}
        {(viewMode === 'split' || viewMode === 'editor') && (
          <div className="space-y-4">
            
            <div className="flex items-center justify-between">
              <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-indigo-600" />
                <span>Question Paper Structure ({sections.length} Sections)</span>
              </h2>

              <button
                onClick={handleAddSection}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Add New Section
              </button>
            </div>

            {sections.map((section, sIdx) => (
              <div key={section.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
                
                {/* Section Header Input */}
                <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <input
                    type="text"
                    value={section.title}
                    onChange={(e) => {
                      const copy = [...sections];
                      copy[sIdx].title = e.target.value;
                      setSections(copy);
                    }}
                    className="w-full text-xs font-bold text-indigo-950 bg-indigo-50/60 px-3 py-1.5 rounded-lg border border-indigo-100 outline-none focus:border-indigo-400"
                  />

                  <button
                    onClick={() => {
                      setTargetSectionId(section.id);
                      setShowQuestionModal(true);
                    }}
                    className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-semibold whitespace-nowrap"
                  >
                    + Add Question
                  </button>
                </div>

                {/* Section Questions List */}
                <div className="space-y-2">
                  {section.questions.length === 0 ? (
                    <div className="p-4 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl">
                      No questions in this section yet. Click '+ Add Question' above.
                    </div>
                  ) : (
                    section.questions.map((q, qIdx) => {
                      globalQuestionCounter += 1;
                      const qNum = globalQuestionCounter;

                      return (
                        <div key={q.id || qIdx} className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 flex items-start gap-2.5 group">
                          
                          <div className="flex flex-col gap-1 text-slate-400 shrink-0 mt-0.5">
                            <button
                              onClick={() => moveQuestion(sIdx, qIdx, 'up')}
                              disabled={qIdx === 0}
                              className="hover:text-indigo-600 disabled:opacity-30"
                              title="Move Up"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => moveQuestion(sIdx, qIdx, 'down')}
                              disabled={qIdx === section.questions.length - 1}
                              className="hover:text-indigo-600 disabled:opacity-30"
                              title="Move Down"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-slate-900">Q{qNum}.</span>
                                <div className="flex items-center gap-1 bg-white border border-slate-200 px-1.5 py-0.5 rounded-md shadow-2xs">
                                  <span className="text-[10px] text-slate-500 font-semibold">Marks:</span>
                                  <input
                                    type="number"
                                    min="1"
                                    max="50"
                                    value={q.marks}
                                    onChange={(e) => {
                                      const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                                      const copy = [...sections];
                                      copy[sIdx].questions[qIdx].marks = val;
                                      setSections(copy);
                                    }}
                                    className="w-10 text-center text-[11px] font-bold text-indigo-700 outline-none bg-transparent"
                                  />
                                </div>
                              </div>

                              <div className="flex items-center gap-1 opacity-90 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                                <button
                                  type="button"
                                  onClick={() => duplicateQuestion(sIdx, qIdx)}
                                  className="p-1 text-slate-400 hover:text-indigo-600 transition-colors rounded-md hover:bg-slate-200/50"
                                  title="Duplicate Question"
                                >
                                  <Copy className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => removeQuestion(sIdx, qIdx)}
                                  className="p-1 text-slate-400 hover:text-rose-600 transition-colors rounded-md hover:bg-slate-200/50"
                                  title="Remove Question"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>

                            <textarea
                              rows={2}
                              value={q.text}
                              onChange={(e) => {
                                const copy = [...sections];
                                copy[sIdx].questions[qIdx].text = e.target.value;
                                setSections(copy);
                              }}
                              className="w-full text-xs font-medium text-slate-800 bg-white p-2 rounded-lg border border-slate-200 outline-none focus:border-indigo-400"
                            />

                            {/* Diagram Controls & Management Bar */}
                            <div className="pt-1.5 space-y-2">
                              <div className="flex items-center justify-between text-[11px]">
                                <button
                                  type="button"
                                  onClick={() => setEditingDiagramQId(editingDiagramQId === q.id ? null : q.id)}
                                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold transition-colors ${
                                    q.diagramUrl || q.hasDiagram
                                      ? 'bg-indigo-100 text-indigo-900 hover:bg-indigo-200'
                                      : 'bg-slate-200/80 text-slate-700 hover:bg-slate-300'
                                  }`}
                                >
                                  <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                                  <span>{q.diagramUrl || q.hasDiagram ? 'Edit Diagram (Attached)' : '+ Add Diagram'}</span>
                                </button>

                                {(q.diagramUrl || q.hasDiagram) && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const copy = [...sections];
                                      copy[sIdx].questions[qIdx].hasDiagram = false;
                                      copy[sIdx].questions[qIdx].diagramUrl = undefined;
                                      setSections(copy);
                                    }}
                                    className="text-rose-600 hover:underline font-semibold text-[10px]"
                                  >
                                    Remove Diagram
                                  </button>
                                )}
                              </div>

                              {/* Expanded Diagram Editor Panel */}
                              {editingDiagramQId === q.id && (
                                <div className="p-3 bg-white border border-indigo-200 rounded-xl space-y-3 shadow-xs">
                                  <div className="text-[11px] font-bold text-slate-800 flex items-center gap-1">
                                    <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                                    Diagram Settings & Upload
                                  </div>

                                  {/* Custom Diagram Upload */}
                                  <div className="flex items-center gap-2">
                                    <label className="flex-1 cursor-pointer bg-indigo-50 hover:bg-indigo-100 text-indigo-800 font-bold text-[11px] px-3 py-1.5 rounded-lg border border-indigo-200 flex items-center justify-center gap-1.5 transition-colors">
                                      <Upload className="w-3.5 h-3.5" />
                                      Upload Custom Diagram Image
                                      <input
                                        type="file"
                                        accept="image/*"
                                        className="hidden"
                                        onChange={(e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            const reader = new FileReader();
                                            reader.onload = (evt) => {
                                              const result = evt.target?.result as string;
                                              if (result) {
                                                const copy = [...sections];
                                                copy[sIdx].questions[qIdx].hasDiagram = true;
                                                copy[sIdx].questions[qIdx].diagramUrl = result;
                                                setSections(copy);
                                              }
                                            };
                                            reader.readAsDataURL(file);
                                          }
                                        }}
                                      />
                                    </label>
                                  </div>

                                  {/* Resize Diagram Width Slider */}
                                  {(q.diagramUrl || q.hasDiagram) && (
                                    <div className="space-y-1">
                                      <div className="flex items-center justify-between text-[10px] font-bold text-slate-700">
                                        <span>Diagram Width:</span>
                                        <span>{q.diagramWidth || 280}px</span>
                                      </div>
                                      <input
                                        type="range"
                                        min="150"
                                        max="450"
                                        step="10"
                                        value={q.diagramWidth || 280}
                                        onChange={(e) => {
                                          const copy = [...sections];
                                          copy[sIdx].questions[qIdx].diagramWidth = Number(e.target.value);
                                          setSections(copy);
                                        }}
                                        className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
                                      />
                                    </div>
                                  )}

                                  {/* Diagram Preview inside Editor */}
                                  {(q.diagramUrl || q.hasDiagram) && (
                                    <div className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-center">
                                      {q.diagramUrl?.startsWith('<svg') ? (
                                        <div
                                          className="mx-auto flex justify-center"
                                          style={{ width: `${Math.min(220, q.diagramWidth || 220)}px` }}
                                          dangerouslySetInnerHTML={{ __html: q.diagramUrl }}
                                        />
                                      ) : (
                                        <img
                                          src={q.diagramUrl}
                                          alt="Preview"
                                          className="mx-auto object-contain rounded max-h-32"
                                          style={{ width: `${Math.min(220, q.diagramWidth || 220)}px` }}
                                        />
                                      )}
                                    </div>
                                  )}

                                </div>
                              )}
                            </div>
                          </div>

                        </div>
                      );
                    })
                  )}
                </div>

                {/* Quick Add Inline Question Bar */}
                <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Type new question text here and press Enter to add..."
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                        const text = e.currentTarget.value.trim();
                        e.currentTarget.value = '';
                        const newQ: Question = {
                          id: 'q_inline_' + Date.now(),
                          text,
                          type: 'short',
                          marks: 2,
                          subject,
                          classLevel: classLevel as any,
                          chapter: 'Builder Direct',
                          answer: 'Answer to be evaluated by faculty.'
                        };
                        const copy = [...sections];
                        copy[sIdx].questions.push(newQ);
                        setSections(copy);
                      }
                    }}
                    className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-dashed border-slate-300 bg-slate-50/50 hover:bg-white focus:bg-white focus:border-indigo-400 outline-none text-slate-800 transition-colors"
                  />
                  <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md shrink-0">
                    Press Enter
                  </span>
                </div>

              </div>
            ))}

          </div>
        )}

        {/* RIGHT COLUMN: LIVE PAPER PREVIEW */}
        {(viewMode === 'split' || viewMode === 'preview') && (
          <div className="bg-slate-100 rounded-2xl p-6 border border-slate-300 shadow-inner space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-2">
                <Eye className="w-4 h-4 text-blue-600" />
                Live Exam Paper Preview (A4 Printable Format)
              </span>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-0.5 rounded-full">
                Auto-Formatted Header
              </span>
            </div>

            {/* Simulated Paper A4 Document */}
            <div className="bg-white rounded-xl shadow-md p-8 text-slate-900 space-y-6 font-serif border border-slate-200 relative overflow-hidden">
              
              {/* Optional Watermark */}
              {branding.watermarkText && (
                <div 
                  className="absolute inset-0 flex items-center justify-center pointer-events-none select-none text-center font-bold text-4xl text-slate-400 rotate-[-30deg] uppercase"
                  style={{ opacity: branding.watermarkOpacity || 0.08 }}
                >
                  {branding.watermarkText}
                </div>
              )}

              {/* School Header */}
              <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1 relative z-10">
                <h1 className="text-base sm:text-lg font-black tracking-wide uppercase">{branding.schoolName || 'ACADEMIC INSTITUTION'}</h1>
                <p className="text-[11px] font-sans font-medium text-slate-600">{branding.tagline}</p>
                <p className="text-[10px] font-sans text-slate-500">{branding.address}</p>
                <div className="mt-2 text-xs font-bold font-sans uppercase underline tracking-wider text-slate-900">
                  {paperTitle}
                </div>
                
                {/* Meta details bar */}
                <div className="pt-2 flex items-center justify-between text-[11px] font-sans font-bold text-slate-800 border-t border-slate-200 mt-2">
                  <span>Class: {classLevel} ({subject})</span>
                  <span>Time Allowed: {timeAllowed} Mins</span>
                  <span>Max Marks: {totalMarksCount}</span>
                </div>
              </div>

              {/* Instructions */}
              <div className="text-[11px] font-sans space-y-1 bg-slate-50 p-3 rounded-lg border border-slate-200">
                <span className="font-bold uppercase tracking-wider block">General Instructions:</span>
                <ol className="list-decimal pl-4 space-y-0.5 text-slate-700">
                  <li>All questions are compulsory.</li>
                  <li>Questions carrying 1 mark are objective type MCQs.</li>
                  <li>Draw neat and labeled diagrams wherever necessary.</li>
                </ol>
              </div>

              {/* Paper Sections Render */}
              <div className="space-y-6 font-serif text-xs">
                {(() => {
                  let previewCounter = 0;
                  return sections.map((sec) => (
                    <div key={sec.id} className="space-y-3">
                      <div className="text-center font-bold uppercase tracking-wider underline text-slate-900 font-sans">
                        {sec.title}
                      </div>

                      <div className="space-y-3">
                        {sec.questions.map((q) => {
                          previewCounter += 1;
                          return (
                            <div key={q.id} className="flex items-start justify-between gap-4">
                              <div className="space-y-1 flex-1">
                                <p className="leading-relaxed">
                                  <span className="font-bold">Q{previewCounter}.</span> {q.text}
                                </p>

                                {/* Diagram Rendering in Live Preview */}
                                {(q.diagramUrl || q.hasDiagram) && (
                                  <div className="my-2 text-center">
                                    {q.diagramUrl?.startsWith('<svg') ? (
                                      <div
                                        className="mx-auto flex justify-center"
                                        style={{ width: `${q.diagramWidth || 280}px`, maxWidth: '100%' }}
                                        dangerouslySetInnerHTML={{ __html: q.diagramUrl }}
                                      />
                                    ) : (
                                      <img
                                        src={q.diagramUrl}
                                        alt="Question Diagram"
                                        className="mx-auto object-contain rounded"
                                        style={{ width: `${q.diagramWidth || 280}px`, maxWidth: '100%' }}
                                      />
                                    )}
                                    {q.diagramCaption && (
                                      <div className="text-[10px] text-slate-600 font-sans italic mt-1">{q.diagramCaption}</div>
                                    )}
                                  </div>
                                )}
                                {q.options && q.options.length > 0 && (
                                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 pl-4 font-sans text-[11px] text-slate-700 pt-1">
                                    {q.options.map((opt, oIdx) => (
                                      <div key={oIdx}>({String.fromCharCode(97 + oIdx)}) {opt}</div>
                                    ))}
                                  </div>
                                )}
                              </div>
                              <span className="font-bold font-sans text-[11px] shrink-0">[{q.marks}]</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ));
                })()}
              </div>

              {/* Principal Signature Footer */}
              <div className="pt-8 border-t border-slate-200 flex items-center justify-between text-xs font-sans">
                <div className="text-center">
                  <div className="h-8 border-b border-dashed border-slate-400 w-32 mb-1" />
                  <span className="text-[10px] text-slate-500 font-semibold">Teacher / Examiner</span>
                </div>
                <div className="text-center">
                  <div className="h-8 border-b border-dashed border-slate-400 w-32 mb-1" />
                  <span className="text-[10px] text-slate-500 font-semibold">{branding.signatureTitle || 'Principal Signature'}</span>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Render Add Question Modal */}
        <AddQuestionModal
          isOpen={showQuestionModal}
          onClose={() => setShowQuestionModal(false)}
          targetSectionTitle={sections.find(s => s.id === targetSectionId)?.title || 'Question Paper Section'}
          onAddQuestions={(newQs) => {
            if (newQs.length === 0) return;
            const targetId = targetSectionId || (sections.length > 0 ? sections[0].id : '');
            if (!targetId) return;

            setSections(sections.map(s => {
              if (s.id === targetId) {
                return { ...s, questions: [...s.questions, ...newQs] };
              }
              return s;
            }));
          }}
          defaultSubject={subject}
          defaultBoard={board}
          defaultClass={classLevel}
        />

      </div>
    </div>
  );
};

// Drawer/Modal for adding questions: Prebuilt Bank, AI Suggested (40-50), Manual Custom
interface AddQuestionModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetSectionTitle: string;
  onAddQuestions: (questions: Question[]) => void;
  defaultSubject: string;
  defaultBoard: string;
  defaultClass: string;
}

const AddQuestionModal: React.FC<AddQuestionModalProps> = ({
  isOpen,
  onClose,
  targetSectionTitle,
  onAddQuestions,
  defaultSubject,
  defaultBoard,
  defaultClass
}) => {
  const [tab, setTab] = useState<'bank' | 'ai_suggest' | 'manual'>('bank');

  // Option 1: Prebuilt Question Bank Filters
  const [bankBoard, setBankBoard] = useState<string>('all');
  const [bankClass, setBankClass] = useState<string>('all');
  const [bankSubject, setBankSubject] = useState<string>(defaultSubject || 'all');
  const [bankChapter, setBankChapter] = useState<string>('all');
  const [bankMarks, setBankMarks] = useState<string>('all');
  const [bankDifficulty, setBankDifficulty] = useState<string>('all');
  const [bankSearch, setBankSearch] = useState<string>('');
  const [selectedBankIds, setSelectedBankIds] = useState<string[]>([]);

  // Option 2: AI Suggested Questions State
  const [aiBoard, setAiBoard] = useState<string>(defaultBoard || 'CBSE');
  const [aiClass, setAiClass] = useState<string>(defaultClass || '10');
  const [aiSubject, setAiSubject] = useState<string>(defaultSubject || 'Science');
  const [aiChapter, setAiChapter] = useState<string>('Light, Electricity, Acids & Bases');
  const [aiDifficulty, setAiDifficulty] = useState<string>('Medium');
  const [aiQuestions, setAiQuestions] = useState<Question[]>([]);
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [selectedAiIds, setSelectedAiIds] = useState<string[]>([]);

  // Option 3: Manual Custom State
  const [manualText, setManualText] = useState<string>('');
  const [manualMarks, setManualMarks] = useState<number>(2);
  const [manualType, setManualType] = useState<'mcq' | 'short' | 'long'>('short');
  const [manualOptions, setManualOptions] = useState<string>('Option A, Option B, Option C, Option D');
  const [manualAnswer, setManualAnswer] = useState<string>('');

  if (!isOpen) return null;

  // Filter Prebuilt Question Bank
  const filteredBankQuestions = MOCK_QUESTION_BANK.filter(q => {
    if (bankBoard !== 'all' && q.board && q.board !== bankBoard) return false;
    if (bankClass !== 'all' && q.classLevel && q.classLevel !== bankClass) return false;
    if (bankSubject !== 'all' && q.subject && q.subject.toLowerCase() !== bankSubject.toLowerCase()) return false;
    if (bankChapter !== 'all' && q.chapter && !q.chapter.toLowerCase().includes(bankChapter.toLowerCase())) return false;
    if (bankMarks !== 'all' && q.marks !== Number(bankMarks)) return false;
    if (bankDifficulty !== 'all' && q.difficulty && q.difficulty !== bankDifficulty) return false;
    if (bankSearch) {
      const s = bankSearch.toLowerCase();
      return q.text.toLowerCase().includes(s) || (q.chapter && q.chapter.toLowerCase().includes(s));
    }
    return true;
  });

  const toggleBankSelection = (id: string) => {
    setSelectedBankIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleAddSelectedBank = () => {
    const selected = MOCK_QUESTION_BANK.filter(q => selectedBankIds.includes(q.id));
    onAddQuestions(selected);
    setSelectedBankIds([]);
    onClose();
  };

  // Generate 40-50 AI Suggested Questions
  const handleGenerateAiSuggested = async () => {
    setIsGeneratingAi(true);
    setSelectedAiIds([]);

    try {
      const response = await fetch('/api/suggest-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          board: aiBoard,
          classLevel: aiClass,
          subject: aiSubject,
          chapter: aiChapter,
          difficulty: aiDifficulty,
          count: 40
        })
      });

      const data = await response.json();
      if (data.success && Array.isArray(data.questions) && data.questions.length > 0) {
        const formatted: Question[] = data.questions.map((q: any, idx: number) => ({
          id: `ai_sug_${Date.now()}_${idx}`,
          text: q.text,
          type: q.type || (q.marks === 1 ? 'mcq' : q.marks >= 5 ? 'long' : 'short'),
          marks: q.marks || 2,
          subject: aiSubject,
          classLevel: aiClass as any,
          chapter: aiChapter,
          options: q.options,
          answer: q.answer || 'Detailed solution provided by AI.',
          explanation: q.explanation || 'Step-by-step marking scheme.'
        }));
        setAiQuestions(formatted);
      } else {
        throw new Error('Fallback to local AI suggestion engine.');
      }
    } catch (err) {
      // Robust Fallback Generator producing 40 distinct AI suggested questions
      const generatedFallback: Question[] = [];
      const topics = aiChapter.split(',').map(t => t.trim()).filter(Boolean);
      const topName = topics[0] || aiSubject;

      for (let i = 1; i <= 40; i++) {
        let qType: 'mcq' | 'short' | 'long' | 'case_study' = 'short';
        let qMarks = 2;
        let options: string[] | undefined = undefined;

        if (i <= 15) {
          qType = 'mcq';
          qMarks = 1;
          options = [
            `Option A regarding ${topName}`,
            `Option B regarding ${topName}`,
            `Option C regarding ${topName}`,
            `Option D regarding ${topName}`
          ];
        } else if (i <= 25) {
          qType = 'short';
          qMarks = 2;
        } else if (i <= 32) {
          qType = 'short';
          qMarks = 3;
        } else if (i <= 36) {
          qType = 'case_study';
          qMarks = 4;
        } else {
          qType = 'long';
          qMarks = 5;
        }

        generatedFallback.push({
          id: `ai_sug_fallback_${Date.now()}_${i}`,
          text: `[Q${i} - ${aiSubject} (${topName})] State key principle ${i} and explain its practical significance in ${aiBoard} Class ${aiClass} curriculum.`,
          type: qType,
          marks: qMarks,
          subject: aiSubject,
          classLevel: aiClass as any,
          chapter: topName,
          options,
          answer: `Step-by-step model solution for Question ${i}. Ensure clear terminology and formulas where applicable.`,
          explanation: 'Full credit for proper steps and labeled diagrams.'
        });
      }
      setAiQuestions(generatedFallback);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const toggleAiSelection = (id: string) => {
    setSelectedAiIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleAddSelectedAi = () => {
    const selected = aiQuestions.filter(q => selectedAiIds.includes(q.id));
    onAddQuestions(selected);
    setSelectedAiIds([]);
    onClose();
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualText.trim()) return;

    const newQ: Question = {
      id: 'manual_' + Date.now(),
      text: manualText,
      type: manualType,
      marks: manualMarks,
      subject: defaultSubject || 'General',
      classLevel: (defaultClass || '10') as any,
      chapter: 'Teacher Custom Entry',
      options: manualType === 'mcq' ? manualOptions.split(',').map(o => o.trim()).filter(Boolean) : undefined,
      answer: manualAnswer || 'Answer provided by subject teacher.'
    };

    onAddQuestions([newQ]);
    setManualText('');
    setManualAnswer('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div>
            <h3 className="font-bold text-base flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-indigo-400" />
              Add Questions to "{targetSectionTitle}"
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select prebuilt questions, generate 40-50 AI suggested questions, or type manually.
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Option Tabs */}
        <div className="bg-slate-100 p-2 border-b border-slate-200 flex items-center gap-2 text-xs font-bold shrink-0">
          <button
            onClick={() => setTab('bank')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-2 ${
              tab === 'bank' ? 'bg-white text-indigo-900 shadow-xs border border-slate-200' : 'text-slate-600 hover:bg-slate-200/60'
            }`}
          >
            <Database className="w-4 h-4 text-emerald-600" />
            <span>Option 1: Prebuilt Question Bank</span>
          </button>

          <button
            onClick={() => {
              setTab('ai_suggest');
              if (aiQuestions.length === 0) {
                handleGenerateAiSuggested();
              }
            }}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-2 ${
              tab === 'ai_suggest' ? 'bg-white text-indigo-900 shadow-xs border border-slate-200' : 'text-slate-600 hover:bg-slate-200/60'
            }`}
          >
            <Sparkles className="w-4 h-4 text-purple-600" />
            <span>Option 2: AI Suggested Questions (40–50 Qs)</span>
          </button>

          <button
            onClick={() => setTab('manual')}
            className={`flex-1 py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-2 ${
              tab === 'manual' ? 'bg-white text-indigo-900 shadow-xs border border-slate-200' : 'text-slate-600 hover:bg-slate-200/60'
            }`}
          >
            <Edit3 className="w-4 h-4 text-blue-600" />
            <span>Option 3: Manual Custom Question</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto flex-1 text-xs space-y-4">
          
          {/* TAB 1: PREBUILT QUESTION BANK */}
          {tab === 'bank' && (
            <div className="space-y-4">
              
              {/* Filter Controls */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Board</label>
                  <select
                    value={bankBoard}
                    onChange={(e) => setBankBoard(e.target.value)}
                    className="w-full px-2 py-1 text-xs rounded-lg border border-slate-300 bg-white font-medium"
                  >
                    <option value="all">All Boards</option>
                    <option value="CBSE">CBSE</option>
                    <option value="ICSE">ICSE</option>
                    <option value="State Board (Maharashtra)">State Board</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Class</label>
                  <select
                    value={bankClass}
                    onChange={(e) => setBankClass(e.target.value)}
                    className="w-full px-2 py-1 text-xs rounded-lg border border-slate-300 bg-white font-medium"
                  >
                    <option value="all">All Classes</option>
                    {[9, 10, 11, 12].map(c => <option key={c} value={`${c}`}>Class {c}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Subject</label>
                  <select
                    value={bankSubject}
                    onChange={(e) => setBankSubject(e.target.value)}
                    className="w-full px-2 py-1 text-xs rounded-lg border border-slate-300 bg-white font-medium"
                  >
                    <option value="all">All Subjects</option>
                    <option value="Science">Science</option>
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Biology">Biology</option>
                    <option value="Mathematics">Mathematics</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Marks</label>
                  <select
                    value={bankMarks}
                    onChange={(e) => setBankMarks(e.target.value)}
                    className="w-full px-2 py-1 text-xs rounded-lg border border-slate-300 bg-white font-medium"
                  >
                    <option value="all">All Marks</option>
                    {[1, 2, 3, 4, 5].map(m => <option key={m} value={`${m}`}>{m} Mark(s)</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Difficulty</label>
                  <select
                    value={bankDifficulty}
                    onChange={(e) => setBankDifficulty(e.target.value)}
                    className="w-full px-2 py-1 text-xs rounded-lg border border-slate-300 bg-white font-medium"
                  >
                    <option value="all">All Levels</option>
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Hard">Hard</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 mb-0.5">Search</label>
                  <input
                    type="text"
                    value={bankSearch}
                    onChange={(e) => setBankSearch(e.target.value)}
                    placeholder="Search keywords..."
                    className="w-full px-2 py-1 text-xs rounded-lg border border-slate-300 bg-white font-medium outline-none"
                  />
                </div>
              </div>

              {/* Selection Bar */}
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="font-semibold text-slate-700">
                  Showing <span className="text-indigo-600 font-bold">{filteredBankQuestions.length}</span> Preloaded Questions
                </span>
                
                {selectedBankIds.length > 0 && (
                  <button
                    onClick={handleAddSelectedBank}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold shadow-xs flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Add ({selectedBankIds.length}) Selected to Paper</span>
                  </button>
                )}
              </div>

              {/* Questions List */}
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                {filteredBankQuestions.map((q) => {
                  const isSelected = selectedBankIds.includes(q.id);
                  return (
                    <div
                      key={q.id}
                      onClick={() => toggleBankSelection(q.id)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                        isSelected
                          ? 'bg-emerald-50/80 border-emerald-300 ring-1 ring-emerald-400'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {}} // Handled by container click
                        className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 mt-0.5 shrink-0"
                      />

                      <div className="space-y-1 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900">
                            {q.marks} {q.marks === 1 ? 'Mark' : 'Marks'} • {q.type.toUpperCase()} • {q.subject} ({q.chapter || 'General'})
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                            {q.difficulty || 'Medium'}
                          </span>
                        </div>
                        <p className="text-slate-800 font-medium text-xs">{q.text}</p>
                        {q.options && (
                          <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1">
                            {q.options.map((opt, oIdx) => (
                              <div key={oIdx}>({String.fromCharCode(97 + oIdx)}) {opt}</div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          )}

          {/* TAB 2: AI SUGGESTED QUESTIONS (40-50 QUESTIONS) */}
          {tab === 'ai_suggest' && (
            <div className="space-y-4">
              
              {/* Parameters & Regeneration Bar */}
              <div className="bg-purple-50/60 p-3.5 rounded-xl border border-purple-100 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                <div>
                  <label className="block text-[10px] font-bold text-purple-900 mb-0.5">Subject</label>
                  <input
                    type="text"
                    value={aiSubject}
                    onChange={(e) => setAiSubject(e.target.value)}
                    className="w-full px-2.5 py-1 text-xs rounded-lg border border-purple-200 bg-white font-semibold text-purple-950"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-purple-900 mb-0.5">Chapter / Topic</label>
                  <input
                    type="text"
                    value={aiChapter}
                    onChange={(e) => setAiChapter(e.target.value)}
                    className="w-full px-2.5 py-1 text-xs rounded-lg border border-purple-200 bg-white font-semibold text-purple-950"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-purple-900 mb-0.5">Difficulty</label>
                  <select
                    value={aiDifficulty}
                    onChange={(e) => setAiDifficulty(e.target.value)}
                    className="w-full px-2.5 py-1 text-xs rounded-lg border border-purple-200 bg-white font-semibold text-purple-950"
                  >
                    <option value="Balanced Mix">Balanced Mix</option>
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Hard">Hard</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleGenerateAiSuggested}
                  disabled={isGeneratingAi}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white rounded-xl font-bold text-xs shadow-md transition-all flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
                  <span>{isGeneratingAi ? 'Generating...' : 'Regenerate 40–50 Qs'}</span>
                </button>
              </div>

              {/* Selection Bar */}
              <div className="flex items-center justify-between text-xs pt-1">
                <span className="font-semibold text-slate-700">
                  Generated <span className="text-purple-700 font-bold">{aiQuestions.length}</span> AI Suggested Questions
                </span>
                
                {selectedAiIds.length > 0 && (
                  <button
                    onClick={handleAddSelectedAi}
                    className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-bold shadow-xs flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Add ({selectedAiIds.length}) Questions to Paper</span>
                  </button>
                )}
              </div>

              {/* Questions Grid */}
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                {isGeneratingAi ? (
                  <div className="p-12 text-center text-slate-500 space-y-2">
                    <Sparkles className="w-8 h-8 text-purple-600 animate-bounce mx-auto" />
                    <p className="font-bold text-slate-800 text-sm">Gemini AI is generating 40-50 questions...</p>
                    <p className="text-xs text-slate-500">Drafting MCQs, short answer, and long answer questions with answers.</p>
                  </div>
                ) : (
                  aiQuestions.map((q, idx) => {
                    const isSelected = selectedAiIds.includes(q.id);
                    return (
                      <div
                        key={q.id}
                        onClick={() => toggleAiSelection(q.id)}
                        className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                          isSelected
                            ? 'bg-purple-50/80 border-purple-300 ring-1 ring-purple-400'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 mt-0.5 shrink-0"
                        />

                        <div className="space-y-1 flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900">
                              #{idx + 1} • {q.marks} {q.marks === 1 ? 'Mark' : 'Marks'} ({q.type.toUpperCase()})
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-800">
                              AI Suggested
                            </span>
                          </div>
                          <p className="text-slate-800 font-medium text-xs">{q.text}</p>
                          {q.options && (
                            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 pt-1">
                              {q.options.map((opt, oIdx) => (
                                <div key={oIdx}>({String.fromCharCode(97 + oIdx)}) {opt}</div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

            </div>
          )}

          {/* TAB 3: MANUAL CUSTOM QUESTION */}
          {tab === 'manual' && (
            <form onSubmit={handleManualSubmit} className="space-y-4 max-w-lg mx-auto py-2">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Question Type</label>
                  <select
                    value={manualType}
                    onChange={(e) => setManualType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-medium text-slate-800"
                  >
                    <option value="short">Short Answer</option>
                    <option value="mcq">MCQ (Multiple Choice)</option>
                    <option value="long">Long Answer</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Marks</label>
                  <select
                    value={manualMarks}
                    onChange={(e) => setManualMarks(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-medium text-slate-800"
                  >
                    {[1, 2, 3, 4, 5].map(m => (
                      <option key={m} value={m}>{m} {m === 1 ? 'Mark' : 'Marks'}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Question Wording</label>
                <textarea
                  rows={4}
                  required
                  value={manualText}
                  onChange={(e) => setManualText(e.target.value)}
                  placeholder="Type your question statement here..."
                  className="w-full p-3 rounded-xl border border-slate-300 font-medium text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>

              {manualType === 'mcq' && (
                <div>
                  <label className="block font-bold text-slate-700 mb-1">MCQ Options (Comma separated)</label>
                  <input
                    type="text"
                    value={manualOptions}
                    onChange={(e) => setManualOptions(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-medium text-slate-800"
                  />
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 mb-1">Solution / Marking Answer (Optional)</label>
                <textarea
                  rows={2}
                  value={manualAnswer}
                  onChange={(e) => setManualAnswer(e.target.value)}
                  placeholder="Correct option or model solution for answer key..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium text-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-md"
                >
                  Insert Question
                </button>
              </div>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
