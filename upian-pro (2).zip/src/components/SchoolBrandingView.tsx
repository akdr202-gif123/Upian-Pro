import React, { useState } from 'react';
import { 
  Building2, 
  Upload, 
  Image, 
  CheckCircle, 
  Eye, 
  Sparkles, 
  PenTool, 
  Sliders, 
  Save 
} from 'lucide-react';
import { SchoolBranding } from '../types';

interface SchoolBrandingViewProps {
  branding: SchoolBranding;
  onSaveBranding: (branding: SchoolBranding) => void;
}

const PRESET_LOGOS = [
  'https://images.unsplash.com/photo-1592280771190-3e2e4d571952?auto=format&fit=crop&q=80&w=200',
  'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=200',
  'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=200'
];

const PRESET_SIGNATURES = [
  'https://images.unsplash.com/photo-1600132806370-bf17e65e942f?auto=format&fit=crop&q=80&w=300'
];

export const SchoolBrandingView: React.FC<SchoolBrandingViewProps> = ({
  branding,
  onSaveBranding
}) => {
  const [formState, setFormState] = useState<SchoolBranding>(branding);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormState(prev => ({ ...prev, logoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSignatureUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormState(prev => ({ ...prev, signatureUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveBranding(formState);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Title Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold mb-2">
            <Building2 className="w-3.5 h-3.5" />
            School Identity & Branding Configuration
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
            School Branding & Exam Header Customizer
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Upload your school logo, principal signature, custom watermark, and official affiliation details.
          </p>
        </div>

        {saveSuccess && (
          <div className="px-3.5 py-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>Branding Saved Successfully!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Step 1: School Details */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h2 className="font-bold text-slate-900 text-sm pb-3 border-b border-slate-100 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-600" />
            1. Institution Details
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            
            <div className="col-span-2 sm:col-span-1">
              <label className="block font-semibold text-slate-700 mb-1">School / Institute Full Name</label>
              <input
                type="text"
                required
                value={formState.schoolName}
                onChange={(e) => setFormState({ ...formState, schoolName: e.target.value })}
                placeholder="DELHI PUBLIC SCHOOL, VASANT KUNJ"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-bold uppercase text-slate-900 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
              />
            </div>

            <div className="col-span-2 sm:col-span-1">
              <label className="block font-semibold text-slate-700 mb-1">Tagline / Motto</label>
              <input
                type="text"
                value={formState.tagline}
                onChange={(e) => setFormState({ ...formState, tagline: e.target.value })}
                placeholder="Service Before Self | Affiliated to CBSE"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 text-slate-800 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
              />
            </div>

            <div className="col-span-2 sm:col-span-1">
              <label className="block font-semibold text-slate-700 mb-1">Address Line</label>
              <input
                type="text"
                value={formState.address}
                onChange={(e) => setFormState({ ...formState, address: e.target.value })}
                placeholder="Sector C, Pocket 5, Vasant Kunj, New Delhi - 110070"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 text-slate-800 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
              />
            </div>

            <div className="col-span-2 sm:col-span-1">
              <label className="block font-semibold text-slate-700 mb-1">Affiliation Code / Board Code</label>
              <input
                type="text"
                value={formState.affiliationNo}
                onChange={(e) => setFormState({ ...formState, affiliationNo: e.target.value })}
                placeholder="CBSE / AFF / 2730182"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 text-slate-800 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600"
              />
            </div>

          </div>
        </div>

        {/* Step 2: Upload Logo & Signature */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Logo Upload Box */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Image className="w-4 h-4 text-blue-600" />
              School Official Logo
            </h3>

            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-2xl bg-slate-50 border border-slate-200 p-2 flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
                {formState.logoUrl ? (
                  <img src={formState.logoUrl} alt="School Logo" className="max-w-full max-h-full object-contain" />
                ) : (
                  <Building2 className="w-8 h-8 text-slate-300" />
                )}
              </div>

              <div className="space-y-2 text-xs">
                <label className="inline-flex items-center gap-2 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-xl cursor-pointer transition-colors shadow-xs">
                  <Upload className="w-4 h-4" />
                  <span>Upload Logo Image</span>
                  <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                </label>
                <p className="text-[11px] text-slate-400">PNG, JPG, SVG recommended. Max 5MB.</p>
              </div>
            </div>

            {/* Presets */}
            <div className="pt-2 border-t border-slate-100">
              <span className="text-[11px] font-semibold text-slate-400 block mb-2">Or select sample crest:</span>
              <div className="flex gap-2">
                {PRESET_LOGOS.map((url, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setFormState({ ...formState, logoUrl: url })}
                    className="w-10 h-10 rounded-lg border border-slate-200 p-1 hover:border-blue-500 transition-colors bg-slate-50 overflow-hidden"
                  >
                    <img src={url} alt="Preset Logo" className="w-full h-full object-contain" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Signature Upload Box */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <PenTool className="w-4 h-4 text-indigo-600" />
              Principal / Exam Controller Signature
            </h3>

            <div className="flex items-center gap-4">
              <div className="w-28 h-20 rounded-2xl bg-slate-50 border border-slate-200 p-2 flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
                {formState.signatureUrl ? (
                  <img src={formState.signatureUrl} alt="Signature" className="max-w-full max-h-full object-contain" />
                ) : (
                  <span className="text-[10px] text-slate-400 font-semibold">No Signature</span>
                )}
              </div>

              <div className="space-y-2 text-xs">
                <label className="inline-flex items-center gap-2 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl cursor-pointer transition-colors shadow-xs">
                  <Upload className="w-4 h-4" />
                  <span>Upload Signature Image</span>
                  <input type="file" accept="image/*" onChange={handleSignatureUpload} className="hidden" />
                </label>
                <p className="text-[11px] text-slate-400">Clear background PNG recommended.</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Signature Label</label>
              <input
                type="text"
                value={formState.signatureTitle}
                onChange={(e) => setFormState({ ...formState, signatureTitle: e.target.value })}
                placeholder="Controller of Examinations / Principal"
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 text-slate-800 outline-none"
              />
            </div>
          </div>

        </div>

        {/* Step 3: Watermark Settings */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h2 className="font-bold text-slate-900 text-sm pb-3 border-b border-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-600" />
            3. PDF Watermark Settings
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Diagonal Watermark Text</label>
              <input
                type="text"
                value={formState.watermarkText}
                onChange={(e) => setFormState({ ...formState, watermarkText: e.target.value })}
                placeholder="DPS VASANT KUNJ - EXAMINATION DEPT"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 uppercase font-semibold text-slate-800 outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Watermark Opacity ({Math.round((formState.watermarkOpacity || 0.08) * 100)}%)
              </label>
              <input
                type="range"
                min="0.02"
                max="0.25"
                step="0.01"
                value={formState.watermarkOpacity}
                onChange={(e) => setFormState({ ...formState, watermarkOpacity: Number(e.target.value) })}
                className="w-full accent-blue-600 mt-2"
              />
            </div>
          </div>
        </div>

        {/* Step 4: Live Exam Header Preview */}
        <div className="bg-slate-900 rounded-2xl p-6 text-white space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="font-bold text-sm text-blue-400 flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Live Exam Paper Header Preview
            </span>
            <span className="text-[10px] text-slate-400">Updates live as you edit</span>
          </div>

          <div className="bg-white text-slate-900 p-8 rounded-xl shadow-xl font-serif space-y-3 relative overflow-hidden">
            
            {/* Watermark preview */}
            {formState.watermarkText && (
              <div 
                className="absolute inset-0 flex items-center justify-center pointer-events-none select-none text-center font-bold text-3xl text-slate-400 rotate-[-25deg] uppercase"
                style={{ opacity: formState.watermarkOpacity }}
              >
                {formState.watermarkText}
              </div>
            )}

            <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
              <div className="w-16 h-16 shrink-0 overflow-hidden">
                {formState.logoUrl && <img src={formState.logoUrl} alt="Logo" className="w-full h-full object-contain" />}
              </div>

              <div className="text-center space-y-0.5 flex-1 px-4">
                <h1 className="text-base sm:text-lg font-black tracking-wide uppercase font-sans">
                  {formState.schoolName || 'YOUR SCHOOL NAME HERE'}
                </h1>
                <p className="text-[11px] font-sans font-medium text-slate-600">{formState.tagline}</p>
                <p className="text-[10px] font-sans text-slate-500">{formState.address}</p>
                <p className="text-[10px] font-sans font-bold text-slate-800">{formState.affiliationNo}</p>
              </div>

              <div className="w-16 h-16 shrink-0 flex items-center justify-center border border-dashed border-slate-300 rounded-lg text-[9px] text-slate-400">
                Seal / Code
              </div>
            </div>

            <div className="text-center font-bold font-sans text-xs uppercase tracking-wider underline text-slate-900 pt-1">
              CLASS X SCIENCE ANNUAL EXAMINATION 2026-27
            </div>

            <div className="flex items-center justify-between text-[11px] font-sans font-bold text-slate-800 pt-1">
              <span>Time: 3 Hours</span>
              <span>Max Marks: 80</span>
            </div>
          </div>
        </div>

        {/* Submit Save Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold text-sm shadow-xl shadow-blue-500/20 transition-all flex items-center justify-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Save School Branding Settings</span>
          </button>
        </div>

      </form>

    </div>
  );
};
