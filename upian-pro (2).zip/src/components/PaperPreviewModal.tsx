import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  Check, 
  FileCheck, 
  Sparkles, 
  Building2, 
  Eye, 
  FileText,
  Save,
  KeyRound,
  Share2,
  Crown,
  Loader2
} from 'lucide-react';
import { QuestionPaper, SchoolBranding, UserProfile } from '../types';
import { generateAndDownloadPDF } from '../utils/pdfGenerator';
import { cleanLatexToUnicode } from '../utils/mathFormatter';

interface PaperPreviewModalProps {
  paper: QuestionPaper | null;
  branding: SchoolBranding;
  user: UserProfile;
  onClose: () => void;
  onSavePaper?: (paper: QuestionPaper) => void;
}

export const PaperPreviewModal: React.FC<PaperPreviewModalProps> = ({
  paper,
  branding,
  user,
  onClose,
  onSavePaper
}) => {
  const [showAnswerKey, setShowAnswerKey] = useState<boolean>(
    paper?.includeAnswerKey !== undefined ? paper.includeAnswerKey : true
  );
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  const [sharedSuccess, setSharedSuccess] = useState<boolean>(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState<boolean>(false);

  if (!paper) return null;

  const isNeetPaper =
    paper.board === 'NTA / NEET UG' ||
    paper.board === 'NEET' ||
    paper.board === 'NEET UG' ||
    paper.classLevel === 'NEET_UG' ||
    paper.classLevel === 'NEET' ||
    (paper.title && paper.title.toUpperCase().includes('NEET'));

  if (isNeetPaper && paper.sections) {
    let neetTotalQuestions = 0;
    paper.sections.forEach((sec) => {
      let secMarksSum = 0;
      if (sec.questions) {
        sec.questions.forEach((q) => {
          q.marks = 4;
          q.type = 'mcq';
          secMarksSum += 4;
          neetTotalQuestions++;
        });
      }
      sec.marks = 4;
      sec.totalSectionMarks = secMarksSum;
      sec.description = `${sec.questions.length} MCQs carrying 4 marks each (+4 for correct, -1 for incorrect).`;
    });
    paper.totalMarks = neetTotalQuestions * 4;
  }

  const school = paper.schoolBranding || branding;
  const isTrialUser = !user.plan || user.plan === 'Trial';

  const handlePrint = () => {
    window.print();
  };

  const handleSharePaper = async () => {
    const shareTitle = `${paper.title} (${paper.board} Class ${paper.classLevel})`;
    const shareText = `Question Paper: ${paper.title}\nBoard: ${paper.board} | Class: ${paper.classLevel} | Subject: ${paper.subject} | Max Marks: ${paper.totalMarks}\nTime Allowed: ${paper.timeAllowedMinutes} Mins`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: window.location.href,
        });
        setSharedSuccess(true);
        setTimeout(() => setSharedSuccess(false), 2000);
        return;
      } catch (e) {
        // Ignored if cancelled
      }
    }

    navigator.clipboard.writeText(`${shareText}\n\nGenerated with Upian Pro:\n${window.location.href}`);
    setSharedSuccess(true);
    setTimeout(() => setSharedSuccess(false), 2000);
  };

  const handleSave = () => {
    if (onSavePaper && paper) {
      const updatedPaper = {
        ...paper,
        includeAnswerKey: showAnswerKey
      };
      onSavePaper(updatedPaper);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    }
  };

  const handleDownloadPDF = async () => {
    setIsGeneratingPDF(true);
    try {
      await generateAndDownloadPDF(paper, branding, user, {
        includeAnswerKey: showAnswerKey
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handleDownloadAnswerKey = async () => {
    setIsGeneratingPDF(true);
    try {
      await generateAndDownloadPDF(paper, branding, user, {
        includeAnswerKey: true
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  let questionCounter = 0;
  let answerCounter = 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
      
      {/* Container */}
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 my-auto overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header Controls (Hidden during print) */}
        <div className="relative bg-slate-900 text-white px-6 py-4 flex flex-wrap items-center justify-between gap-3 shrink-0 print:hidden pr-16">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400 shrink-0" />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-sm truncate max-w-xs sm:max-w-md">{paper.title}</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-extrabold flex items-center gap-1 shrink-0">
                  <FileCheck className="w-3 h-3 text-emerald-400" />
                  <span>100% QA Audited</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {paper.board} • Class {paper.classLevel} • {paper.totalMarks} Marks • 18 Audit Validations Passed
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            
            {/* Include Answer Key Checkbox */}
            <label className="flex items-center gap-1.5 text-xs text-slate-200 font-semibold cursor-pointer bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-750">
              <input
                type="checkbox"
                checked={showAnswerKey}
                onChange={(e) => setShowAnswerKey(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
              />
              <span>{showAnswerKey ? '✅ Include Answer Key in PDF' : '⬜ Exclude Answer Key'}</span>
            </label>

            {/* Share Paper Button */}
            <button
              onClick={handleSharePaper}
              className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
            >
              {sharedSuccess ? <Check className="w-3.5 h-3.5" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{sharedSuccess ? 'Shared!' : 'Share Paper'}</span>
            </button>

            {/* Save Paper Button */}
            {onSavePaper && (
              <button
                onClick={handleSave}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all shadow-sm flex items-center gap-1.5"
              >
                {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                <span>{savedSuccess ? 'Saved!' : 'Save Paper'}</span>
              </button>
            )}

            {/* Download PDF */}
            <button
              onClick={handleDownloadPDF}
              disabled={isGeneratingPDF}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
            >
              {isGeneratingPDF ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Download className="w-3.5 h-3.5" />
              )}
              <span>{isGeneratingPDF ? 'Generating PDF...' : 'Download PDF'}</span>
            </button>

            {/* Download Answer Key if enabled */}
            {showAnswerKey && (
              <button
                onClick={handleDownloadAnswerKey}
                disabled={isGeneratingPDF}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-all shadow-md flex items-center gap-1.5"
              >
                {isGeneratingPDF ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <KeyRound className="w-3.5 h-3.5" />
                )}
                <span>Download Answer Key</span>
              </button>
            )}

            {/* Print Paper */}
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 border border-slate-700"
            >
              <Printer className="w-3.5 h-3.5 text-blue-400" />
              <span>Print Paper</span>
            </button>

          </div>

          {/* Close Button in Top-Right Corner */}
          <button
            onClick={onClose}
            className="absolute top-3.5 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 shadow-sm flex items-center justify-center"
            title="Close (✕)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Plan Watermark Status Banner - ONLY VISIBLE TO FREE TRIAL USERS */}
        {isTrialUser && (
          <div className="px-6 py-2 text-xs font-medium flex items-center justify-between border-b bg-amber-50 text-amber-900 border-amber-200">
            <div className="flex items-center gap-2">
              <span className="font-bold bg-amber-200 text-amber-900 px-2 py-0.5 rounded text-[10px] uppercase tracking-wider">
                Free Trial
              </span>
              <span>
                Downloaded PDF will include 'Generated by Upian Trial' watermark.
              </span>
            </div>

            <span className="text-[11px] font-bold text-amber-800 underline cursor-pointer hover:text-amber-950">
              Upgrade Plan
            </span>
          </div>
        )}

        {/* PRINTABLE EXAM PAPER WORKSPACE (FULL A4 PAGE DISPLAY) */}
        <div className="bg-slate-200/90 p-3 sm:p-8 overflow-y-auto flex-1 flex flex-col items-center">
          
          <div 
            id="printablePaper"
            className="w-full max-w-[210mm] min-h-[297mm] bg-white shadow-2xl border border-slate-300 p-6 sm:p-12 text-slate-900 font-serif relative flex flex-col justify-between print:m-0 print:p-0 print:border-none print:shadow-none print:w-full print:min-h-0 print:max-w-none"
          >
            <div id="printableQuestionPaperArea" className="space-y-8 flex-1 flex flex-col justify-between">
            {/* Watermark */}
            {school.watermarkText && (
              <div 
                className="absolute inset-0 flex items-center justify-center pointer-events-none select-none text-center font-bold text-4xl text-slate-400 rotate-[-30deg] uppercase"
                style={{ opacity: school.watermarkOpacity || 0.08 }}
              >
                {school.watermarkText}
              </div>
            )}

            {/* School / Exam Header */}
            {(paper.title?.toUpperCase().includes('PAPER 2') || paper.subject?.toUpperCase().includes('PAPER 2')) ? (
              <div className="border-2 border-black p-4 mb-4 text-center bg-white font-sans text-slate-900 relative z-10">
                <div className="text-lg sm:text-xl font-black uppercase tracking-wider text-black">
                  INDIAN INSTITUTES OF TECHNOLOGY (IIT JEE ADVANCED)
                </div>
                <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wide border-b border-slate-300 pb-2">
                  Joint Implementation Committee • Official Examination Pattern (Paper 2)
                </div>
                <div className="text-sm sm:text-base font-black uppercase tracking-wide pt-2 text-slate-900">
                  {paper.title}
                </div>
                <div className="mt-3 grid grid-cols-2 text-xs text-left border border-black divide-x divide-y divide-black bg-slate-50">
                  <div className="p-2 font-bold">JEE Advanced Roll No: ______________________</div>
                  <div className="p-2 font-bold">Candidate Name: ______________________</div>
                  <div className="p-2"><strong>Test Paper:</strong> JEE Advanced Paper 2 ({paper.subject})</div>
                  <div className="p-2"><strong>Test Duration:</strong> {paper.timeAllowedMinutes} Mins</div>
                  <div className="p-2"><strong>Maximum Marks:</strong> {paper.totalMarks} Marks</div>
                  <div className="p-2"><strong>Exam Mode:</strong> Official IIT JEE Advanced Paper 2 Pattern</div>
                </div>
              </div>
            ) : (paper.board === 'IIT JEE / JEE Advanced' || paper.classLevel === 'JEE Advanced' || (paper.title?.toUpperCase().includes('JEE ADVANCED')) || (paper.title?.toUpperCase().includes('PAPER 1'))) ? (
              <div className="border-2 border-black p-4 mb-4 text-center bg-white font-sans text-slate-900 relative z-10">
                <div className="text-lg sm:text-xl font-black uppercase tracking-wider text-black">
                  INDIAN INSTITUTES OF TECHNOLOGY (IIT JEE ADVANCED)
                </div>
                <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wide border-b border-slate-300 pb-2">
                  Joint Implementation Committee • Official Examination Pattern (Paper 1)
                </div>
                <div className="text-sm sm:text-base font-black uppercase tracking-wide pt-2 text-slate-900">
                  {paper.title}
                </div>
                <div className="mt-3 grid grid-cols-2 text-xs text-left border border-black divide-x divide-y divide-black bg-slate-50">
                  <div className="p-2 font-bold">JEE Advanced Roll No: ______________________</div>
                  <div className="p-2 font-bold">Candidate Name: ______________________</div>
                  <div className="p-2"><strong>Test Paper:</strong> JEE Advanced Paper 1 ({paper.subject})</div>
                  <div className="p-2"><strong>Test Duration:</strong> {paper.timeAllowedMinutes} Mins</div>
                  <div className="p-2"><strong>Maximum Marks:</strong> {paper.totalMarks} Marks</div>
                  <div className="p-2"><strong>Exam Mode:</strong> Official IIT JEE Advanced Paper 1 Pattern</div>
                </div>
              </div>
            ) : (paper.board === 'NTA / NEET UG' || paper.classLevel === 'NEET_UG' || paper.title?.toUpperCase().includes('NEET')) ? (
              <div className="border-2 border-black p-4 mb-4 text-center bg-white font-sans text-slate-900 relative z-10">
                <div className="text-lg sm:text-xl font-black uppercase tracking-wider text-black">
                  NATIONAL TESTING AGENCY (NTA) • NEET UG MEDICAL
                </div>
                <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wide border-b border-slate-300 pb-2">
                  Excellence in Assessment • Official NEET UG Medical Examination Pattern
                </div>
                <div className="text-sm sm:text-base font-black uppercase tracking-wide pt-2 text-slate-900">
                  {paper.title}
                </div>
                <div className="mt-3 grid grid-cols-2 text-xs text-left border border-black divide-x divide-y divide-black bg-slate-50">
                  <div className="p-2 font-bold">NEET Roll No: ______________________</div>
                  <div className="p-2 font-bold">Candidate Name: ______________________</div>
                  <div className="p-2"><strong>Test Paper:</strong> {paper.subject}</div>
                  <div className="p-2"><strong>Test Duration:</strong> {paper.timeAllowedMinutes} Mins</div>
                  <div className="p-2"><strong>Maximum Marks:</strong> {paper.totalMarks} Marks</div>
                  <div className="p-2"><strong>Exam Mode:</strong> PART-1 (Phys Q1-45, Chem Q46-90) • PART-2 (Bot Q91-135, Zoo Q136-180) • 180 MCQs</div>
                </div>
              </div>
            ) : paper.board === 'NTA / JEE Main' || paper.classLevel === 'JEE Main' || paper.title?.toUpperCase().includes('JEE MAIN') ? (
              <div className="border-2 border-black p-4 mb-4 text-center bg-white font-sans text-slate-900 relative z-10">
                <div className="text-lg sm:text-xl font-black uppercase tracking-wider text-black">
                  NATIONAL TESTING AGENCY (NTA)
                </div>
                <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wide border-b border-slate-300 pb-2">
                  Excellence in Assessment • Official Examination Pattern
                </div>
                <div className="text-sm sm:text-base font-black uppercase tracking-wide pt-2 text-slate-900">
                  {paper.title}
                </div>
                <div className="mt-3 grid grid-cols-2 text-xs text-left border border-black divide-x divide-y divide-black bg-slate-50">
                  <div className="p-2 font-bold">Candidate Roll No: ______________________</div>
                  <div className="p-2 font-bold">Candidate Name: ______________________</div>
                  <div className="p-2"><strong>Test Subject:</strong> {paper.subject}</div>
                  <div className="p-2"><strong>Test Duration:</strong> {paper.timeAllowedMinutes} Mins</div>
                  <div className="p-2"><strong>Maximum Marks:</strong> {paper.totalMarks} Marks</div>
                  <div className="p-2"><strong>Exam Mode:</strong> Official NTA Pattern</div>
                </div>
              </div>
            ) : (
              <div className="border-b-2 border-slate-900 pb-4 space-y-1 text-center relative z-10">
                <div className="flex items-center justify-between mb-2">
                  <div className="w-16 h-16 shrink-0 overflow-hidden">
                    {school.logoUrl && <img src={school.logoUrl} alt="Logo" className="w-full h-full object-contain" />}
                  </div>

                  <div className="text-center flex-1 px-4 space-y-0.5">
                    <h1 className="text-lg sm:text-2xl font-black uppercase font-sans tracking-wide">
                      {school.schoolName || 'DELHI PUBLIC SCHOOL, VASANT KUNJ'}
                    </h1>
                    <p className="text-xs font-sans font-medium text-slate-600">{school.tagline}</p>
                    <p className="text-[11px] font-sans text-slate-500">{school.address}</p>
                    <p className="text-[11px] font-sans font-bold text-slate-800">{school.affiliationNo}</p>
                  </div>

                  <div className="w-16 h-16 shrink-0 flex items-center justify-center border border-dashed border-slate-300 rounded-lg text-[10px] font-sans text-slate-400">
                    School Seal
                  </div>
                </div>

                <div className="text-sm sm:text-base font-bold font-sans uppercase underline tracking-wider pt-2 text-slate-900">
                  {paper.title}
                </div>

                <div className="pt-2 flex items-center justify-between text-xs font-sans font-bold border-t border-slate-200 mt-2 text-slate-800">
                  <span>Class: {paper.classLevel} ({paper.subject})</span>
                  <span>Time Allowed: {paper.timeAllowedMinutes} Mins</span>
                  <span>Maximum Marks: {paper.totalMarks}</span>
                </div>
              </div>
            )}

            {/* General Instructions */}
            <div className="text-xs font-sans space-y-1 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="font-bold uppercase tracking-wider block text-slate-900">General Instructions:</span>
              <ol className="list-decimal pl-5 space-y-0.5 text-slate-700">
                {paper.generalInstructions.map((inst, idx) => (
                  <li key={idx}>{inst}</li>
                ))}
              </ol>
            </div>

            {/* Paper Sections (ONLY QUESTIONS - NO ANSWERS) */}
            <div className="space-y-8">
              {paper.sections.map((sec) => (
                <div key={sec.id} className="space-y-4">
                  
                  <div className="text-center font-extrabold font-sans text-xs sm:text-sm uppercase tracking-wider bg-slate-900 text-white py-1.5 px-3 rounded shadow-xs">
                    {sec.title}
                  </div>

                  <div className="space-y-4">
                    {sec.questions.map((q) => {
                      questionCounter += 1;
                      const qNum = questionCounter;
                      const allShortOpts = Array.isArray(q.options) && q.options.length > 0 && q.options.every((opt: string) => (opt || '').length <= 25);

                      return (
                        <div key={q.id} className="flex items-start justify-between gap-4 text-xs sm:text-sm">
                          <div className="space-y-1.5 flex-1">
                            <p className="leading-relaxed">
                              <span className="font-bold">Q{qNum}.</span> {cleanLatexToUnicode(q.text)}
                            </p>

                            {/* Question Diagram */}
                            {(q.diagramUrl || q.hasDiagram) && (
                              <div className="my-2 text-center">
                                {q.diagramUrl?.startsWith('<svg') ? (
                                  <div
                                    className="mx-auto flex justify-center"
                                    style={{ width: `${q.diagramWidth || 280}px`, maxWidth: '100%' }}
                                    dangerouslySetInnerHTML={{ __html: q.diagramUrl }}
                                  />
                                ) : (
                                  <img
                                    src={q.diagramUrl}
                                    alt="Question Diagram"
                                    className="mx-auto object-contain rounded"
                                    style={{ width: `${q.diagramWidth || 280}px`, maxWidth: '100%' }}
                                  />
                                )}
                                {q.diagramCaption && (
                                  <div className="text-[10px] text-slate-600 font-sans italic mt-1">{q.diagramCaption}</div>
                                )}
                              </div>
                            )}

                            {/* MCQ Options */}
                            {q.options && q.options.length > 0 ? (
                              <div className={`grid gap-x-6 gap-y-1 pl-5 font-sans text-xs text-slate-800 pt-1 ${allShortOpts ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-1 sm:grid-cols-2'}`}>
                                {q.options.map((opt, oIdx) => (
                                  <div key={oIdx}>
                                    <span className="font-bold">({String.fromCharCode(97 + oIdx)})</span> {cleanLatexToUnicode(opt)}
                                  </div>
                                ))}
                              </div>
                            ) : (q.type === 'numerical' || paper.board === 'NTA / JEE Main') && (
                              <div className="pl-5 pt-1">
                                <span className="inline-block px-3 py-1 bg-slate-50 border border-dashed border-slate-400 rounded text-[11px] font-bold font-sans text-slate-600">
                                  Response: [ Enter Numerical Value ]
                                </span>
                              </div>
                            )}
                          </div>

                          <span className="font-bold font-sans text-xs shrink-0 text-slate-900">[{q.marks}]</span>
                        </div>
                      );
                    })}
                  </div>

                </div>
              ))}
            </div>

            {/* Signature Block */}
            <div className="pt-10 border-t border-slate-200 flex items-center justify-between font-sans text-xs pt-8">
              <div className="text-center">
                <div className="h-10 border-b border-dashed border-slate-400 w-36 mb-1" />
                <span className="text-[11px] text-slate-500 font-semibold">Subject Teacher / Setter</span>
              </div>

              <div className="text-center">
                {school.signatureUrl ? (
                  <img src={school.signatureUrl} alt="Signature" className="h-10 mx-auto mb-1 object-contain" />
                ) : (
                  <div className="h-10 border-b border-dashed border-slate-400 w-36 mb-1" />
                )}
                <span className="text-[11px] text-slate-500 font-semibold">{school.signatureTitle || 'Principal Signature'}</span>
              </div>
            </div>
          </div>

          {/* ANSWER KEY SECTION (GENERATED ON A SEPARATE PAGE AFTER QUESTION PAPER IF CHECKED) */}
          {showAnswerKey && (
            <div id="printableAnswerKeyArea" className="pt-12 border-t-2 border-slate-900 space-y-6 page-break-before break-before-page">
              <div className="text-center font-bold font-sans text-base uppercase underline tracking-wider text-slate-900">
                ANSWER KEY & DETAILED MARKING SCHEME
              </div>

              <div className="space-y-4 font-sans text-xs">
                {paper.sections.map((sec) => (
                  <div key={sec.id} className="space-y-2.5">
                    <div className="font-bold text-slate-900 bg-slate-100 p-2 rounded-md border border-slate-200">{sec.title}</div>
                    
                    {sec.questions.map((q) => {
                      answerCounter += 1;
                      const aNum = answerCounter;

                      return (
                        <div key={q.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                          <div className="font-bold text-slate-900 flex items-center justify-between">
                            <span>Q{aNum}. Solution Statement:</span>
                            <span className="text-[11px] font-semibold text-slate-600">[{q.marks} Mark(s)]</span>
                          </div>
                          <p className="text-slate-800 whitespace-pre-line leading-relaxed font-medium">{cleanLatexToUnicode(q.answer)}</p>

                          {q.answerDiagramUrl && (
                            <div className="my-2 p-2 bg-emerald-50/50 rounded-lg border border-emerald-100 text-center">
                              <div className="text-[10px] font-bold text-emerald-800 mb-1">Solution Diagram Marking Scheme:</div>
                              {q.answerDiagramUrl.startsWith('<svg') ? (
                                <div
                                  className="mx-auto flex justify-center"
                                  style={{ width: `${q.diagramWidth || 260}px`, maxWidth: '100%' }}
                                  dangerouslySetInnerHTML={{ __html: q.answerDiagramUrl }}
                                />
                              ) : (
                                <img
                                  src={q.answerDiagramUrl}
                                  alt="Solution Diagram"
                                  className="mx-auto object-contain rounded"
                                  style={{ width: `${q.diagramWidth || 260}px`, maxWidth: '100%' }}
                                />
                              )}
                            </div>
                          )}
                          {q.explanation && (
                            <p className="text-slate-500 text-[11px] italic pt-1 border-t border-slate-200/60 mt-1">
                              Marking Scheme Note: {q.explanation}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>

    </div>

    </div>
  );
};
