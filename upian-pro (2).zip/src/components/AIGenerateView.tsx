import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  BookOpen, 
  Layers, 
  Clock, 
  Award, 
  HelpCircle, 
  FileCheck2, 
  AlertCircle, 
  CheckCircle2, 
  Sliders, 
  RefreshCw,
  Minus,
  Plus,
  Calculator,
  Search,
  ChevronDown,
  Check
} from 'lucide-react';
import { BoardType, ClassLevel, MediumType, DifficultyLevel, PaperGenerationConfig, QuestionPaper, SchoolBranding } from '../types';
import { PAPER_CATEGORIES, getSubjectsForCategory, getCategoryById, PaperCategory } from '../data/paperCatalog';

const CategorySearchableDropdown: React.FC<{
  categories: PaperCategory[];
  selectedId: string;
  onSelect: (id: string) => void;
}> = ({ categories, selectedId, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedCategory = categories.find(c => c.id === selectedId) || categories[0];

  const filteredCategories = categories.filter(cat =>
    cat.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <label className="block text-xs font-bold text-slate-700 mb-1">
        Primary Categories Catalog ({categories.length} Official Exam Categories):
      </label>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-4 py-2.5 rounded-xl bg-white border border-slate-300 hover:border-blue-500 shadow-2xs font-bold text-slate-800 text-xs flex items-center justify-between transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500/20"
      >
        <div className="flex items-center gap-2 truncate">
          <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
          <span className="truncate">{selectedCategory ? selectedCategory.name : 'Select Category'}</span>
          {selectedCategory?.badge && (
            <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-extrabold uppercase">
              {selectedCategory.badge}
            </span>
          )}
        </div>
        <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute z-50 left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden p-2 space-y-2 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              autoFocus
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search category (e.g. Class 10, JEE Main, NEET UG)..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
            />
          </div>

          <div className="max-h-60 overflow-y-auto space-y-1 scrollbar-thin">
            {filteredCategories.length === 0 ? (
              <div className="px-3 py-2 text-xs text-slate-400 text-center font-medium">
                No matching category found
              </div>
            ) : (
              filteredCategories.map((cat) => {
                const isSelected = cat.id === selectedId;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      onSelect(cat.id);
                      setIsOpen(false);
                      setSearchTerm('');
                    }}
                    className={`w-full text-left px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'bg-blue-50 text-blue-700 font-bold'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span>{cat.name}</span>
                      {cat.badge && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-extrabold bg-slate-100 text-slate-600 uppercase">
                          {cat.badge}
                        </span>
                      )}
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-blue-600" />}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};

interface AIGenerateViewProps {
  branding: SchoolBranding;
  onPaperGenerated: (paper: QuestionPaper) => void;
}

export const AIGenerateView: React.FC<AIGenerateViewProps> = ({
  branding,
  onPaperGenerated
}) => {
  const [board, setBoard] = useState<BoardType>('CBSE');
  const [classLevel, setClassLevel] = useState<ClassLevel>('10');
  const [medium, setMedium] = useState<MediumType>('English');
  const [subject, setSubject] = useState<string>('Science');
  const [isCustomSubject, setIsCustomSubject] = useState<boolean>(false);
  const [customSubjectInput, setCustomSubjectInput] = useState<string>('');
  
  // Custom Chapter / Topics list
  const [chapterInput, setChapterInput] = useState<string>('');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('Balanced Mix');
  const [totalMarks, setTotalMarks] = useState<number>(80);
  const [examTitle, setExamTitle] = useState<string>('Class 10 Science Annual Examination 2026-27');
  const [timeAllowedMinutes, setTimeAllowedMinutes] = useState<number>(180);
  const [includeAnswerKey, setIncludeAnswerKey] = useState<boolean>(true);
  const [customInstructions, setCustomInstructions] = useState<string>('Include real-world competency-based questions compliant with latest exam format.');

  // Current category info
  const currentCategory = getCategoryById(classLevel) || PAPER_CATEGORIES[9];
  const categorySubjects = getSubjectsForCategory(classLevel);

  const handleCategorySelect = (catId: string) => {
    setClassLevel(catId as ClassLevel);
    const cat = getCategoryById(catId);
    const subs = getSubjectsForCategory(catId);
    setIsCustomSubject(false);
    
    if (subs.length > 0) {
      setSubject(subs[0]);
    }
    
    if (catId === 'JEE_Main') {
      setExamTitle('JEE Main Official Pattern Paper 2026-27');
      setTotalMarks(300);
      setTimeAllowedMinutes(180);
      setMcq1m(0);
      setShort2m(0);
      setShort3m(0);
      setCase4m(75);
      setLong5m(0);
      setChapterInput('Physics (25 Qs: Sec A 20 MCQs + Sec B 5 Qs), Chemistry (25 Qs), Mathematics (25 Qs)');
      setCustomInstructions('JEE Main Pattern: 75 Questions total (Physics: 25, Chemistry: 25, Mathematics: 25), 300 Marks, 180 Mins. Per subject: Sec A (20 MCQs, 4 marks each) & Sec B (5 Qs, 4 marks each). Numerical questions have no negative marking for unanswered.');
    } else if (catId === 'JEE_Advanced') {
      setExamTitle('JEE Advanced Paper 1 Pattern Paper 2026-27');
      setTotalMarks(180);
      setTimeAllowedMinutes(180);
      setMcq1m(0);
      setShort2m(0);
      setShort3m(24);
      setCase4m(27);
      setLong5m(0);
      setChapterInput('Physics (17 Qs), Chemistry (17 Qs), Mathematics (17 Qs)');
      setCustomInstructions('JEE Advanced Paper 1 Pattern: 51 Questions total (17 per subject: Physics, Chemistry, Math), 180 Marks, 180 Mins. 21 MCQs total across paper. Per subject: Sec A (4 Qs of 3m each), Sec B (3 Qs of 4m each), Sec C (6 Qs of 4m each), Sec D (4 Qs of 3m each).');
    } else if (catId === 'NEET_UG') {
      setExamTitle('NEET UG Official Pattern Paper 2026-27');
      setTotalMarks(720);
      setTimeAllowedMinutes(180);
      setMcq1m(0);
      setShort2m(0);
      setShort3m(0);
      setCase4m(180);
      setLong5m(0);
      setChapterInput('Biology (90 Qs: 45 Botany + 45 Zoology), Physics (45 Qs), Chemistry (45 Qs)');
      setCustomInstructions('NEET UG Pattern: 180 Questions total divided into PART-1 (Physics Q.1-45, Chemistry Q.46-90 = 360 Marks) and PART-2 (Botany Q.91-135, Zoology Q.136-180 = 360 Marks). Total 180 Questions, 720 Marks, 180 Mins. All questions are MCQs of 4 marks each (+4 for correct, -1 for wrong).');
    } else if (catId === 'CUET_UG') {
      setExamTitle('CUET UG Subject-Wise Paper 2026-27');
      setTotalMarks(250);
      setTimeAllowedMinutes(60);
      setMcq1m(0);
      setShort2m(0);
      setShort3m(0);
      setCase4m(0);
      setLong5m(50);
      setChapterInput('Full Domain Subject Syllabus');
      setCustomInstructions('CUET UG Subject-Wise Pattern: 50 Questions per subject (All MCQs of 5 marks each), 250 Marks, 60 Mins. Marking: Correct +5, Wrong -1.');
    } else if (catId === 'NDA_NA') {
      setExamTitle('NDA & NA Paper 1 - Mathematics Exam 2026-27');
      setTotalMarks(300);
      setTimeAllowedMinutes(150);
      setMcq1m(0);
      setShort2m(30);
      setShort3m(80);
      setCase4m(0);
      setLong5m(0);
      setChapterInput('Mathematics (Algebra, Matrices, Trigonometry, Analytical Geometry, Calculus, Vector Algebra, Statistics & Probability)');
      setCustomInstructions('NDA & NA Paper 1 (Mathematics): 120 Questions (2.5 marks each), Total 300 Marks, Time 150 Mins.');
    } else if (cat) {
      if (cat.type === 'entrance' || cat.type === 'competitive') {
        setExamTitle(`${cat.name} Official Style Paper 2026-27`);
      } else {
        setExamTitle(`${cat.name} ${subs[0] || 'Examination'} 2026-27`);
      }
      setTotalMarks(80);
      setTimeAllowedMinutes(180);
      setMcq1m(12);
      setShort2m(6);
      setShort3m(5);
      setCase4m(2);
      setLong5m(3);
      setCustomInstructions('Include real-world competency-based questions compliant with latest exam format.');
    }
  };

  const handleSubjectSelectChange = (val: string) => {
    if (val === '__CUSTOM__') {
      setIsCustomSubject(true);
    } else {
      setIsCustomSubject(false);
      setSubject(val);

      // Dynamic sub-presets for JEE Advanced Paper 1 vs Paper 2
      if (classLevel === 'JEE_Advanced') {
        if (val.includes('Paper 2')) {
          setExamTitle('JEE Advanced Paper 2 Pattern Paper 2026-27');
          setTotalMarks(180);
          setTimeAllowedMinutes(180);
          setMcq1m(0);
          setShort2m(0);
          setShort3m(36);
          setCase4m(18);
          setLong5m(0);
          setChapterInput('Physics (18 Qs), Chemistry (18 Qs), Mathematics (18 Qs)');
          setCustomInstructions('JEE Advanced Paper 2 Pattern: 54 Questions total (18 per subject: Physics, Chemistry, Math), 180 Marks, 180 Mins. 36 MCQs total across paper (includes paragraph based questions). Per subject: Sec A (6 Qs of 3m each), Sec B (3 Qs of 4m each), Sec C (3 Qs of 4m each), Sec D (6 Qs of 3m each - includes paragraph based).');
        } else {
          setExamTitle('JEE Advanced Paper 1 Pattern Paper 2026-27');
          setTotalMarks(180);
          setTimeAllowedMinutes(180);
          setMcq1m(0);
          setShort2m(0);
          setShort3m(24);
          setCase4m(27);
          setLong5m(0);
          setChapterInput('Physics (17 Qs), Chemistry (17 Qs), Mathematics (17 Qs)');
          setCustomInstructions('JEE Advanced Paper 1 Pattern: 51 Questions total (17 per subject: Physics, Chemistry, Math), 180 Marks, 180 Mins. 21 MCQs total across paper. Per subject: Sec A (4 Qs of 3m each), Sec B (3 Qs of 4m each), Sec C (6 Qs of 4m each), Sec D (4 Qs of 3m each).');
        }
      }

      // Dynamic sub-presets for NDA & NA Paper 1 vs Paper 2
      if (classLevel === 'NDA_NA') {
        if (val.includes('Paper 2') || val.includes('GAT')) {
          setExamTitle('NDA & NA Paper 2 - General Ability Test (GAT) 2026-27');
          setTotalMarks(600);
          setTimeAllowedMinutes(150);
          setMcq1m(0);
          setShort2m(0);
          setShort3m(0);
          setCase4m(150);
          setLong5m(0);
          setChapterInput('General Ability Test (English 50 Qs, General Knowledge 100 Qs [Physics, Chemistry, General Science, History, Geography, Current Events])');
          setCustomInstructions('NDA & NA Paper 2 (General Ability Test - GAT): 150 Questions (4 marks each), Total 600 Marks, Time 150 Mins.');
        } else {
          setExamTitle('NDA & NA Paper 1 - Mathematics Exam 2026-27');
          setTotalMarks(300);
          setTimeAllowedMinutes(150);
          setMcq1m(0);
          setShort2m(30);
          setShort3m(80);
          setCase4m(0);
          setLong5m(0);
          setChapterInput('Mathematics (Algebra, Matrices, Trigonometry, Analytical Geometry, Calculus, Vector Algebra, Statistics & Probability)');
          setCustomInstructions('NDA & NA Paper 1 (Mathematics): 120 Questions (2.5 marks each), Total 300 Marks, Time 150 Mins.');
        }
      }
    }
  };

  // Question Distribution Breakdown
  const [mcq1m, setMcq1m] = useState<number>(12);
  const [short2m, setShort2m] = useState<number>(6);
  const [short3m, setShort3m] = useState<number>(5);
  const [case4m, setCase4m] = useState<number>(2);
  const [long5m, setLong5m] = useState<number>(3);

  // Generation status
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Calculate calculated distribution sum
  const calculatedMarks = (mcq1m * 1) + (short2m * 2) + (short3m * 3) + (case4m * 4) + (long5m * 5);

  const handleCountChange = (setter: React.Dispatch<React.SetStateAction<number>>, currentVal: number, delta: number, min = 0, max = 200) => {
    setter(Math.max(min, Math.min(max, currentVal + delta)));
  };

  const handleDirectCountChange = (setter: React.Dispatch<React.SetStateAction<number>>, rawValue: string) => {
    if (rawValue === '') {
      setter(0);
      return;
    }
    const parsed = parseInt(rawValue, 10);
    if (!isNaN(parsed)) {
      setter(Math.max(0, parsed));
    }
  };

  const handleQuickPreset = (presetSubject: string) => {
    setSubject(presetSubject);
    setIsCustomSubject(false);
    if (presetSubject === 'Physics') {
      setChapterInput('Light, Electricity, Magnetic Effects of Electric Current, Motion, Work & Energy');
    } else if (presetSubject === 'Chemistry') {
      setChapterInput('Chemical Reactions and Equations, Acids Bases and Salts, Metals and Non-Metals, Carbon Compounds');
    } else if (presetSubject === 'Biology') {
      setChapterInput('Life Processes, Control and Coordination, How do Organisms Reproduce, Genetics & Evolution');
    } else if (presetSubject === 'Science') {
      setChapterInput('Light, Electricity, Chemical Reactions, Life Processes');
    } else if (presetSubject === 'Mathematics') {
      setChapterInput('Real Numbers, Polynomials, Quadratic Equations, Triangles, Trigonometry, Statistics');
    } else if (presetSubject === 'Social Science') {
      setChapterInput('Rise of Nationalism in Europe, Resources & Development, Money & Credit, Federalism');
    } else if (presetSubject === 'English') {
      setChapterInput('Reading Comprehension, Formal Letters, Tenses, Literature Prose & Poetry');
    } else {
      setChapterInput('');
    }
  };

  const [generatingPart, setGeneratingPart] = useState<'PART1' | 'PART2' | null>(null);

  const isNeetCategory = classLevel === 'NEET_UG' || classLevel === 'NEET' || currentCategory?.id === 'NEET_UG';

  const executePaperGeneration = async (neetPart?: 'PART1' | 'PART2') => {
    setError(null);

    if (!isNeetCategory && calculatedMarks <= 0) {
      setError('Please select at least 1 question (Total Marks must be greater than 0) before generating paper.');
      return;
    }

    setIsGenerating(true);
    if (neetPart) setGeneratingPart(neetPart);

    const targetPaperTotalMarks = isNeetCategory ? 360 : (calculatedMarks > 0 ? calculatedMarks : totalMarks);
    const finalSubjectName = isCustomSubject ? customSubjectInput : subject;
    const selectedCatObj = getCategoryById(classLevel);

    let customTitle = examTitle;
    if (isNeetCategory) {
      customTitle = neetPart === 'PART2'
        ? 'NATIONAL TESTING AGENCY (NTA) • NEET UG MEDICAL EXAMINATION (PART 2)'
        : 'NATIONAL TESTING AGENCY (NTA) • NEET UG MEDICAL EXAMINATION (PART 1)';
    }

    const configPayload: PaperGenerationConfig & { categoryRules?: string; neetPart?: string } = {
      board,
      classLevel: selectedCatObj ? selectedCatObj.name : classLevel,
      medium,
      subject: finalSubjectName,
      chapters: chapterInput.split(',').map(c => c.trim()).filter(Boolean),
      difficulty,
      totalMarks: targetPaperTotalMarks,
      questionDistribution: {
        mcq1m,
        short2m,
        short3m,
        case4m,
        long5m
      },
      customInstructions,
      includeAnswerKey,
      examTitle: customTitle,
      timeAllowedMinutes: isNeetCategory ? 90 : timeAllowedMinutes,
      categoryRules: selectedCatObj?.generationRules || '',
      ...(neetPart ? { neetPart } : {})
    };

    setStatusMessage(isNeetCategory ? `Generating Official NEET UG ${neetPart || 'PART 1'} Questions...` : 'Initializing AI Section Workers...');
    const timer1 = setTimeout(() => setStatusMessage('Generating Questions in Parallel...'), 800);
    const timer2 = setTimeout(() => setStatusMessage('Validating NCERT Terms & Formulas...'), 2200);
    const timer3 = setTimeout(() => setStatusMessage('Assembling Final Paper...'), 3800);

    let paperData: any = null;
    let errorMessage = '';

    try {
      const response = await fetch('/api/generate-paper', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(configPayload)
      });

      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);

      const data = await response.json();

      if (response.ok && data.success && data.paper) {
        paperData = data.paper;
      } else {
        errorMessage = data?.error || 'Server returned invalid paper response';
      }
    } catch (err: any) {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      console.error('[Generation Error]', err);
      errorMessage = err?.message || 'Network or connection error during paper generation';
    }

    if (!paperData) {
      setIsGenerating(false);
      setGeneratingPart(null);
      setError(errorMessage || 'Generation failed. Please try again.');
      return;
    }

    const cleanedSections = (paperData.sections || [])
      .map((sec: any) => ({
        ...sec,
        questions: (sec.questions || []).filter((q: any) => q && q.text)
      }))
      .filter((sec: any) => sec.questions.length > 0);

    // NEET UG Specific Marking Scheme Enforcer
    if (isNeetCategory) {
      cleanedSections.forEach((sec: any) => {
        sec.questions = sec.questions.map((q: any) => ({
          ...q,
          marks: 4,
          type: 'mcq'
        }));
        sec.marks = 4;
        sec.totalSectionMarks = sec.questions.length * 4;
        sec.description = `${sec.questions.length} MCQs carrying 4 marks each (+4 for correct, -1 for incorrect).`;
      });
    }

    const computedSumMarks = cleanedSections.reduce((sum: number, sec: any) => {
      return sum + sec.questions.reduce((qSum: number, q: any) => qSum + (Number(q.marks) || 0), 0);
    }, 0);

    const finalTotalMarks = computedSumMarks > 0 ? computedSumMarks : targetPaperTotalMarks;

    const fullPaper: QuestionPaper = {
      id: 'pap_' + Date.now(),
      title: paperData.title || customTitle,
      board: paperData.board || board,
      classLevel: paperData.classLevel || classLevel,
      subject: paperData.subject || subject,
      medium: paperData.medium || medium,
      timeAllowedMinutes: paperData.timeAllowedMinutes || (isNeetCategory ? 90 : timeAllowedMinutes),
      totalMarks: finalTotalMarks,
      createdMode: 'ai',
      createdAt: new Date().toISOString(),
      status: 'published',
      generalInstructions: paperData.generalInstructions || [
        'All questions are compulsory.',
        'Read questions carefully before answering.',
        'Write neat and legible answers.'
      ],
      sections: cleanedSections,
      includeAnswerKey,
      schoolBranding: branding
    };

    setIsGenerating(false);
    setGeneratingPart(null);
    onPaperGenerated(fullPaper);
  };

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (isNeetCategory) {
      executePaperGeneration('PART1');
    } else {
      executePaperGeneration();
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Title Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            Mode A: AI Paper Generator
          </div>
          <h1 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
            Generate Question Paper in 2 minutes
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Configure board parameters below. Our AI drafts standard section-wise questions with detailed answer keys.
          </p>
        </div>
      </div>

      {/* Main Configuration Form */}
      <form onSubmit={handleGenerate} className="space-y-6">
        
        {/* Section 1: Exam Details & Target Parameters */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 font-bold text-slate-900 text-sm">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <span>1. Exam Details & Target Parameters</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Exam Title</label>
              <input
                type="text"
                required
                value={examTitle}
                onChange={(e) => setExamTitle(e.target.value)}
                placeholder="e.g. Annual Board Exam 2026-27"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Difficulty Level</label>
              <select
                value={difficulty}
                onChange={(e) => setDifficulty(e.target.value as DifficultyLevel)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
              >
                <option value="Balanced Mix">Balanced Mix (Easy 30%, Med 50%, Hard 20%)</option>
                <option value="Easy">Easy (Focus on basic concepts)</option>
                <option value="Medium">Medium (Standard board level)</option>
                <option value="Hard">Hard (High Order Thinking HOTS)</option>
              </select>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Duration (Minutes)</label>
                <input
                  type="number"
                  min="10"
                  max="720"
                  value={timeAllowedMinutes}
                  onChange={(e) => setTimeAllowedMinutes(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Target Total Marks</label>
                <input
                  type="number"
                  min="10"
                  max="720"
                  value={totalMarks}
                  onChange={(e) => setTotalMarks(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none"
                />
              </div>
            </div>

          </div>

          {/* Additional Options */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2">
            
            <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-800">
              <input
                type="checkbox"
                checked={includeAnswerKey}
                onChange={(e) => setIncludeAnswerKey(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
              />
              <span>Generate Step-by-Step Answer Key & Marking Scheme</span>
            </label>

            <div className="text-[11px] text-slate-500">
              School Header: <span className="font-semibold text-slate-800">{branding.schoolName || 'Default School'}</span>
            </div>

          </div>

          {/* Custom Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Custom Teacher Instructions to Upian Pro (Optional)
            </label>
            <textarea
              rows={2}
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              placeholder="e.g. Include numerical problems from Ohm's Law and Ray Optics."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
            />
          </div>

        </div>

        {/* Section 2: Board & Paper Category Selection Catalog */}
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
              <Sliders className="w-4 h-4 text-blue-600" />
              <span>2. Paper Selection Catalog</span>
            </div>
            <span className="text-xs font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
              Selected: {currentCategory?.name || 'Class 10'} • {isCustomSubject ? customSubjectInput : subject}
            </span>
          </div>

          {/* Primary Categories Catalog Searchable Dropdown */}
          <CategorySearchableDropdown
            categories={PAPER_CATEGORIES}
            selectedId={classLevel}
            onSelect={handleCategorySelect}
          />

          {/* Grid Controls: Board, Category Dropdown, Subject Dropdown, Medium */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
            
            {/* 1. Board */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Education Board / Authority</label>
              <select
                value={board}
                onChange={(e) => setBoard(e.target.value as BoardType)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
              >
                <option value="CBSE">CBSE (Central Board)</option>
                <option value="ICSE">ICSE / ISC Board</option>
                <option value="State Board (Maharashtra)">State Board (Maharashtra)</option>
                <option value="State Board (UP)">State Board (Uttar Pradesh)</option>
                <option value="State Board (Delhi)">State Board (Delhi)</option>
                <option value="State Board (Karnataka)">State Board (Karnataka)</option>
                <option value="State Board (Tamil Nadu)">State Board (Tamil Nadu)</option>
                <option value="Cambridge / IB">Cambridge / IB International</option>
              </select>
            </div>

            {/* 2. Paper Category Dropdown (All 20 in exact order) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Paper Category / Class</label>
              <select
                value={classLevel}
                onChange={(e) => handleCategorySelect(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-bold text-slate-900"
              >
                {PAPER_CATEGORIES.map((cat, i) => (
                  <option key={cat.id} value={cat.id}>
                    {i + 1}. {cat.name}
                  </option>
                ))}
              </select>
            </div>

            {/* 3. Class-Wise Subject Dropdown */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subject ({categorySubjects.length} Available)
              </label>
              {!isCustomSubject ? (
                <select
                  value={subject}
                  onChange={(e) => handleSubjectSelectChange(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-bold text-blue-700"
                >
                  {categorySubjects.map((sub) => (
                    <option key={sub} value={sub}>{sub}</option>
                  ))}
                  <option value="__CUSTOM__">+ Other Custom Subject...</option>
                </select>
              ) : (
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    required
                    value={customSubjectInput}
                    onChange={(e) => setCustomSubjectInput(e.target.value)}
                    placeholder="Type subject name..."
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
                  />
                  <button
                    type="button"
                    onClick={() => setIsCustomSubject(false)}
                    className="text-[10px] text-slate-500 underline whitespace-nowrap px-1"
                  >
                    List
                  </button>
                </div>
              )}
            </div>

            {/* 4. Language (Medium) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Language (Medium)</label>
              <select
                value={medium}
                onChange={(e) => setMedium(e.target.value as MediumType)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
              >
                <option value="English">English Medium</option>
                <option value="Hindi">Hindi Medium</option>
                <option value="Hinglish">Hinglish (Bilingual)</option>
                <option value="Regional">Regional Medium</option>
              </select>
            </div>

          </div>

          {/* Category Pattern & Guidelines Badge */}
          {currentCategory && (
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-start gap-2">
              <BookOpen className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-800">{currentCategory.name} Exam Rules: </span>
                <span>{currentCategory.generationRules}</span>
              </div>
            </div>
          )}

          {/* 5. Chapter / Specific Topics */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Chapters / Specific Topics to Cover (Comma separated)
            </label>
            <input
              type="text"
              required
              value={chapterInput}
              onChange={(e) => setChapterInput(e.target.value)}
              placeholder="e.g. Light Reflection, Electricity, Acids Bases & Salts"
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium text-slate-800"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Specify unit names or chapters. The AI will distribute questions proportionally across these chapters adhering strictly to NCERT / NTA / Board guidelines.
            </p>
          </div>

        </div>

        {/* NEET UG TWO-PART UI vs STANDARD MARKS SELECTION */}
        {isNeetCategory ? (
          <div className="bg-slate-900 text-white rounded-2xl p-5 sm:p-7 border border-slate-800 shadow-xl space-y-6">
            {/* OFFICIAL NTA MARKING SCHEME NOTICE BANNER */}
            <div className="bg-blue-950/80 border border-blue-500/40 rounded-xl p-4 text-blue-100 text-xs flex items-start gap-3 shadow-inner">
              <AlertCircle className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="font-extrabold text-white text-xs sm:text-sm">
                  Official NTA NEET UG Marking Scheme Enforced:
                </div>
                <p className="text-blue-200/90 leading-relaxed font-medium">
                  NEET UG follows the official NTA marking scheme. Every question carries 4 marks (+4 for correct, -1 for incorrect).
                </p>
              </div>
            </div>

            {/* OVERALL NEET UG PAPER SPECIFICATION SUMMARY */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-700/50">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Paper</span>
                <span className="text-sm font-black text-white">180 Questions</span>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-700/50">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Marks / Question</span>
                <span className="text-sm font-black text-blue-400">4 Marks Locked</span>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-700/50">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Paper Marks</span>
                <span className="text-sm font-black text-emerald-400">720 Marks</span>
              </div>
              <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-700/50">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Marking Rules</span>
                <span className="text-xs font-black text-amber-300">+4 Correct | -1 Wrong</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-extrabold text-white">NEET UG Paper Parts</h3>
                  <p className="text-xs text-slate-400">Generates independent 90-question official NEET UG paper parts (360 Marks each).</p>
                </div>
              </div>
              <span className="text-xs font-bold text-blue-400 bg-blue-950/80 px-3 py-1 rounded-full border border-blue-800/50">
                Official NTA 2-Part Mode
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* PART 1 CARD */}
              <div className="bg-slate-800/90 rounded-2xl p-5 border border-slate-700/80 flex flex-col justify-between hover:border-blue-500/50 transition-all shadow-md">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-base font-black text-white flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                      PART 1 (Questions 1–90)
                    </span>
                    <span className="text-[11px] font-bold text-blue-400 bg-blue-900/50 px-2 py-0.5 rounded border border-blue-700/50">360 Marks</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-4 font-medium">
                    Generates the first half of the official NEET UG paper.
                  </p>

                  <div className="bg-slate-900/80 rounded-xl p-3.5 border border-slate-800 space-y-3 mb-5">
                    <div className="text-xs font-bold text-slate-300 uppercase tracking-wider text-[11px] border-b border-slate-800 pb-1.5">
                      Contents
                    </div>
                    <div className="space-y-2.5 text-xs">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-bold text-white block">Physics</span>
                          <span className="text-[11px] text-slate-400">• Questions 1–45</span>
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-slate-300 block text-[11px]">• 45 MCQs (4 Mks)</span>
                          <span className="font-bold text-blue-400 text-[11px]">• 180 Marks</span>
                        </div>
                      </div>

                      <div className="flex items-start justify-between border-t border-slate-800/80 pt-2">
                        <div>
                          <span className="font-bold text-white block">Chemistry</span>
                          <span className="text-[11px] text-slate-400">• Questions 46–90</span>
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-slate-300 block text-[11px]">• 45 MCQs (4 Mks)</span>
                          <span className="font-bold text-blue-400 text-[11px]">• 180 Marks</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-950/40 rounded-xl p-3 border border-blue-900/60 mb-5 flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">Part 1 Summary:</span>
                    <div className="flex items-center gap-3 font-bold text-white">
                      <span>Total Questions: 90</span>
                      <span className="text-slate-500">•</span>
                      <span className="text-emerald-400">Total Marks: 360</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={isGenerating}
                  onClick={() => executePaperGeneration('PART1')}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl font-extrabold text-sm shadow-lg shadow-blue-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isGenerating && generatingPart === 'PART1' ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Generating Part 1...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-yellow-300" />
                      <span>Generate Part 1</span>
                    </>
                  )}
                </button>
              </div>

              {/* PART 2 CARD */}
              <div className="bg-slate-800/90 rounded-2xl p-5 border border-slate-700/80 flex flex-col justify-between hover:border-emerald-500/50 transition-all shadow-md">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-base font-black text-white flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                      PART 2 (Questions 91–180)
                    </span>
                    <span className="text-[11px] font-bold text-emerald-400 bg-emerald-900/50 px-2 py-0.5 rounded border border-emerald-700/50">360 Marks</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-4 font-medium">
                    Generates the second half of the official NEET UG paper.
                  </p>

                  <div className="bg-slate-900/80 rounded-xl p-3.5 border border-slate-800 space-y-3 mb-5">
                    <div className="text-xs font-bold text-slate-300 uppercase tracking-wider text-[11px] border-b border-slate-800 pb-1.5">
                      Contents
                    </div>
                    <div className="space-y-2.5 text-xs">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-bold text-white block">Botany</span>
                          <span className="text-[11px] text-slate-400">• Questions 91–135</span>
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-slate-300 block text-[11px]">• 45 MCQs (4 Mks)</span>
                          <span className="font-bold text-emerald-400 text-[11px]">• 180 Marks</span>
                        </div>
                      </div>

                      <div className="flex items-start justify-between border-t border-slate-800/80 pt-2">
                        <div>
                          <span className="font-bold text-white block">Zoology</span>
                          <span className="text-[11px] text-slate-400">• Questions 136–180</span>
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-slate-300 block text-[11px]">• 45 MCQs (4 Mks)</span>
                          <span className="font-bold text-emerald-400 text-[11px]">• 180 Marks</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-emerald-950/40 rounded-xl p-3 border border-emerald-900/60 mb-5 flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-medium">Part 2 Summary:</span>
                    <div className="flex items-center gap-3 font-bold text-white">
                      <span>Total Questions: 90</span>
                      <span className="text-slate-500">•</span>
                      <span className="text-emerald-400">Total Marks: 360</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={isGenerating}
                  onClick={() => executePaperGeneration('PART2')}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl font-extrabold text-sm shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isGenerating && generatingPart === 'PART2' ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Generating Part 2...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-yellow-300" />
                      <span>Generate Part 2</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* STICKY DYNAMIC TOTAL MARKS BANNER */}
            <div 
              className={`sticky top-16 sm:top-20 z-30 rounded-2xl p-4 sm:p-5 shadow-lg border transition-all duration-300 backdrop-blur-md ${
                calculatedMarks === 0
                  ? 'bg-slate-800 border-slate-700 text-white'
                  : calculatedMarks === totalMarks
                  ? 'bg-emerald-600 border-emerald-500 text-white ring-2 ring-emerald-400/50 shadow-emerald-600/20'
                  : 'bg-amber-600 border-amber-500 text-white'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl border flex items-center justify-center text-white shrink-0 shadow-xs transition-colors ${
                    calculatedMarks === totalMarks && calculatedMarks > 0
                      ? 'bg-emerald-500 border-emerald-300 text-white ring-4 ring-emerald-300/30'
                      : 'bg-white/15 border-white/20'
                  }`}>
                    <Calculator className="w-5 h-5 sm:w-6 sm:h-6" />
                  </div>
                  <div>
                    <div className="text-[11px] sm:text-xs font-bold uppercase tracking-wider text-white/80">
                      Selected Paper Specification
                    </div>
                    <div className="text-xl sm:text-2xl font-black text-white leading-tight">
                      Total Marks: {calculatedMarks} Marks
                    </div>
                  </div>
                </div>

                <div className="flex items-center">
                  {calculatedMarks === 0 ? (
                    <div className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/20 text-white/90 text-xs font-bold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-slate-400 animate-pulse" />
                      <span>Enter required question counts below</span>
                    </div>
                  ) : calculatedMarks === totalMarks ? (
                    <div className="px-3.5 py-1.5 rounded-xl bg-emerald-500 border border-emerald-300 text-white text-xs font-extrabold flex items-center gap-1.5 shadow-md">
                      <CheckCircle2 className="w-4 h-4 text-emerald-100 fill-emerald-600" />
                      <span>Paper Ready to Generate ({calculatedMarks} Marks)</span>
                    </div>
                  ) : (
                    <div className="px-3.5 py-1.5 rounded-xl bg-amber-500/80 border border-amber-300/60 text-white text-xs font-bold flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 text-amber-100" />
                      <span>Selected: {calculatedMarks} / Target: {totalMarks} Marks</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* QUESTION SELECTION RECTANGULAR GRID - Single Label Container */}
            <div className="bg-white border border-slate-300 shadow-xs space-y-0 overflow-hidden rounded-xl">
              <div className="flex items-center justify-between p-3 sm:p-4 bg-slate-50 border-b border-slate-300 font-bold text-slate-900 text-xs sm:text-sm">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-purple-600 shrink-0" />
                  <span className="truncate">Select Number of Questions Per Mark Category</span>
                </div>
                <span className="text-[11px] font-semibold text-slate-500 shrink-0 hidden sm:inline">
                  Directly type question counts
                </span>
              </div>

              <div className="overflow-x-auto">
                <div className="grid grid-cols-5 divide-x divide-slate-300 bg-slate-100 min-w-[500px]">
                
                {/* 1 Mark Box */}
                <div className="p-2 sm:p-3 bg-white flex flex-col items-center justify-between gap-1.5 text-center">
                  <span className="text-[10px] sm:text-xs font-black text-slate-900 uppercase tracking-tight">1 MARK</span>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={mcq1m === 0 ? '0' : mcq1m}
                    onChange={(e) => handleDirectCountChange(setMcq1m, e.target.value)}
                    onFocus={(e) => e.target.select()}
                    className="w-full text-center font-black text-sm sm:text-base text-slate-900 bg-slate-50 border border-slate-300 rounded-none py-1 outline-none focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                  />
                  <span className="w-full text-center text-[10px] sm:text-[11px] font-bold text-blue-700 bg-blue-50 py-0.5 border-t border-blue-100">
                    Marks : {mcq1m * 1}
                  </span>
                </div>

                {/* 2 Mark Box */}
                <div className="p-2 sm:p-3 bg-white flex flex-col items-center justify-between gap-1.5 text-center">
                  <span className="text-[10px] sm:text-xs font-black text-slate-900 uppercase tracking-tight">2 MARK</span>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={short2m === 0 ? '0' : short2m}
                    onChange={(e) => handleDirectCountChange(setShort2m, e.target.value)}
                    onFocus={(e) => e.target.select()}
                    className="w-full text-center font-black text-sm sm:text-base text-slate-900 bg-slate-50 border border-slate-300 rounded-none py-1 outline-none focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                  />
                  <span className="w-full text-center text-[10px] sm:text-[11px] font-bold text-blue-700 bg-blue-50 py-0.5 border-t border-blue-100">
                    Marks : {short2m * 2}
                  </span>
                </div>

                {/* 3 Mark Box */}
                <div className="p-2 sm:p-3 bg-white flex flex-col items-center justify-between gap-1.5 text-center">
                  <span className="text-[10px] sm:text-xs font-black text-slate-900 uppercase tracking-tight">3 MARK</span>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={short3m === 0 ? '0' : short3m}
                    onChange={(e) => handleDirectCountChange(setShort3m, e.target.value)}
                    onFocus={(e) => e.target.select()}
                    className="w-full text-center font-black text-sm sm:text-base text-slate-900 bg-slate-50 border border-slate-300 rounded-none py-1 outline-none focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                  />
                  <span className="w-full text-center text-[10px] sm:text-[11px] font-bold text-blue-700 bg-blue-50 py-0.5 border-t border-blue-100">
                    Marks : {short3m * 3}
                  </span>
                </div>

                {/* 4 Mark Box */}
                <div className="p-2 sm:p-3 bg-white flex flex-col items-center justify-between gap-1.5 text-center">
                  <span className="text-[10px] sm:text-xs font-black text-slate-900 uppercase tracking-tight">4 MARK</span>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={case4m === 0 ? '0' : case4m}
                    onChange={(e) => handleDirectCountChange(setCase4m, e.target.value)}
                    onFocus={(e) => e.target.select()}
                    className="w-full text-center font-black text-sm sm:text-base text-slate-900 bg-slate-50 border border-slate-300 rounded-none py-1 outline-none focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                  />
                  <span className="w-full text-center text-[10px] sm:text-[11px] font-bold text-blue-700 bg-blue-50 py-0.5 border-t border-blue-100">
                    Marks : {case4m * 4}
                  </span>
                </div>

                {/* 5 Mark Box */}
                <div className="p-2 sm:p-3 bg-white flex flex-col items-center justify-between gap-1.5 text-center">
                  <span className="text-[10px] sm:text-xs font-black text-slate-900 uppercase tracking-tight">5 MARK</span>
                  <input
                    type="number"
                    min="0"
                    max="200"
                    value={long5m === 0 ? '0' : long5m}
                    onChange={(e) => handleDirectCountChange(setLong5m, e.target.value)}
                    onFocus={(e) => e.target.select()}
                    className="w-full text-center font-black text-sm sm:text-base text-slate-900 bg-slate-50 border border-slate-300 rounded-none py-1 outline-none focus:bg-white focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
                  />
                  <span className="w-full text-center text-[10px] sm:text-[11px] font-bold text-blue-700 bg-blue-50 py-0.5 border-t border-blue-100">
                    Marks : {long5m * 5}
                  </span>
                </div>

              </div>
            </div>
          </div>

            {/* Generate Trigger Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isGenerating}
                className="w-full py-4 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white rounded-2xl font-bold text-base shadow-xl shadow-blue-600/25 transition-all flex items-center justify-center gap-3 disabled:opacity-60"
              >
                {isGenerating ? (
                  <div className="flex items-center gap-3">
                    <RefreshCw className="w-5 h-5 animate-spin text-white" />
                    <div className="text-left">
                      <div>Generating Question Paper with Upian Pro...</div>
                      <div className="text-xs font-normal text-blue-100">{statusMessage}</div>
                    </div>
                  </div>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 text-yellow-300" />
                    <span>Generate Professional Question Paper ({calculatedMarks} Marks)</span>
                  </>
                )}
              </button>
            </div>
          </>
        )}

        {/* Error Display */}
        {error && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-800 text-xs">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Generation Failed</p>
              <p className="mt-0.5">{error}</p>
            </div>
          </div>
        )}

        {/* Generate Trigger Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isGenerating}
            className="w-full py-4 bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white rounded-2xl font-bold text-base shadow-xl shadow-blue-600/25 transition-all flex items-center justify-center gap-3 disabled:opacity-60"
          >
            {isGenerating ? (
              <div className="flex items-center gap-3">
                <RefreshCw className="w-5 h-5 animate-spin text-white" />
                <div className="text-left">
                  <div>Generating Question Paper with Upian Pro...</div>
                  <div className="text-xs font-normal text-blue-100">{statusMessage}</div>
                </div>
              </div>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-yellow-300" />
                <span>Generate Professional Question Paper ({calculatedMarks} Marks)</span>
              </>
            )}
          </button>
        </div>

      </form>

    </div>
  );
};

