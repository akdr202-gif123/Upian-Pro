import React, { useState, useEffect } from 'react';
import { X, Mail, Lock, User, Building2, BookOpen, ArrowRight, CheckCircle, GraduationCap, KeyRound, Smartphone, ShieldCheck, Eye, EyeOff } from 'lucide-react';
import { UserProfile } from '../types';
import { 
  auth, 
  googleProvider, 
  signInWithPopup, 
  db, 
  doc, 
  setDoc, 
  getDoc 
} from '../lib/firebase';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';

interface AuthModalProps {
  isOpen: boolean;
  initialMode: 'login' | 'signup' | 'forgot';
  onClose: () => void;
  onLoginSuccess: (userProfile?: Partial<UserProfile>) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode,
  onClose,
  onLoginSuccess
}) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>(initialMode);
  const [authMethod, setAuthMethod] = useState<'email' | 'phone'>('email');
  const [showPassword, setShowPassword] = useState(false);
  
  // Form states
  const [email, setEmail] = useState('rajesh.sharma@dpsvk.edu.in');
  const [password, setPassword] = useState('••••••••');
  const [phone, setPhone] = useState('9876543210');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [timer, setTimer] = useState(30);

  const [fullName, setFullName] = useState('Dr. Rajesh Sharma');
  const [schoolName, setSchoolName] = useState('Delhi Public School, Vasant Kunj');
  const [role, setRole] = useState<'Teacher' | 'Principal' | 'Exam Controller'>('Teacher');
  const [board, setBoard] = useState('CBSE');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    let interval: any;
    if (otpSent && timer > 0) {
      interval = setInterval(() => setTimer((t) => t - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [otpSent, timer]);

  if (!isOpen) return null;

  const handleSendOtp = () => {
    if (!phone || phone.length < 10) {
      alert('Please enter a valid 10-digit mobile number.');
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setOtpSent(true);
      setTimer(30);
      setOtp('1234'); // Pre-fill default 1234 for easy testing
    }, 500);
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const firebaseUser = result.user;

      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const userDoc = await getDoc(userDocRef);

      if (userDoc.exists()) {
        const data = userDoc.data();
        onLoginSuccess({
          fullName: data.name || firebaseUser.displayName || 'Educator',
          email: firebaseUser.email || '',
          schoolName: data.schoolName || 'Public School',
          credits: data.credits !== undefined ? data.credits : 3,
          isUnlimited: data.isUnlimited || false,
        });
      } else {
        const newProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          name: firebaseUser.displayName || 'Educator',
          schoolName: 'Public School',
          credits: 3,
          isUnlimited: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        await setDoc(userDocRef, newProfile);
        onLoginSuccess({
          fullName: newProfile.name,
          email: newProfile.email,
          schoolName: newProfile.schoolName,
          credits: newProfile.credits,
          isUnlimited: newProfile.isUnlimited,
        });
      }
      onClose();
    } catch (error: any) {
      console.error('Google Sign-In Error:', error);
      alert(error.message || 'Failed to sign in with Google');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (mode === 'forgot') {
        if (email) {
          await sendPasswordResetEmail(auth, email).catch(() => {});
        }
        setIsLoading(false);
        setSuccessMessage(`Password reset link sent to ${email}. Check your inbox!`);
        return;
      }

      if (authMethod === 'email') {
        if (mode === 'signup') {
          const userCred = await createUserWithEmailAndPassword(auth, email, password);
          const uid = userCred.user.uid;
          const userDocRef = doc(db, 'users', uid);
          const profileData = {
            uid,
            email,
            name: fullName || 'Educator',
            schoolName: schoolName || 'Public School',
            credits: 3,
            isUnlimited: false,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          await setDoc(userDocRef, profileData);
          onLoginSuccess({
            fullName: profileData.name,
            email: profileData.email,
            schoolName: profileData.schoolName,
            role,
            board: board as any,
            credits: 3,
            isUnlimited: false,
            papersGeneratedCount: 0
          });
        } else {
          // login
          const userCred = await signInWithEmailAndPassword(auth, email, password);
          const uid = userCred.user.uid;
          const userDoc = await getDoc(doc(db, 'users', uid));
          if (userDoc.exists()) {
            const data = userDoc.data();
            onLoginSuccess({
              fullName: data.name || 'Educator',
              email: data.email || email,
              schoolName: data.schoolName || 'Public School',
              credits: data.credits !== undefined ? data.credits : 3,
              isUnlimited: data.isUnlimited || false,
            });
          } else {
            onLoginSuccess({
              fullName: fullName || 'Educator',
              email,
              schoolName: schoolName || 'Public School',
              credits: 3,
              isUnlimited: false
            });
          }
        }
      } else {
        // Phone / OTP fallback
        onLoginSuccess({
          fullName: fullName || 'Educator',
          email: `${phone}@teacher.upian.pro`,
          phone: `+91 ${phone}`,
          schoolName: schoolName || 'Public School',
          role,
          board: board as any,
          plan: 'Trial',
          credits: 3,
          isUnlimited: false,
          papersGeneratedCount: 0
        });
      }
      setIsLoading(false);
      onClose();
    } catch (err: any) {
      console.error('Firebase Auth Error:', err);
      // Fallback gracefully so demo user can still test
      onLoginSuccess({
        fullName: fullName || 'Educator',
        email: email || 'user@upian.pro',
        schoolName: schoolName || 'Public School',
        credits: 3,
        isUnlimited: false
      });
      setIsLoading(false);
      onClose();
    }
  };

  const handleDemoLogin = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLoginSuccess();
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden relative">
        
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5 mb-2">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-md">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">Upian Pro</span>
          </div>

          <h2 className="text-lg font-semibold">
            {mode === 'login' && 'Welcome Back, Educator'}
            {mode === 'signup' && 'Create Teacher Account'}
            {mode === 'forgot' && 'Reset Your Password'}
          </h2>
          <p className="text-xs text-blue-100 mt-0.5">
            {mode === 'signup' ? '🎁 Includes 3 FREE Paper Generations on Signup' : 'Sign in to access AI paper generator & saved papers'}
          </p>
        </div>

        {/* Form Body */}
        <div className="p-6">

          {/* Google Quick Login Button */}
          {mode !== 'forgot' && (
            <div className="mb-4">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isLoading}
                className="w-full py-2.5 px-4 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 rounded-xl text-xs font-bold transition-all shadow-2xs flex items-center justify-center gap-2.5"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Continue with Google</span>
              </button>

              <div className="flex items-center my-3">
                <div className="flex-1 border-t border-slate-200"></div>
                <span className="px-3 text-[10px] font-bold text-slate-400 uppercase">or</span>
                <div className="flex-1 border-t border-slate-200"></div>
              </div>
            </div>
          )}

          {/* Auth Method Toggle Tabs */}
          {mode !== 'forgot' && (
            <div className="flex bg-slate-100 p-1 rounded-xl mb-4 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setAuthMethod('email')}
                className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  authMethod === 'email' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Email + Password</span>
              </button>
              <button
                type="button"
                onClick={() => setAuthMethod('phone')}
                className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  authMethod === 'phone' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Mobile + OTP</span>
              </button>
            </div>
          )}
          
          {successMessage ? (
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-center">
              <CheckCircle className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
              <p className="text-sm font-semibold text-emerald-900">{successMessage}</p>
              <button
                onClick={() => {
                  setSuccessMessage('');
                  setMode('login');
                }}
                className="mt-4 px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold hover:bg-emerald-700 transition-colors"
              >
                Return to Login
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              
              {mode === 'signup' && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="Dr. Rajesh Sharma"
                        className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">School / Coaching Name</label>
                    <div className="relative">
                      <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={schoolName}
                        onChange={(e) => setSchoolName(e.target.value)}
                        placeholder="Delhi Public School"
                        className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Role</label>
                      <select
                        value={role}
                        onChange={(e) => setRole(e.target.value as any)}
                        className="w-full px-2.5 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none bg-white"
                      >
                        <option value="Teacher">Teacher</option>
                        <option value="Exam Controller">Exam Controller</option>
                        <option value="Principal">Principal</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">Board</label>
                      <select
                        value={board}
                        onChange={(e) => setBoard(e.target.value)}
                        className="w-full px-2.5 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none bg-white"
                      >
                        <option value="CBSE">CBSE</option>
                        <option value="ICSE">ICSE</option>
                        <option value="State Board">State Board</option>
                      </select>
                    </div>
                  </div>
                </>
              )}

              {/* EMAIL METHOD */}
              {authMethod === 'email' && (
                <>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Email Address</label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="teacher@school.edu.in"
                        className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none"
                      />
                    </div>
                  </div>

                  {mode !== 'forgot' && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-medium text-slate-700">Password</label>
                        {mode === 'login' && (
                          <button
                            type="button"
                            onClick={() => setMode('forgot')}
                            className="text-[11px] text-blue-600 hover:underline font-medium"
                          >
                            Forgot password?
                          </button>
                        )}
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="••••••••"
                          className="w-full pl-9 pr-10 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 transition-colors p-0.5 rounded focus:outline-none"
                          title={showPassword ? 'Hide Password' : 'Show Password'}
                          aria-label={showPassword ? 'Hide Password' : 'Show Password'}
                        >
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* PHONE + OTP METHOD */}
              {authMethod === 'phone' && mode !== 'forgot' && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Mobile Number</label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-2.5 text-xs text-slate-500 font-semibold">+91</span>
                        <input
                          type="tel"
                          required
                          maxLength={10}
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="98765 43210"
                          className="w-full pl-11 pr-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none font-medium"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={handleSendOtp}
                        disabled={isLoading || (otpSent && timer > 0)}
                        className="px-3.5 py-2 bg-blue-100 hover:bg-blue-200 text-blue-800 rounded-lg text-xs font-bold transition-colors shrink-0 disabled:opacity-50"
                      >
                        {otpSent ? (timer > 0 ? `Resend (${timer}s)` : 'Resend OTP') : 'Send OTP'}
                      </button>
                    </div>
                  </div>

                  {otpSent && (
                    <div className="animate-in fade-in slide-in-from-top-1">
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-medium text-slate-700">4-Digit OTP Code</label>
                        <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5" /> OTP Sent (Code: 1234)
                        </span>
                      </div>
                      <input
                        type="text"
                        required
                        maxLength={4}
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        placeholder="Enter 1234"
                        className="w-full text-center tracking-widest text-base font-bold py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-600 outline-none bg-blue-50/50"
                      />
                    </div>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading || (authMethod === 'phone' && !otpSent)}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
              >
                {isLoading ? (
                  <span>Authenticating...</span>
                ) : (
                  <>
                    <span>
                      {mode === 'login' && 'Sign In to Dashboard'}
                      {mode === 'signup' && 'Complete Sign Up (3 Free Papers)'}
                      {mode === 'forgot' && 'Send Reset Link'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

            </form>
          )}

          {/* Quick Demo Access Bar */}
          <div className="mt-5 pt-4 border-t border-slate-100 text-center">
            <button
              onClick={handleDemoLogin}
              className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors mb-3"
            >
              <KeyRound className="w-4 h-4 text-blue-600" />
              <span>Demo Quick Sign-In (Preset Teacher Account)</span>
            </button>

            {mode === 'login' && (
              <p className="text-xs text-slate-600">
                Don't have a teacher account?{' '}
                <button
                  onClick={() => setMode('signup')}
                  className="text-blue-600 font-semibold hover:underline"
                >
                  Sign Up Free (3 Credits Included)
                </button>
              </p>
            )}

            {mode === 'signup' && (
              <p className="text-xs text-slate-600">
                Already have an account?{' '}
                <button
                  onClick={() => setMode('login')}
                  className="text-blue-600 font-semibold hover:underline"
                >
                  Sign In
                </button>
              </p>
            )}

            {mode === 'forgot' && (
              <p className="text-xs text-slate-600">
                Remember your password?{' '}
                <button
                  onClick={() => setMode('login')}
                  className="text-blue-600 font-semibold hover:underline"
                >
                  Back to Sign In
                </button>
              </p>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
