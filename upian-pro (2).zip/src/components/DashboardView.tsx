import React from 'react';
import { 
  FileText, 
  Sparkles, 
  Database, 
  FileCheck, 
  FileEdit, 
  Plus, 
  ArrowUpRight, 
  Building2, 
  Eye, 
  Copy, 
  Trash2, 
  TrendingUp, 
  BookOpen
} from 'lucide-react';
import { ActiveTab, QuestionPaper, SchoolBranding, UserProfile } from '../types';

interface DashboardViewProps {
  user: UserProfile;
  branding: SchoolBranding;
  papers: QuestionPaper[];
  setActiveTab: (tab: ActiveTab) => void;
  onPreviewPaper: (paper: QuestionPaper) => void;
  onDuplicatePaper: (id: string) => void;
  onDeletePaper: (id: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  branding,
  papers,
  setActiveTab,
  onPreviewPaper,
  onDuplicatePaper,
  onDeletePaper
}) => {
  const totalPapers = papers.length;
  const aiPapersCount = papers.filter(p => p.createdMode === 'ai').length;
  const qBankPapersCount = papers.filter(p => p.createdMode === 'question_bank').length;
  const draftPapersCount = papers.filter(p => p.status === 'draft').length;

  const stats = [
    {
      title: 'Total Papers Generated',
      count: totalPapers,
      icon: FileText,
      color: 'from-blue-600 to-indigo-600',
      textColor: 'text-blue-600',
      bgColor: 'bg-blue-50',
      change: '+24% this month'
    },
    {
      title: 'AI Papers',
      count: aiPapersCount,
      icon: Sparkles,
      color: 'from-purple-600 to-indigo-600',
      textColor: 'text-purple-600',
      bgColor: 'bg-purple-50',
      change: 'Gemini 3.6 Powered'
    },
    {
      title: 'Question Bank Papers',
      count: qBankPapersCount,
      icon: Database,
      color: 'from-emerald-600 to-teal-600',
      textColor: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      change: '1 to 5 Mark Questions'
    },
    {
      title: 'Draft Papers',
      count: draftPapersCount,
      icon: FileEdit,
      color: 'from-amber-600 to-orange-600',
      textColor: 'text-amber-600',
      bgColor: 'bg-amber-50',
      change: 'In-progress Builder'
    }
  ];

  return (
    <div className="space-y-6">
      
      {/* Welcome & Quick Action Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 rounded-2xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-[radial-gradient(circle_at_top_right,var(--color-blue-500),transparent_70%)] opacity-20 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Welcome Back, {user.fullName}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-display tracking-tight text-white">
              Question Paper Generation Studio
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
              Generate 100% board-compliant question papers for {branding.schoolName || user.schoolName} in under 2 minutes with AI.
            </p>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid - 2x2 on Mobile */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div key={idx} className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-2xs hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <span className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase tracking-wider">
                  {stat.title}
                </span>
                <div className={`p-1.5 sm:p-2 rounded-xl ${stat.bgColor} ${stat.textColor}`}>
                  <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </div>
              </div>
              <div className="mt-2 sm:mt-3">
                <p className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  {stat.count}
                </p>
                <p className="text-[10px] sm:text-xs font-semibold text-slate-500 mt-0.5 truncate">
                  {stat.change}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Creation Mode Shortcuts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div 
          onClick={() => setActiveTab('ai_generate')}
          className="group bg-white p-6 rounded-2xl border-2 border-blue-50 hover:border-blue-500 transition-all cursor-pointer shadow-sm relative overflow-hidden flex flex-col justify-between"
        >
          <div>
            <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mb-4 text-white shadow-md shadow-blue-100 group-hover:scale-105 transition-transform">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2 flex items-center justify-between">
              A) AI Generate Mode
              <ArrowUpRight className="w-4 h-4 text-blue-600 group-hover:translate-x-0.5 transition-transform" />
            </h3>
            <p className="text-sm text-slate-500 mb-6 leading-relaxed">
              Specify Board, Class, Subject, Chapters & Marks. Gemini drafts balanced MCQs, Short & Long questions automatically.
            </p>
          </div>
          <button className="w-full py-2.5 bg-blue-50 text-blue-700 font-bold rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-all text-xs">
            Start AI Paper Generation
          </button>
        </div>

        <div 
          onClick={() => setActiveTab('question_bank')}
          className="group bg-white p-6 rounded-2xl border-2 border-emerald-50 hover:border-emerald-500 transition-all cursor-pointer shadow-sm relative overflow-hidden flex flex-col justify-between"
        >
          <div>
            <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center mb-4 text-white shadow-md shadow-emerald-100 group-hover:scale-105 transition-transform">
              <Database className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2 flex items-center justify-between">
              B) Question Bank Mode
              <ArrowUpRight className="w-4 h-4 text-emerald-600 group-hover:translate-x-0.5 transition-transform" />
            </h3>
            <p className="text-sm text-slate-500 mb-6 leading-relaxed">
              Pick questions manually from curated 1, 2, 3, 4, 5 marks repositories. Filter by topic and difficulty.
            </p>
          </div>
          <button className="w-full py-2.5 bg-emerald-50 text-emerald-700 font-bold rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition-all text-xs">
            Browse Question Bank
          </button>
        </div>

        <div 
          onClick={() => setActiveTab('smart_builder')}
          className="group bg-white p-6 rounded-2xl border-2 border-indigo-50 hover:border-indigo-500 transition-all cursor-pointer shadow-sm relative overflow-hidden flex flex-col justify-between"
        >
          <div>
            <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center mb-4 text-white shadow-md shadow-indigo-100 group-hover:scale-105 transition-transform">
              <FileEdit className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2 flex items-center justify-between">
              C) Smart Paper Builder
              <ArrowUpRight className="w-4 h-4 text-indigo-600 group-hover:translate-x-0.5 transition-transform" />
            </h3>
            <p className="text-sm text-slate-500 mb-6 leading-relaxed">
              Drag and drop questions, reorder sections live, auto-number, add custom questions, and format school headers.
            </p>
          </div>
          <button className="w-full py-2.5 bg-indigo-50 text-indigo-700 font-bold rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-all text-xs">
            Open Drag-and-Drop Builder
          </button>
        </div>

      </div>

      {/* Recent Question Papers Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between gap-4">
          <div>
            <h2 className="font-bold text-slate-900 text-base font-display">Recent Question Papers</h2>
            <p className="text-xs text-slate-500">Manage, preview, print or export your generated papers</p>
          </div>
          
          <button
            onClick={() => setActiveTab('saved_papers')}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 hover:underline flex items-center gap-1"
          >
            View All Saved Papers ({papers.length})
          </button>
        </div>

        {papers.length === 0 ? (
          <div className="p-8 sm:p-12 text-center text-slate-500">
            <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="font-medium text-sm text-slate-700">No papers created yet</p>
            <p className="text-xs text-slate-500 mt-1">Start by generating an AI paper or picking from the Question Bank.</p>
            <button
              onClick={() => setActiveTab('ai_generate')}
              className="mt-4 px-4 py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-700 transition-colors shadow-sm"
            >
              Generate First Paper
            </button>
          </div>
        ) : (
          <div>
            {/* Mobile Cards View */}
            <div className="block sm:hidden divide-y divide-slate-100">
              {papers.slice(0, 5).map((paper) => (
                <div key={paper.id} className="p-4 space-y-3 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <div className="p-2 rounded-xl bg-blue-50 text-blue-600 shrink-0 mt-0.5">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-xs line-clamp-2 leading-snug">
                          {paper.title}
                        </h4>
                        <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700">
                            {paper.board} • Class {paper.classLevel}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-blue-50 text-blue-700">
                            {paper.subject}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-extrabold ${
                            paper.createdMode === 'ai' 
                              ? 'bg-purple-100 text-purple-800' 
                              : paper.createdMode === 'question_bank' 
                                ? 'bg-emerald-100 text-emerald-800' 
                                : 'bg-indigo-100 text-indigo-800'
                          }`}>
                            {paper.createdMode === 'ai' && 'AI'}
                            {paper.createdMode === 'question_bank' && 'Bank'}
                            {paper.createdMode === 'builder' && 'Builder'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-50">
                    <span className="font-semibold text-slate-600">
                      {paper.totalMarks} Marks • {paper.timeAllowedMinutes} Mins
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onPreviewPaper(paper)}
                        className="px-2.5 py-1.5 bg-blue-600 text-white rounded-lg font-bold text-[11px] flex items-center gap-1 shadow-2xs active:scale-95 transition-transform"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View</span>
                      </button>
                      <button
                        onClick={() => onDuplicatePaper(paper.id)}
                        className="p-1.5 text-slate-600 hover:text-emerald-600 bg-slate-100 hover:bg-emerald-50 rounded-lg transition-colors"
                        title="Duplicate Paper"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeletePaper(paper.id)}
                        className="p-1.5 text-slate-600 hover:text-rose-600 bg-slate-100 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete Paper"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden sm:block overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold uppercase tracking-wider border-b border-slate-100">
                  <tr>
                    <th className="px-5 py-3.5">Paper Title</th>
                    <th className="px-5 py-3.5">Board & Class</th>
                    <th className="px-5 py-3.5">Subject</th>
                    <th className="px-5 py-3.5">Marks & Time</th>
                    <th className="px-5 py-3.5">Mode</th>
                    <th className="px-5 py-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {papers.slice(0, 5).map((paper) => (
                    <tr key={paper.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-5 py-4 font-semibold text-slate-900">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                          <span className="truncate max-w-xs" title={paper.title}>{paper.title}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700">
                          {paper.board} • Class {paper.classLevel}
                        </span>
                      </td>
                      <td className="px-5 py-4 font-medium text-slate-800">
                        {paper.subject}
                      </td>
                      <td className="px-5 py-4 text-slate-600">
                        {paper.totalMarks} Marks • {paper.timeAllowedMinutes} Mins
                      </td>
                      <td className="px-5 py-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          paper.createdMode === 'ai' 
                            ? 'bg-purple-100 text-purple-800' 
                            : paper.createdMode === 'question_bank' 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : 'bg-indigo-100 text-indigo-800'
                        }`}>
                          {paper.createdMode === 'ai' && 'AI Generated'}
                          {paper.createdMode === 'question_bank' && 'Question Bank'}
                          {paper.createdMode === 'builder' && 'Smart Builder'}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onPreviewPaper(paper)}
                            className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                            title="Preview & Print PDF"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onDuplicatePaper(paper.id)}
                            className="p-1.5 text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-md transition-colors"
                            title="Duplicate Paper"
                          >
                            <Copy className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onDeletePaper(paper.id)}
                            className="p-1.5 text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                            title="Delete Paper"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
